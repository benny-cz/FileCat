if (args is ["--analysis-memory-counter-control"]) return AnalysisPhysicalMemoryNative.Control();
if (args is ["--analysis-csv-scale", var count, var shape, var parent]) return await CsvReportScale.RunAsync(int.Parse(count, System.Globalization.CultureInfo.InvariantCulture), shape, parent);
throw new ArgumentException("Choose an explicit counter control or generated CSV scale workload.");
