using System.Reflection;
using FileCat.Core.Analysis;
internal static class ScratchScale
{
 internal static AnalysisPrivateDirectory Directory(string parent)
 {
  if (!OperatingSystem.IsWindows()) return new UnixAnalysisPrivateDirectory(parent, "scratch");
  var assembly = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "FileCat.Platform.Windows.dll"));
  return (AnalysisPrivateDirectory)Activator.CreateInstance(assembly.GetType("FileCat.Platform.Windows.WindowsAnalysisPrivateDirectory", true)!, parent, "scratch")!;
 }
}
