$ErrorActionPreference='Stop';$base=$PSScriptRoot;$state=Join-Path $base 'state.txt'
if((Get-Process -Id $PID).SessionId-eq0-or[Environment]::UserName-ne'filecatdsa_r2'){throw 'Use the ordinary R2 interactive desktop'}
function Idle {if(@(Get-Process -Name 'FileCat*',dotnet -ErrorAction SilentlyContinue).Count){'BUSY'|Set-Content $state;exit 75}}
try{
 Idle;'RUNNING phase=verify'|Set-Content $state
 if((Get-FileHash -LiteralPath (Join-Path $base 'bundle.tgz') -Algorithm SHA256).Hash-ne'bfe3d7e4bf769464c681853ea4a92e29f32d8f2f678d579f60af58dbe957450d'){throw 'Bundle changed'}
 $driver=Join-Path $base 'driver';$payload=Join-Path $base 'payload'
 if((Test-Path -LiteralPath $driver)-or(Test-Path -LiteralPath $payload)){throw 'Fresh directories required'}
 New-Item -ItemType Directory -Path $driver|Out-Null
 & tar.exe -xzf (Join-Path $base 'bundle.tgz') -C $driver;if($LASTEXITCODE){throw 'Extraction failed'}
 $plan=Get-Content -LiteralPath (Join-Path $driver 'plan.json') -Raw|ConvertFrom-Json
 $baseline=[IO.Path]::GetFullPath([string]$plan.baseline).TrimEnd('\')+'\'
 if($baseline-ne'C:\FileCatDsa20261104R2\batch-r1291\payload\'){throw 'Wrong baseline'}
 $disk=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
 $reserve=[long][Math]::Min(2GB,[Math]::Max(256MB,[Math]::Ceiling($disk.Size/100.0)))
 if($disk.FreeSpace-lt($reserve+[long]$plan.clonedBytes+256MB)){throw 'Insufficient clone space'}
 foreach($row in $plan.inputs){
  if([IO.Path]::IsPathRooted($row.path)-or$row.path.Contains(':')-or$row.path.Split('/')-contains'..'){throw 'Invalid input path'}
  $source=[IO.Path]::GetFullPath((Join-Path $baseline $row.path));$item=Get-Item -LiteralPath $source
  if(!$source.StartsWith($baseline,[StringComparison]::OrdinalIgnoreCase)-or$item.PSIsContainer-or($item.Attributes-band[IO.FileAttributes]::ReparsePoint)-ne0-or(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash-ne$row.sha256){throw ('Cached input changed: '+$row.path)}
 }
 foreach($row in $plan.inputs){
  $target=Join-Path $payload $row.path;New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force|Out-Null
  Copy-Item -LiteralPath (Join-Path $baseline $row.path) -Destination $target
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash-ne$row.sha256){throw 'Clone changed'}
 }
 foreach($row in $plan.patches){
  if($row.patch-notin@('FileCat.App.Tests.dll','FileCat.App.Tests.pdb')-or$row.path-ne('tests/FileCat.App.Tests/bin/Debug/net10.0/'+$row.patch)){throw 'Only the test assembly may change'}
  $patch=Join-Path $driver $row.patch
  if((Get-FileHash -LiteralPath $patch -Algorithm SHA256).Hash-ne$row.sha256){throw 'Patch changed'}
  Copy-Item -LiteralPath $patch -Destination (Join-Path $payload $row.path)
 }
 [ordered]@{baseline=$baseline;verifiedFiles=@($plan.inputs).Count;changedProductFiles=0;testOnlyPatches=$plan.patches}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $base 'cache-proof.json')
 foreach($phase in 'epoch','app-rescan','render','settings'){
  Idle;('RUNNING phase='+$phase)|Set-Content $state
  $bin=Join-Path $payload 'tests\FileCat.Core.Tests\bin\Debug\net10.0';$assembly='FileCat.Core.Tests.dll'
  $filters=switch($phase){
   'epoch'{@('-method','*RescanEpoch*')}
   'native-epoch'{@('-method','*RescanEpoch*')}
   'core'{@('-class','FileCat.Core.Tests.Analysis*','-class','*CommandTests','-class','*DeviceIoSchedulerTests','-class','*PathAndStateTests','-class','*ZipListingRevisionTests')}
   'app-rescan'{@('-method','*NativeRuntimeRescanFactory*','-method','*NativeRescanView*','-method','*NativeRescanPreparationKeepsPrivateNamesExcludedAcrossBothEpochs','-method','*NativeOwnedRuntimeView*','-method','*NativeIndexedComparisonCanceledMappingAndAcquisitionPublishNoPartialTab','-method','*NonrespondingPreparationFreezesBindingAndNeverStartsAScanAfterReturning','-method','*NativeProgressivePreview*')}
   'render'{@('-class','*AnalysisRenderingTests')}
   'settings'{@('-method','*Private_Windows_history_is_acknowledged_through_UI_and_retained_summary_survives_restart_without_its_journal')}
   'native'{@('-class','*AnalysisWindowsTests','-class','*WindowsFileOperationsTests','-class','*WindowsHiddenDataTests','-class','*BoundReplacementTests','-class','*BoundComparedDeleteTests','-class','*BoundExtractionTests')}
  }
  if($phase-in@('native-epoch','native')){$bin=Join-Path $payload 'native';$assembly='FileCat.Platform.Windows.Tests.dll'}
  if($phase-in@('app-rescan','render','settings')){$bin=Join-Path $payload 'render';$assembly=if($phase-eq'settings'){'FileCat.App.Tests.dll'}else{'FileCat.Rendering.Tests.dll'}}
  if($phase-eq'settings'){$bin=Join-Path $payload 'tests\FileCat.App.Tests\bin\Debug\net10.0'}
  Set-Location -LiteralPath $bin;$ErrorActionPreference='Continue'
  & 'C:\Program Files\dotnet\dotnet.exe' $assembly @filters -noLogo -noColor -maxThreads 2 -xml (Join-Path $base ($phase+'.xml')) *> (Join-Path $base ($phase+'.log'))
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop'
  [xml]$document=[IO.File]::ReadAllText((Join-Path $base ($phase+'.xml')));$a=$document.assemblies.assembly
  if($result-ne0-or[int]$a.total-le0-or[int]$a.failed-ne0-or[int]$a.errors-ne0){throw 'The actual test phase failed'}
  if($phase-eq'app-rescan'-and([int]$a.total-ne39-or[int]$a.passed-ne39-or[int]$a.skipped-ne0)){throw 'App rescan discovery mismatch'}
  if($phase-eq'settings'-and([int]$a.total-ne1-or[int]$a.passed-ne1-or[int]$a.skipped-ne0)){throw 'App/source audit discovery mismatch'}
  if($phase-eq'render'-and([int]$a.total-ne825-or[int]$a.passed-ne824-or[int]$a.skipped-ne1)){throw 'Rendering discovery mismatch'}
  if($phase-eq'epoch'-and([int]$a.total-ne23-or[int]$a.passed-ne21-or[int]$a.skipped-ne2)){throw 'Epoch discovery/platform skips mismatch'}
  if($phase-eq'native-epoch'-and([int]$a.total-ne2-or[int]$a.passed-ne2-or[int]$a.skipped-ne0)){throw 'Native epoch discovery mismatch'}
 }
 'FINISHED exit=0'|Set-Content $state;exit 0
}catch{($_|Out-String)|Set-Content (Join-Path $base 'failure.txt');'FINISHED exit=1'|Set-Content $state;exit 1}
