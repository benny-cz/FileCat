set -eu
cd "$(dirname "$0")";base=$(pwd)
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=verify\n' > state.txt;exit 75;fi
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '12a10c01ce02dc74145401bbef12b797da333b950cece5f3d06a61f2607acc5e' ];umask 077;mkdir driver;tar -xzf bundle.tgz -C driver
python3 driver/clone.py
idle(){ if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=next\n' > state.txt;exit 75;fi; }
bin="$base/payload/render"
export DOTNET_ROOT="$HOME/.dotnet"
chmod 700 "$base/payload/tests/FileCat.App.Tests/bin/Debug/net10.0/FileCat"
for phase in settings epoch app-rescan render;do
 idle;printf 'RUNNING phase=%s\n' "$phase" > "$base/state.txt"
 assembly=FileCat.Rendering.Tests.dll;bin="$base/payload/render"
 case "$phase" in
  epoch) bin="$base/payload/tests/FileCat.Core.Tests/bin/Debug/net10.0";assembly=FileCat.Core.Tests.dll;set -- -method '*RescanEpoch*';;
  app-rescan) set -- -method '*NativeRuntimeRescanFactory*' -method '*NativeRescanView*' -method '*NativeRescanPreparationKeepsPrivateNamesExcludedAcrossBothEpochs' -method '*NativeOwnedRuntimeView*' -method '*NativeIndexedComparisonCanceledMappingAndAcquisitionPublishNoPartialTab' -method '*NonrespondingPreparationFreezesBindingAndNeverStartsAScanAfterReturning' -method '*NativeProgressivePreview*';;
  render) set -- -class '*AnalysisRenderingTests';;
  settings) bin="$base/payload/tests/FileCat.App.Tests/bin/Debug/net10.0";assembly=FileCat.App.Tests.dll;set -- -method '*Renamed_apphosts_are_identified_by_their_bound_entry_assembly_and_incomplete_reads_are_unknown' -method '*Actual_macOS_worker_policy_denies_descendants_and_network' -method '*No_control_that_can_be_live_has_a_fixed_accessible_name';;
 esac
 set +e
 (cd "$bin";"$HOME/.dotnet/dotnet" "$assembly" "$@" -noLogo -noColor -maxThreads 2 -xml "$base/$phase.xml") > "$base/$phase.log" 2>&1
 result=$?;set -e
 if [ "$result" != 0 ] || ! python3 "$base/payload/validate.py" "$phase" "$base/$phase.xml";then printf 'FINISHED exit=1 phase=%s\n' "$phase" > "$base/state.txt";tail -n 30 "$base/$phase.log";exit 1;fi
done
printf 'FINISHED exit=0\n' > "$base/state.txt"
