$ErrorActionPreference='Stop';$base=$PSScriptRoot;$state=Join-Path $base 'state.txt'
if((Get-Process -Id $PID).SessionId-eq0-or[Environment]::UserName-ne'filecatdsa_r2'){throw 'Use the ordinary R2 interactive desktop'}
function Idle {if(@(Get-Process -Name 'FileCat*',dotnet -ErrorAction SilentlyContinue).Count){'BUSY'|Set-Content $state;exit 75}}
try{
 Idle;'RUNNING phase=verify'|Set-Content $state
 if((Get-FileHash -LiteralPath (Join-Path $base 'bundle.tgz') -Algorithm SHA256).Hash-ne'c54aec58fefee24f1ab6583d05278daf6c718c6c684e5d6a9e584906ecc5386f'){throw 'Bundle changed'}
 $payload=Join-Path $base 'payload';if(Test-Path -LiteralPath $payload){throw 'Fresh payload required'}
 New-Item -ItemType Directory -Path $payload|Out-Null
 & tar.exe -xzf (Join-Path $base 'bundle.tgz') -C $payload;if($LASTEXITCODE){throw 'Extraction failed'}
 foreach($phase in 'settings','epoch','app-rescan','render'){
  Idle;('RUNNING phase='+$phase)|Set-Content $state
  $bin=Join-Path $payload 'tests\FileCat.Core.Tests\bin\Debug\net10.0';$assembly='FileCat.Core.Tests.dll'
  $filters=switch($phase){
   'epoch'{@('-method','*RescanEpoch*')}
   'native-epoch'{@('-method','*RescanEpoch*')}
   'core'{@('-class','FileCat.Core.Tests.Analysis*','-class','*CommandTests','-class','*DeviceIoSchedulerTests','-class','*PathAndStateTests','-class','*ZipListingRevisionTests')}
   'app-rescan'{@('-method','*NativeRuntimeRescanFactory*','-method','*NativeRescanView*','-method','*NativeRescanPreparationKeepsPrivateNamesExcludedAcrossBothEpochs','-method','*NativeOwnedRuntimeView*','-method','*NativeIndexedComparisonCanceledMappingAndAcquisitionPublishNoPartialTab','-method','*NonrespondingPreparationFreezesBindingAndNeverStartsAScanAfterReturning','-method','*NativeProgressivePreview*')}
   'render'{@('-class','*AnalysisRenderingTests')}
   'settings'{@('-method','*Renamed_apphosts_are_identified_by_their_bound_entry_assembly_and_incomplete_reads_are_unknown','-method','*Actual_macOS_worker_policy_denies_descendants_and_network','-method','*No_control_that_can_be_live_has_a_fixed_accessible_name','-method','*OperationsDrawerLayoutTests.*','-method','*StorageHistoryStartupUiTests.*')}
   'native'{@('-class','*AnalysisWindowsTests','-class','*WindowsFileOperationsTests','-class','*WindowsHiddenDataTests','-class','*BoundReplacementTests','-class','*BoundComparedDeleteTests','-class','*BoundExtractionTests')}
  }
  if($phase-in@('native-epoch','native')){$bin=Join-Path $payload 'native';$assembly='FileCat.Platform.Windows.Tests.dll'}
  if($phase-in@('app-rescan','render','settings')){$bin=Join-Path $payload 'render';$assembly=if($phase-eq'settings'){'FileCat.App.Tests.dll'}else{'FileCat.Rendering.Tests.dll'}}
  if($phase-eq'settings'){$bin=Join-Path $payload 'tests\FileCat.App.Tests\bin\Debug\net10.0'}
  Set-Location -LiteralPath $bin;$ErrorActionPreference='Continue'
  & 'C:\Program Files\dotnet\dotnet.exe' $assembly @filters -noLogo -noColor -maxThreads 2 -xml (Join-Path $base ($phase+'.xml')) *> (Join-Path $base ($phase+'.log'))
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop'
  [xml]$document=[IO.File]::ReadAllText((Join-Path $base ($phase+'.xml')));$a=$document.assemblies.assembly
  if($result-ne0-or[int]$a.total-le0-or[int]$a.failed-ne0-or[int]$a.errors-ne0){throw 'The actual test phase failed'}
  if($phase-eq'app-rescan'-and([int]$a.total-ne39-or[int]$a.passed-ne39-or[int]$a.skipped-ne0)){throw 'App rescan discovery mismatch'}
  if($phase-eq'settings'-and([int]$a.total-ne22-or[int]$a.passed-ne21-or[int]$a.skipped-ne1)){throw 'App/source audit discovery mismatch'}
  if($phase-eq'render'-and([int]$a.total-ne825-or[int]$a.passed-ne824-or[int]$a.skipped-ne1)){throw 'Rendering discovery mismatch'}
  if($phase-eq'epoch'-and([int]$a.total-ne23-or[int]$a.passed-ne21-or[int]$a.skipped-ne2)){throw 'Epoch discovery/platform skips mismatch'}
  if($phase-eq'native-epoch'-and([int]$a.total-ne2-or[int]$a.passed-ne2-or[int]$a.skipped-ne0)){throw 'Native epoch discovery mismatch'}
 }
 'FINISHED exit=0'|Set-Content $state;exit 0
}catch{($_|Out-String)|Set-Content (Join-Path $base 'failure.txt');'FINISHED exit=1'|Set-Content $state;exit 1}
