set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=verify
' > state.txt;exit 75;fi
actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);[ "$actual" = 'd7ac320d0e08f2764e68103a8d8a70eba9c5e6ae28b249e8eb753aef5eae035b' ];umask 077;mkdir driver;tar -xzf bundle.tgz -C driver
python3 driver/run.py
