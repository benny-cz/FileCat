set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=verify
' > state.txt;exit 75;fi
actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);[ "$actual" = '575f35b37ec94f628107ecd2d550fec0d0a8f5d35fc725a7e95c96b7b66b68fd' ];umask 077;mkdir driver;tar -xzf bundle.tgz -C driver
python3 driver/run.py
