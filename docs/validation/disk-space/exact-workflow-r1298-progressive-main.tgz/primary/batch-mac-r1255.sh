set -eu
cd "$(dirname "$0")";base=$(pwd)
idle(){ if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=%s
' "$1" > "$base/state.txt";ps -axo pid=,ppid=,args= > "$base/busy-$1.txt";exit 75;fi; }
idle verify
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = 'f273808d941126d300871a8fb0b738617a67f0f9984444ec15d1ed8044791d55' ];umask 077;mkdir payload;tar -xzf bundle.tgz -C payload
for phase in app-rescan core render settings;do
 idle "$phase";printf 'RUNNING phase=%s
' "$phase" > "$base/state.txt"
 project=FileCat.Rendering.Tests;set -- -class '*AnalysisRenderingTests'
 case "$phase" in
 app-rescan)set -- -method '*NativeRuntimeRescanFactory*' -method '*NativeRescanView*' -method '*NativeRescanPreparationKeepsPrivateNamesExcludedAcrossBothEpochs' -method '*NativeOwnedRuntimeView*' -method '*NativeIndexedComparisonCanceledMappingAndAcquisitionPublishNoPartialTab' -method '*NonrespondingPreparationFreezesBindingAndNeverStartsAScanAfterReturning';;
 core)project=FileCat.Core.Tests;set -- -class '*';;
 settings)project=FileCat.App.Tests;set -- -class '*';;
 esac
 bin="$base/payload/tests/$project/bin/Debug/net10.0"
 set +e
 (cd "$bin";"$HOME/.dotnet/dotnet" "$project.dll" "$@" -noLogo -noColor -maxThreads 2 -xml "$base/$phase.xml") > "$base/$phase.log" 2>&1
 result=$?;set -e
 if [ "$result" != 0 ] || ! python3 "$base/payload/validate.py" "$phase" "$base/$phase.xml";then printf 'FINISHED exit=1 phase=%s
' "$phase" > "$base/state.txt";tail -n 30 "$base/$phase.log";exit 1;fi
done
printf 'FINISHED exit=0
' > "$base/state.txt"
