set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=verify
' > state.txt;exit 75;fi
actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);[ "$actual" = '67a3564a4cc1bc0961cd9632f15c40d01104d5e71ca8de873225069b17c41a3e' ];umask 077;mkdir driver;tar -xzf bundle.tgz -C driver
python3 driver/run.py
