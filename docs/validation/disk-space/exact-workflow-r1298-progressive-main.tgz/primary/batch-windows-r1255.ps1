$ErrorActionPreference='Stop';$base=$PSScriptRoot;$state=Join-Path $base 'state.txt'
function Idle([string]$phase){if(@(Get-Process -Name 'FileCat*',dotnet -ErrorAction SilentlyContinue).Count){('BUSY phase='+$phase)|Set-Content $state;exit 75}}
try{
 if((Get-Process -Id $PID).SessionId-eq0-or[Environment]::UserName-ne'filecatdsa_r2'){throw 'Use ordinary interactive R2'}
 Idle verify
 if((Get-FileHash -LiteralPath (Join-Path $base 'bundle.tgz') -Algorithm SHA256).Hash.ToLowerInvariant()-ne'5a1f66521ca9f67be7202d3960ff44e2194d7ee8f716002eb56c7428427f1baa'){throw 'Bundle changed'}
 $payload=Join-Path $base 'payload';if(Test-Path -LiteralPath $payload){throw 'Fresh payload required'}
 New-Item -ItemType Directory -Path $payload|Out-Null;& tar.exe -xzf (Join-Path $base 'bundle.tgz') -C $payload;if($LASTEXITCODE){throw 'Extraction failed'}
 foreach($phase in 'app-rescan','core','native','render','settings'){
  Idle $phase;('RUNNING phase='+$phase)|Set-Content $state
  $project=switch($phase){'core'{'FileCat.Core.Tests'}'native'{'FileCat.Platform.Windows.Tests'}'settings'{'FileCat.App.Tests'}default{'FileCat.Rendering.Tests'}}
  $filters=if($phase-eq'app-rescan'){@('-method','*NativeRuntimeRescanFactory*','-method','*NativeRescanView*','-method','*NativeRescanPreparationKeepsPrivateNamesExcludedAcrossBothEpochs','-method','*NativeOwnedRuntimeView*','-method','*NativeIndexedComparisonCanceledMappingAndAcquisitionPublishNoPartialTab','-method','*NonrespondingPreparationFreezesBindingAndNeverStartsAScanAfterReturning')}elseif($phase-eq'render'){@('-class','*AnalysisRenderingTests')}else{@('-class','*')}
  $bin=Join-Path $payload ('tests\'+$project+'\bin\Debug\net10.0');Set-Location -LiteralPath $bin;$ErrorActionPreference='Continue'
  & 'C:\Program Files\dotnet\dotnet.exe' ($project+'.dll') @filters -noLogo -noColor -maxThreads 2 -xml (Join-Path $base ($phase+'.xml')) *> (Join-Path $base ($phase+'.log'))
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop';[xml]$xml=[IO.File]::ReadAllText((Join-Path $base ($phase+'.xml')));$a=$xml.assemblies.assembly
  if($result-ne0-or[int]$a.total-le0-or[int]$a.failed-ne0-or[int]$a.errors-ne0){throw 'Actual test phase failed'}
  if($phase-eq'app-rescan'-and([int]$a.total-ne29-or[int]$a.passed-ne29-or[int]$a.skipped-ne0)){throw 'Focused discovery mismatch'}
  if($phase-eq'render'-and([int]$a.total-ne814-or[int]$a.passed-ne813-or[int]$a.skipped-ne1)){throw 'Rendering discovery mismatch'}
 }
 'FINISHED exit=0'|Set-Content $state;exit 0
}catch{($_|Out-String)|Set-Content (Join-Path $base 'failure.txt');'FINISHED exit=1'|Set-Content $state;exit 1}
