using FileCat.Archives.Rar15;
using FileCat.Core.Content;

namespace FileCat.Archives.Rar;

/// <summary>
/// FileCat's own RAR reader (RAR 1.5–4.x and RAR 5/7 archives, single or multi-volume). Non-solid members open
/// independently; a solid run keeps one decoder and window and is read forward, restarting at the run's first member
/// when an earlier member is asked for.
/// </summary>
internal sealed class RarReader : IMemberReader, IVolumeStreams
{
    private readonly List<Stream> _volumes;
    private readonly IReadOnlyList<string> _volumePaths;
    private readonly RarArchive _archive;
    private readonly bool _numberedVolumeGap;
    private RarBitReader _bits = new();
    private RarMemberStream? _decoded;   // the member the decoder is in (solid runs continue from it)
    private int _decodedIndex = -1;
    private RarDecoder? _decoder;
    private RarWindow? _window;
    private Rar15Decoder? _rar15;        // RAR 1.5 runs: a decoder with its own window (FileCat.Archives.Rar15, LGPL)
    private bool _disposed;
    private readonly Rar5ReadPasswordSession? _password;
    private readonly HashSet<Rar5MemberDecryption> _cryptoStreams = [];
    private readonly HashSet<RarWindow> _windows = [];
    private readonly HashSet<RarBitReader> _bitReaders = [];
    private readonly Dictionary<RarWindow, (RarBitReader Bits, RarMemberStream Member)> _runs = [];

    private RarReader(List<Stream> volumes, IReadOnlyList<string> volumePaths, RarArchive archive, bool numberedVolumeGap,
        Rar5ReadPasswordSession? password = null)
    {
        _volumes = volumes;
        _volumePaths = volumePaths;
        _archive = archive;
        _numberedVolumeGap = numberedVolumeGap;
        _password = password;
        _bitReaders.Add(_bits);
    }

    public string Format => _volumes.Count > 1 ? $"RAR ({_volumes.Count} volumes)" : "RAR";

    public bool SharesCursor => _archive.Solid;

    public IReadOnlyList<FileStream> VolumeStreams => _volumes.OfType<FileStream>().ToList();
    public IReadOnlyList<string> VolumePaths => _volumePaths;

    /// <summary>
    /// Opens the archive at <paramref name="path"/> with every volume of its set ("x.partN.rar" or "x.rar" with "x.r00"…),
    /// each read-shared and checked by <paramref name="verifyOpened"/> before any byte is read.
    /// </summary>
    public static RarReader Open(string path, Action<string, Microsoft.Win32.SafeHandles.SafeFileHandle>? verifyOpened = null) => OpenPath(path, verifyOpened, null);

    internal static RarReader OpenWithPassword(string path, Rar5ReadPasswordSession password,
        Action<string, Microsoft.Win32.SafeHandles.SafeFileHandle>? verifyOpened = null) => OpenPath(path, verifyOpened, password);

    private static RarReader OpenPath(string path, Action<string, Microsoft.Win32.SafeHandles.SafeFileHandle>? verifyOpened,
        Rar5ReadPasswordSession? password)
    {
        var volumes = new List<FileStream>();
        bool numberedVolumeGap;
        List<string> paths;
        try
        {
            paths = RarVolumes.Of(path, out numberedVolumeGap);
            foreach (string volume in paths)
                volumes.Add(ArchiveFormats.OpenShared(volume, verifyOpened));
        }
        catch
        {
            foreach (var volume in volumes)
            {
                try { volume.Dispose(); }
                catch (Exception ex) { FileCat.Core.Diagnostics.AppLog.Warn("Archive volume cleanup after open failure: " + ex.GetType().Name); }
            }
            throw;
        }
        try
        {
            return Open(volumes.Cast<Stream>().ToList(), numberedVolumeGap, default, paths, password);
        }
        catch (Exception ex) when (ex is not (IOException or UnauthorizedAccessException or InvalidDataException or OperationCanceledException))
        {
            throw new InvalidDataException("The archive cannot be read: " + ex.Message, ex);
        }
    }

    /// <summary>Reads the headers of <paramref name="volumes"/> (in order); the reader owns the streams from here on.</summary>
    public static RarReader Open(List<FileStream> volumes, bool numberedVolumeGap, CancellationToken ct = default) =>
        Open(volumes.Cast<Stream>().ToList(), numberedVolumeGap, ct, volumes.Select(v => v.Name).ToList());

    /// <summary>The same over any seekable streams (in-memory volumes for fuzzing).</summary>
    internal static RarReader Open(List<Stream> volumes, bool numberedVolumeGap, CancellationToken ct = default,
        IReadOnlyList<string>? volumePaths = null, Rar5ReadPasswordSession? password = null)
    {
        try
        {
            var archive = RarArchive.Read(volumes, ct, password);
            return new RarReader(volumes, volumePaths ?? [], archive, numberedVolumeGap, password);
        }
        catch
        {
            foreach (var volume in volumes) volume.Dispose();
            throw;
        }
    }

    public IEnumerable<MemberInfo> List(Action<string> warn, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        var warnings = new List<string>(_archive.Warnings);
        if (_numberedVolumeGap && !warnings.Contains(RarArchiveWarnings.MissingVolumes)) warnings.Add(RarArchiveWarnings.MissingVolumes);
        foreach (string warning in warnings) warn(warning);
        for (int i = 0; i < _archive.Members.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            var m = _archive.Members[i];
            long size = m.Kind == MemberKind.Directory ? 0 : Math.Max(m.UnpackedSize, 0);
            yield return new MemberInfo(i, m.Name, m.Kind, size, m.PackedSize, ArchiveFormats.Utc(m.ModifiedUtc), m.Encrypted, m.LinkTarget);
        }
    }

    public Stream Open(int index, CancellationToken ct)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if ((uint)index >= (uint)_archive.Members.Count) throw new FileNotFoundException("The member is no longer in the archive.");
        var member = _archive.Members[index];
        if (member.Kind != MemberKind.File) return Stream.Null;
        if (member.Encrypted && !CanDecrypt(member)) throw new InvalidDataException(_password is null
            ? "This member is encrypted; FileCat does not ask for archive passwords." : member.EncryptionError ?? "Password reading for this older RAR encryption format is not implemented.");
        if (!member.Complete) throw new InvalidDataException("This member continues in a volume that is missing.");
        try
        {
            var stream = member.Method == 0
                ? RarMemberStream.Stored(member, OpenPacked(member), ct)
                : OpenDecoded(index, ct);
            return new BorrowedStream(stream);
        }
        catch (Exception ex) when (ex is not (IOException or OperationCanceledException or InvalidDataException))
        {
            throw new InvalidDataException("The archive cannot be read: " + ex.Message, ex);
        }
    }

    private RarMemberStream OpenDecoded(int index, CancellationToken ct)
    {
        var member = _archive.Members[index];
        if (!member.SolidContinuation)
        {
            // Independent of every other stream: its own decoder, window and bit reader.
            NewRun(member.Version, member.Dictionary, member.UnpackedSize);
            return Start(index, solid: false, ct);
        }
        // A solid member needs every compressed member before it in its run decoded, in order.
        int runStart = index;
        while (runStart > 0 && (_archive.Members[runStart].SolidContinuation || !IsCompressedFile(_archive.Members[runStart])))
            runStart--;
        bool continues = (_decoder is not null || _rar15 is not null) && _decoded is { Broken: false } && _decodedIndex >= runStart && _decodedIndex < index;
        long prepared = 0, packed = 0;
        void Prepare(RarMemberStream stream, RarMember earlier)
        {
            long before = prepared;
            packed = checked(packed + Math.Max(1, earlier.PackedSize));
            // The run is bounded by its expansion ratio only. Each member is already held to its own declared size, and a
            // run of real members may well hold more than the 8 GiB a member of unknown size may have: a solid RAR with a
            // member over 8 GiB could otherwise not be read past that member, not even in archive order.
            var limits = MemberLimits.Of(-1, packed, long.MaxValue, ArchiveProvider.MaxExpansionRatio);
            stream.Drain(produced => limits.Check(checked(before + produced)));
            prepared = checked(before + stream.Position);
        }
        if (continues)
        {
            Prepare(_decoded!, _archive.Members[_decodedIndex]);
        }
        else
        {
            long dictionary = 0;
            for (int i = runStart; i <= index; i++) dictionary = Math.Max(dictionary, _archive.Members[i].Dictionary);
            NewRun(member.Version, dictionary, member.UnpackedSize);
        }
        for (int i = continues ? _decodedIndex + 1 : runStart; i < index; i++)
        {
            var earlier = _archive.Members[i];
            if (!IsCompressedFile(earlier)) continue;
            if (earlier.Encrypted && !CanDecrypt(earlier) || !earlier.Complete) throw new InvalidDataException("An earlier member of this solid archive cannot be decoded, so this one cannot either.");
            if (DecoderFamily(earlier.Version) != DecoderFamily(member.Version)) throw RarData.Unsupported("a solid run that changes compression version");
            Prepare(Start(i, solid: i != runStart || earlier.SolidContinuation, ct), earlier);
        }
        return Start(index, solid: true, ct);
    }

    private static bool IsCompressedFile(RarMember member) => member.Kind == MemberKind.File && member.Method != 0;
    private bool CanDecrypt(RarMember member) => _password is not null && member.Encryption is not null;
    internal bool SupportsPasswordRead(int index) => _archive.Members[index].Encryption is not null;
    private Stream OpenPacked(RarMember member)
    {
        var packed = new RarPackedStream(_volumes, member.Segments);
        if (!member.Encrypted) return packed;
        var decrypted = new Rar5MemberDecryption(packed, member.PackedSize, member.Encryption!, _password!, stream => _cryptoStreams.Remove(stream));
        _cryptoStreams.Add(decrypted); return decrypted;
    }

    private void NewRun(int version, long dictionary, long expectedBytes)
    {
        // Independent opens can still be borrowed. Reclaim completed runs, including older borrowed streams
        // that finished since the previous open; unfinished runs stay usable until reader disposal.
        foreach (var run in _runs.Where(pair => pair.Value.Member.Finished).ToArray())
        {
            run.Key.Dispose(); _windows.Remove(run.Key);
            run.Value.Bits.Dispose(); _bitReaders.Remove(run.Value.Bits); _runs.Remove(run.Key);
        }
        if (_decoder is null) { _bits.Dispose(); _bitReaders.Remove(_bits); } // initial/unused RAR 1.5 bit reader
        _bits = new RarBitReader();
        if (version == 15)
        {
            // RAR 1.5 keeps its own 64 KiB window; the run's members go through RarMemberStream's external mode.
            _rar15 = new Rar15Decoder();
            _decoder = null;
            _window = null;
        }
        else
        {
            _bitReaders.Add(_bits);
            _decoder = CreateDecoder(version);
            _window = new RarWindow(dictionary, expectedBytes);
            _windows.Add(_window);
            _rar15 = null;
        }
        _decoded = null;
        _decodedIndex = -1;
    }

    private RarMemberStream Start(int index, bool solid, CancellationToken ct)
    {
        var member = _archive.Members[index];
        if (member.Version == 15)
        {
            if (_rar15 is null) throw RarData.Unsupported("a solid run that changes compression version");
            // RAR 1.5 has no end marker: the decoder needs the size, and a member without one cannot be decoded.
            if (member.UnpackedSize < 0) throw RarData.Unsupported("a RAR 1.5 member whose size the archive does not record");
            _rar15.StartMember(new RarPackedStream(_volumes, member.Segments), member.UnpackedSize, solid);
            _decoded = RarMemberStream.External(member, _rar15.Read, ct);
        }
        else
        {
            if (_decoder is null) throw RarData.Unsupported("a solid run that changes compression version");
            var packed = OpenPacked(member);
            _bits.Reset(packed);
            _decoder.StartMember(_bits, solid, member.UnpackedSize);
            _decoded = RarMemberStream.Decoded(member, _decoder, _window!, ct, packed as Rar5MemberDecryption);
            _runs[_window!] = (_bits, _decoded);
        }
        _decodedIndex = index;
        return _decoded;
    }

    private static int DecoderFamily(int version) => version switch
    {
        50 or 70 => 5,
        29 or 36 => 3,
        20 or 26 => 2,
        15 => 1,
        _ => 0,
    };

    private static RarDecoder CreateDecoder(int version) => version switch
    {
        20 or 26 => new Rar2Decoder(),
        50 => new Rar5Decoder(rar7: false),
        70 => new Rar5Decoder(rar7: true),
        29 => new Rar3Decoder(),
        _ => throw RarData.Unsupported($"compression version {version}"),
    };

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _decoder = null;
        foreach (var bits in _bitReaders) bits.Dispose();
        _bitReaders.Clear();
        _bits.Dispose();
        foreach (var window in _windows) window.Dispose();
        _windows.Clear();
        _runs.Clear();
        _window = null;
        _rar15 = null;
        _decoded = null;
        foreach (var stream in _cryptoStreams.ToArray())
            try { stream.Dispose(); } catch (Exception ex) { FileCat.Core.Diagnostics.AppLog.Warn("Archive cipher cleanup: " + ex.GetType().Name); }
        _cryptoStreams.Clear();
        foreach (var volume in _volumes) volume.Dispose();
        _volumes.Clear();
    }
}

internal static class RarArchiveWarnings
{
    public const string MissingVolumes = "Some volumes of this archive are missing; members that continue in them cannot be extracted.";
}
