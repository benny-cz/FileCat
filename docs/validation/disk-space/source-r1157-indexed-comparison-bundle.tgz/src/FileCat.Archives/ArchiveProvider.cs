using System.Collections.Concurrent;
using FileCat.Core.Archives;
using FileCat.Core.Content;
using FileCat.Core.FileSystem;
using FileCat.Core.Resources;

namespace FileCat.Archives;

/// <summary>A member of a read-only archive, as listed.</summary>
public sealed record ArchiveMemberTag(string FullName, int Index, long Size, long CompressedSize, bool Encrypted, int DuplicateOrdinal, string? UnsafeReason,
    MemberKind Kind, string? LinkTarget) : IDisplayDetails, IArchiveMemberRevision
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? ArchiveRevision { get; init; }
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? ArchiveMutationProblem { get; init; }
    public string KindText => Kind switch
    {
        MemberKind.SymbolicLink => "Link",
        MemberKind.HardLink => "Hard link",
        MemberKind.Special => "Device or pipe",
        _ => string.Empty,
    };

    public string DetailsText => LinkTarget is { Length: > 0 } target ? "→ " + target : string.Empty;
}

/// <summary>
/// TAR, 7z, RAR, single compressed files, and disc images as read-only locations (plan §15, ADR-07, P8). The same rules
/// as ZIP apply: members are parsed in-process under limits on entry count, produced size, and expansion ratio; names
/// that would escape a folder, links, and device entries are listed but never extracted; encrypted members are listed but
/// not opened; archives inside archives (of any supported format, ZIP included) open read-only from a private spool.
/// Mark-of-the-Web propagates on extraction from the outermost marked file.
/// </summary>
public sealed partial class ArchiveProvider : ResourceProvider, IArchiveSpoolProvider
{
    public const int MaxEntries = 1_000_000;
    public const long MaxMemberInMemory = 32L * 1024 * 1024;
    public const long MaxExpansionRatio = 1000;
    public const long MaxSpooledMember = 8L * 1024 * 1024 * 1024;
    public const int MaxNestedSpools = 4;
    public const int MaxNestingDepth = 8;

    // One owner builds/publishes or retires indexes; concurrent misses must not abandon a competing build.
    private readonly object _cacheLock = new();
    private readonly ConcurrentDictionary<string, ArchiveIndex> _cache = new(PathUtil.SafetyComparer);
    private readonly ConcurrentDictionary<string, ArchiveSpool> _spools = new(StringComparer.Ordinal);
    private readonly object _spoolLock = new();
    private readonly string _tempDirectory;
    private readonly ProviderRegistry _providers;

    public ArchiveProvider(string tempDirectory, ProviderRegistry providers)
    {
        _tempDirectory = tempDirectory;
        _providers = providers;
    }

    /// <summary>Stable identity of the archive file, following links; the platform supplies Windows IDs.</summary>
    public Func<string, string?> GetSourceIdentity { get; set; } =
        path => UnixFiles.Stat(path, followLinks: true)?.Identity.ToString();

    /// <summary>Identity of the actual opened source; required when a path identity is known.</summary>
    public Func<Microsoft.Win32.SafeHandles.SafeFileHandle, string?> GetOpenedSourceIdentity { get; set; } =
        handle => UnixFiles.Stat(handle)?.Identity.ToString();

    // Length and modification time alone cannot distinguish an independently replaced file.
    // Without an identity, retain bounded ownership but do not reuse a previous index or spool.
    private string SourceIdentityKey(string path) => GetSourceIdentity(path) is { Length: > 0 } id ? id : Guid.NewGuid().ToString("N");

    // A same-file rewrite can restore length and mtime. Without a native change token, never reuse a spool.
    private static string SourceChangeKey(string path) => SourceChangeToken.FromPath(path) ?? Guid.NewGuid().ToString("N");

    public override string Scheme => Schemes.Archive;

    // ---- Detection -------------------------------------------------------------------------------------------

    public bool IsContainer(string fileName) => ArchiveFormats.ByName(fileName) is not null;

    public Location? GetContainerLocation(string filePath) => IsContainer(Path.GetFileName(filePath)) ? new(Schemes.Archive, string.Empty, Location.FileSystem(filePath)) : null;

    /// <summary>Opens a file in a given format regardless of its name (the format travels in the location).</summary>
    public static Location ForFile(string filePath, ArchiveKind? kind = null) =>
        new(Schemes.Archive, string.Empty, Location.FileSystem(filePath), kind?.ToString());

    /// <summary>ZIP members of these archives open through the ZIP provider.</summary>
    private IContainerDetector? Zip => _providers.TryGet(Schemes.Zip, out var p) ? p as IContainerDetector : null;

    // ---- Navigation --------------------------------------------------------------------------------------

    private static string DisplayArchive(Location l)
    {
        var container = l.Container ?? throw new InvalidOperationException("Archive location without its archive.");
        if (container.IsFileSystem) return PathUtil.WithUpperDrive(container.Path);
        return Path.Combine(DisplayArchive(container), container.Path.Replace('/', Path.DirectorySeparatorChar));
    }

    private static string OutermostFile(Location l)
    {
        var c = l.Container;
        while (c is not null && !c.IsFileSystem) c = c.Container;
        return c?.Path ?? throw new InvalidOperationException("Archive location without its archive.");
    }

    public override string GetDisplayPath(Location location)
    {
        var inner = location.Path.Replace('/', Path.DirectorySeparatorChar);
        return inner.Length == 0 ? DisplayArchive(location) : Path.Combine(DisplayArchive(location), inner);
    }

    public override string GetDisplayName(Location location) =>
        location.Path.Length == 0 ? Path.GetFileName(DisplayArchive(location)) : location.Path[(location.Path.LastIndexOf('/') + 1)..];

    public override Location? GetParent(Location location)
    {
        if (location.Path.Length == 0)
        {
            var container = location.Container!;
            if (container.IsFileSystem) return Location.FileSystem(Path.GetDirectoryName(container.Path) ?? container.Path);
            int at = container.Path.LastIndexOf('/');
            return container.WithPath(at < 0 ? string.Empty : container.Path[..at]);
        }
        int slash = location.Path.LastIndexOf('/');
        return location.WithPath(slash < 0 ? string.Empty : location.Path[..slash]);
    }

    public override string? GetNameInParent(Location location) => GetDisplayName(location);

    public override string GetDeviceKey(Location location) => PathUtil.GetDeviceKey(OutermostFile(location));

    public override LocationCapabilities GetCapabilities(Location location) => LocationCapabilities.Enumerate | LocationCapabilities.ReadContent |
        (!MutationState(location).Available ? LocationCapabilities.None
            // AW7: a standalone stream takes one explicit replacement (F5 of one file) or a sole-payload edit commit, nothing else.
            : IsStandaloneTarget(location) ? LocationCapabilities.TransferTarget |
                (MemberMutationProblem(location) is null ? LocationCapabilities.ExternalEdit : LocationCapabilities.None)
            : LocationCapabilities.TransferTarget | LocationCapabilities.CreateDirectory |
                (MemberMutationProblem(location) is null ? LocationCapabilities.Delete | LocationCapabilities.Rename | LocationCapabilities.ExternalEdit : LocationCapabilities.None));

    public override string ExplainUnavailable(Location location, LocationCapabilities capability) => capability switch
    {
        LocationCapabilities.CreateDirectory or LocationCapabilities.CreateFile or LocationCapabilities.Delete or LocationCapabilities.Rename or LocationCapabilities.Recycle
            when IsStandaloneTarget(location) && MutationState(location).Available => ArchiveStandalone.MemberChangesUnavailable,
        LocationCapabilities.Delete or LocationCapabilities.Rename or LocationCapabilities.ExternalEdit when MutationState(location).Available && MemberMutationProblem(location) is { } problem => problem,
        LocationCapabilities.CreateDirectory or LocationCapabilities.CreateFile or LocationCapabilities.Delete or LocationCapabilities.Rename or
            LocationCapabilities.TransferTarget or LocationCapabilities.ExternalEdit or LocationCapabilities.Recycle =>
            ReadOnlyReason(location) + " Copy (extract) members with F5 to work with them in a folder.",
        LocationCapabilities.MoveSource => "Moving members out of this archive is not supported here. Copy (extract) them with F5.",
        _ => base.ExplainUnavailable(location, capability),
    };

    public override bool TryParse(string text, Location? current, out Location? location)
    {
        location = null;
        var t = PathUtil.ExpandUserInput(text);
        if (!Path.IsPathFullyQualified(t)) return false;
        var probe = t.TrimEnd('\\', '/');
        var rest = new Stack<string>();
        while (!string.IsNullOrEmpty(probe))
        {
            if (File.Exists(probe) && IsContainer(Path.GetFileName(probe)))
            {
                location = new Location(Schemes.Archive, string.Join('/', rest), Location.FileSystem(probe));
                return true;
            }
            if (Directory.Exists(probe)) return false;
            rest.Push(Path.GetFileName(probe));
            probe = Path.GetDirectoryName(probe) ?? string.Empty;
        }
        return false;
    }

    public override Task EnumerateAsync(Location location, IEnumerationSink sink, CancellationToken ct)
    {
        var index = GetIndex(location, ct);
        if (!index.Children.TryGetValue(location.Path, out var children))
            throw new DirectoryNotFoundException($"\"{location.Path}\" does not exist in this archive.");
        var batch = new List<EntryData>(children.Count);
        var zip = Zip;
        foreach (var node in children)
        {
            ct.ThrowIfCancellationRequested();
            bool nested = node.Tag is { Kind: MemberKind.File } && (IsContainer(node.Name) || zip?.IsContainer(node.Name) == true);
            var e = new EntryData(node.Name, node.IsDirectory ? EntryKind.Directory : EntryKind.File, node.IsDirectory ? -1 : node.Size, node.Modified)
            {
                // Rows carry the listing's revision token; a member command resolves it (ArchiveListingRevision).
                Tag = index.Revision is not { } revision ? node.Tag
                    : node.Tag is { } tag ? tag with { ArchiveRevision = revision.Token, ArchiveMutationProblem = revision.Problem }
                    : new DirectoryRevision(revision.Token, revision.Problem),
                Flags = (node.Tag?.Encrypted == true ? EntryFlags.Protected : EntryFlags.None) |
                        (node.Tag is { UnsafeReason: not null } or { Kind: MemberKind.Special } ? EntryFlags.Unavailable : EntryFlags.None) |
                        (node.Tag?.Kind is MemberKind.SymbolicLink or MemberKind.HardLink ? EntryFlags.Link : EntryFlags.None) |
                        (nested ? EntryFlags.Container : EntryFlags.None),
            };
            batch.Add(e);
        }
        foreach (var warning in index.Warnings) sink.ReportIssue(warning);
        // Warning callbacks may run caller code that rewrites the source after index admission.
        // Refuse the assembled rows before publishing them if any opened archive volume changed.
        index.VerifySource();
        index.VerifyVolumePaths();
        sink.AddBatch(batch.ToArray());
        // A panel shows the rows: the revision they carry is read now, in the background (ArchiveListingRevision). An index
        // carries a revision only where writing was available when it was built, or for an edit; a search, a comparison or
        // a transfer walking the archive reads nothing more.
        if (sink.Shown && index.Revision is { Problem: null, Known: null } shown) sink.WhileShown(shown.Show(RevisionReadLimit));
        return Task.CompletedTask;
    }

    public override Location? GetChildLocation(Location parent, in EntryData entry)
    {
        if (entry.Kind == EntryKind.Parent) return GetParent(parent);
        string member = parent.Path.Length == 0 ? entry.Name : parent.Path + "/" + entry.Name;
        if (entry.Kind == EntryKind.Directory) return parent.WithPath(member);
        if (entry.Has(EntryFlags.Container) && entry.Tag is ArchiveMemberTag { UnsafeReason: null, DuplicateOrdinal: 0, Kind: MemberKind.File } tag &&
            (!tag.Encrypted || _cache.Values.Any(index => index.PasswordUnlocked && index.ContainerLocation == parent.WithPath(""))))
        {
            var at = parent.WithPath(member);
            if (Zip?.IsContainer(entry.Name) == true) return new Location(Schemes.Zip, string.Empty, at);
            return new Location(Schemes.Archive, string.Empty, at);
        }
        return null;
    }

    public override ItemRef GetItemRef(Location listing, in EntryData entry) =>
        entry.Tag is ArchiveMemberTag t
            ? new ItemRef(listing, entry.Name, entry.Kind, entry.Size, entry.Modified)
                { Ordinal = t.DuplicateOrdinal, Flags = entry.Flags, ArchiveRevision = t.ArchiveRevision, ArchiveMutationProblem = t.ArchiveMutationProblem }
            : base.GetItemRef(listing, entry);

    // ---- Content -----------------------------------------------------------------------------------------

    public override IContentSource? OpenContent(ItemRef item)
    {
        var root = item.Parent.WithPath(string.Empty);
        using var source = ArchiveFile(root, 0);
        string path = source.Path;
        // Resolve nested paths before taking the cache lock; cross-provider spool locks stay ordered.
        // Admission owns the index until extraction has copied bytes or acquired its progressive lease.
        lock (_cacheLock)
        {
            var index = GetIndex(root, source, CancellationToken.None);
            var node = index.FindFile(item.Parent.Path, item.Name, item.Ordinal);
            if (node?.Tag is not { } tag) throw new FileNotFoundException($"\"{item.Name}\" is not in the archive.");
            if (tag.Encrypted && !index.PasswordUnlocked) return null;
            if (tag.UnsafeReason is not null) throw new InvalidDataException("This member has an unsafe name: " + tag.UnsafeReason);
            if (tag.Kind is MemberKind.SymbolicLink or MemberKind.HardLink)
                throw new InvalidDataException("Links inside archives are not followed or extracted" + (tag.LinkTarget is { } target ? $" (it points to \"{target}\")." : "."));
            if (tag.Kind == MemberKind.Special) throw new InvalidDataException("Device and pipe entries have no content to extract.");
            try { return index.Extract(tag, _tempDirectory); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                // A lazy source-open refusal invalidates the index and closes its witness too. A later request
                // may retry with restored identity capability, but no failed source handle stays retained.
                try { ReleaseIndexes(path); }
                catch (Exception cleanup) { FileCat.Core.Diagnostics.AppLog.Warn("Archive index cleanup after source refusal: " + cleanup.GetType().Name); }
                throw;
            }
        }
    }

    // ---- Index ---------------------------------------------------------------------------------------------

    private ArchiveIndex GetIndex(Location location, CancellationToken ct)
    {
        var root = location.WithPath(string.Empty);
        using var source = ArchiveFile(root, 0);
        string path = source.Path;
        lock (_cacheLock) return GetIndex(root, source, ct);
    }

    private ArchiveIndex GetIndex(Location root, ArchiveSourceLease source, CancellationToken ct, ArchiveJobPassword? password = null, bool requireRevision = false)
    {
        string path = source.Path;
        var fi = new FileInfo(path);
        if (!fi.Exists) throw new FileNotFoundException("The archive no longer exists.", path);
        string? sourceIdentity = GetSourceIdentity(path);
        string identityKey = string.IsNullOrEmpty(sourceIdentity) ? Guid.NewGuid().ToString("N") : sourceIdentity;
        string key = $"{path}|{fi.Length}|{fi.LastWriteTimeUtc.Ticks}|{root.Session}|{identityKey}";
        if (_cache.TryGetValue(key, out var cached))
        {
            try
            {
                if (!cached.CanReuse) throw new IOException("The archive source has no change token for cache reuse.");
                if (password is not null && !cached.PasswordUnlocked) throw new IOException("Unlock this archive with a new reader.");
                cached.VerifySource();
                cached.VerifyVolumePaths();
                // A writable route (or an edit) after this index was built: its listings carry a revision token from now on.
                if (requireRevision || MutationState(root).Available) cached.RequireRevision(RememberRevision);
                cached.Touch();
                return cached;
            }
            catch (IOException)
            {
                if (_cache.TryRemove(key, out var changed)) changed.Dispose();
            }
        }
        Release(path);
        string displayName = Path.GetFileName(DisplayArchive(root));
        var kind = root.Session is { Length: > 0 } forced && Enum.TryParse<ArchiveKind>(forced, out var k2) ? k2
            : ArchiveFormats.ByName(displayName) ?? throw new InvalidDataException("This file is not in an archive format FileCat reads.");
        void VerifyOpened(string openedPath, Microsoft.Win32.SafeHandles.SafeFileHandle handle) =>
            OpenedSourceIdentity.RequireMatch(handle, PathUtil.SafetyComparer.Equals(path, openedPath) ? sourceIdentity : GetSourceIdentity(openedPath), GetOpenedSourceIdentity);
        FileStream? witness = null;
        ArchiveIndex? index = null;
        try
        {
            witness = ArchiveFormats.OpenShared(path, VerifyOpened);
            string? before = SourceChangeToken.FromHandle(witness.SafeFileHandle);
            IMemberReader reader;
            try { reader = password is null ? ArchiveFormats.Open(path, kind, displayName, VerifyOpened)
                    : PasswordMemberReader.Open(path, kind, password, VerifyOpened, ct); }
            catch (Exception ex) when (ex is not (OperationCanceledException or IOException or UnauthorizedAccessException or InvalidDataException or NotSupportedException))
            {
                throw new InvalidDataException("The archive cannot be read: " + ex.Message, ex);
            }
            // A multipart RAR's other files can change without changing the selected file. Capture every
            // opened volume before listing; the index will check their handles on reads and their paths on reuse.
            ArchiveIndex.VolumeWitness[] volumes;
            try
            {
                if (reader is IVolumeStreams volumeSet)
                {
                    var streams = volumeSet.VolumeStreams;
                    var paths = volumeSet.VolumePaths;
                    if (streams.Count != paths.Count) throw new InvalidDataException("The archive volume list changed while it was being opened.");
                    volumes = streams.Select((stream, i) => new ArchiveIndex.VolumeWitness(stream, paths[i],
                        SourceChangeToken.FromHandle(stream.SafeFileHandle), GetOpenedSourceIdentity(stream.SafeFileHandle))).ToArray();
                }
                else volumes = [];
            }
            catch
            {
                try { reader.Dispose(); }
                catch (Exception cleanup) { FileCat.Core.Diagnostics.AppLog.Warn("Archive volume cleanup after capture failure: " + cleanup.GetType().Name); }
                throw;
            }
            index = ArchiveIndex.Build(reader, fi.Length, ct);
            index.PasswordUnlocked = password is not null;
            index.ContainerSession = root.Session;
            index.ContainerLocation = root;
            index.SourceIdentity = sourceIdentity;
            string? after = SourceChangeToken.FromHandle(witness.SafeFileHandle);
            if (before is not null && before != after)
                throw new IOException("The archive source changed while its catalog was being built.");
            index.KeepWitness(witness, after, stableListing: before is not null);
            witness = null;
            index.KeepVolumes(volumes, GetSourceIdentity, kind == ArchiveKind.Rar ? path : null);
            // Only a token: a listing reads what it shows, never the whole archive (ArchiveListingRevision).
            if (requireRevision || MutationState(root).Available) index.RequireRevision(RememberRevision);
            index.VerifySource();
            index.VerifyVolumePaths();
            index.KeepSource(source);
            if (password is not null) index.VerifyPassword(ct);
        }
        catch
        {
            index?.Dispose();
            witness?.Dispose();
            throw;
        }
        _cache[key] = index;
        // Archives opened before are kept for going back into them: eight at most, and their indexes together within
        // RetainedIndexLimitBytes (I06: the index of a ZIP of a million members holds about 560 MiB). The two used last
        // stay whatever their size, as two panels may be showing them. An index that still feeds a viewer closes when the
        // viewer is done with it.
        while (_cache.Count > 2 && (_cache.Count > 8 || RetainedIndexBytes > RetainedIndexLimitBytes))
        {
            var oldest = _cache.Where(kv => !ReferenceEquals(kv.Value, index)).MinBy(kv => kv.Value.LastUsed);
            if (oldest.Key is null) break;
            if (_cache.TryRemove(oldest.Key, out var evicted)) evicted.Dispose();
        }
        return index;
    }

    /// <summary>What the indexes of earlier archives may hold together before the oldest go (see <see cref="GetIndex"/>).</summary>
    public long RetainedIndexLimitBytes { get; set; } = 256L << 20;

    /// <summary>The estimated size of the indexes kept now, and how many.</summary>
    public long RetainedIndexBytes => _cache.Values.Sum(i => i.EstimatedBytes);
    public int RetainedIndexes => _cache.Count;

    /// <summary>The local file holding the archive: the file itself, or a private spool of a member of another archive.</summary>
    private ArchiveSourceLease ArchiveFile(Location location, int depth)
    {
        var container = location.Container ?? throw new InvalidOperationException("Archive location without its archive.");
        if (container.IsFileSystem) return new ArchiveSourceLease(container.Path);
        if (depth >= MaxNestingDepth) throw new InvalidDataException($"Archives are nested more than {MaxNestingDepth} levels deep.");
        return OpenSpool(container);
    }

    /// <summary>
    /// A private copy of an archive member (of any provider) for reading an inner archive. It is deleted when evicted or
    /// when FileCat ends (the file is opened delete-on-close). Used for ZIPs inside these archives too.
    /// </summary>
    public string Spool(Location member)
    {
        using var source = OpenSpool(member);
        return source.Path;
    }

    public ArchiveSourceLease OpenSpool(Location member)
    {
        int slash = member.Path.LastIndexOf('/');
        var folder = member.WithPath(slash < 0 ? string.Empty : member.Path[..slash]);
        string name = member.Path[(slash + 1)..];
        var provider = _providers.For(member);
        string outer = OutermostFile(member);
        var outerInfo = new FileInfo(outer);
        string key = $"{member}|{outerInfo.Length}|{outerInfo.LastWriteTimeUtc.Ticks}|{SourceIdentityKey(outer)}|{SourceChangeKey(outer)}";
        if (FileCat.Core.State.WindowsTokenAuthority.IsHighIntegrity)
            throw new IOException("Nested archives cannot be opened while FileCat runs as administrator because they require a user-local spool.");
        lock (_spoolLock)
        {
            if (_spools.TryGetValue(key, out var existing))
            {
                existing.Used = DateTime.UtcNow;
                return existing.Acquire();
            }
            Directory.CreateDirectory(_tempDirectory);
            string spoolPath = Path.Combine(_tempDirectory, $"nested-{Guid.NewGuid():N}{Path.GetExtension(name)}");
            var holder = new FileStream(spoolPath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.Read | FileShare.Delete, 64 * 1024, FileOptions.DeleteOnClose);
            try
            {
            using var source = ProgressiveContent.Sequential(provider.OpenContent(new ItemRef(folder, name, EntryKind.File)))
                               ?? throw new NotSupportedException("The inner archive is encrypted and cannot be opened here.");
                var buffer = new byte[256 * 1024];
                long offset = 0;
                int n;
                while ((n = source.Read(offset, buffer)) > 0)
                {
                    offset += n;
                    if (offset > MaxSpooledMember) throw new InvalidDataException("The inner archive is larger than FileCat opens in place; extract it with F5.");
                    holder.Write(buffer, 0, n);
                }
                holder.Flush();
            }
            catch
            {
                holder.Dispose();
                throw;
            }
            var added = new ArchiveSpool(spoolPath, holder);
            _spools[key] = added;
            while (_spools.Count > MaxNestedSpools)
            {
                var oldest = _spools.OrderBy(kv => kv.Value.Used).First();
                if (!_spools.TryRemove(oldest.Key, out var evicted)) break;
                Exception? failure = null;
                try { Release(evicted.Path); }
                catch (Exception ex) { failure = ex; }
                try { evicted.Dispose(); }
                catch (Exception ex) when (failure is not null) { FileCat.Core.Diagnostics.AppLog.Warn("Secondary nested archive spool cleanup failure: " + ex.GetType().Name); }
                if (failure is not null) System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(failure).Throw();
            }
            return added.Acquire();
        }
    }

    public void Release(string archivePath)
    {
        lock (_cacheLock) ReleaseIndexes(archivePath);
    }

    private void ReleaseIndexes(string archivePath)
    {
        Exception? failure = null;
        foreach (var k in _cache.Keys.Where(k => k.StartsWith(archivePath + "|", PathUtil.SafetyComparison)).ToList())
        {
            if (!_cache.TryRemove(k, out var old)) continue;
            try { old.Dispose(); }
            catch (Exception ex)
            {
                if (failure is null) failure = ex;
                else FileCat.Core.Diagnostics.AppLog.Warn("Secondary archive index cleanup failure: " + ex.GetType().Name);
            }
        }
        if (failure is not null) System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(failure).Throw();
    }
}

/// <summary>The listing of one archive and its reader; extraction is serialized and bounded.</summary>
internal sealed class ArchiveIndex : IDisposable
{
    private const int MaxMemberSegments = 256;
    private const long MaxRetainedNameChars = 64L * 1024 * 1024;
    private const long MaxGeneratedDirectoryChars = 32L * 1024 * 1024;
    private sealed class IndexBudgetExceededException(string message) : IOException(message);
    private readonly object _lock = new();
    private readonly IMemberReader _reader;
    private FileStream? _witness;
    private string? _openedChangeToken;
    internal readonly record struct VolumeWitness(FileStream Stream, string Path, string? Token, string? Identity);
    private VolumeWitness[] _volumes = [];
    private Func<string, string?>? _volumePathIdentity;
    private string? _rarEntryPath;
    public void KeepVolumes(VolumeWitness[] volumes, Func<string, string?> pathIdentity, string? rarEntryPath)
    {
        _volumes = volumes;
        _volumePathIdentity = pathIdentity;
        _rarEntryPath = rarEntryPath;
    }
    public void KeepWitness(FileStream witness, string? changeToken, bool stableListing = true)
    {
        _witness = witness;
        _witnessHandle = witness.SafeFileHandle;
        _openedChangeToken = changeToken;
        _stableListing = stableListing;
    }
    private Microsoft.Win32.SafeHandles.SafeFileHandle? _witnessHandle;
    // Whether the source had a change token when its catalog was started (not only when it was finished).
    private bool _stableListing;
    // A revision read saw the archive change: this index is never reused (a refresh lists the archive anew).
    private volatile bool _stale;
    private void MarkStale() => _stale = true;
    internal bool Stale => _stale;

    public void VerifySource()
    {
        if (_stale) throw new IOException("The archive changed since it was listed.");
        // Direct readers and filesystems without a token still permit one admitted read. The provider
        // disables cache reuse when no token was captured; it cannot prove a later read is the same source.
        if (_openedChangeToken is not null && (_witness is null || SourceChangeToken.FromHandle(_witness.SafeFileHandle) != _openedChangeToken))
            throw new IOException("The archive source changed while it was being read.");
        foreach (var volume in _volumes)
            if (volume.Token is not null && SourceChangeToken.FromHandle(volume.Stream.SafeFileHandle) != volume.Token)
                throw new IOException("An archive volume changed while it was being read.");
    }
    public void VerifyVolumePaths()
    {
        // Discovery is part of the catalog: a newly added numbered part can fill a gap without changing
        // any volume that was already open. Re-enumerate only at index admission/reuse, never per byte read.
        if (_rarEntryPath is { } entryPath &&
            !Rar.RarVolumes.Of(entryPath).SequenceEqual(_volumes.Select(v => v.Path), PathUtil.SafetyComparer))
            throw new IOException("The set of archive volumes changed since its catalog was built.");
        foreach (var volume in _volumes)
            if (volume.Token is null || SourceChangeToken.FromPath(volume.Path) != volume.Token ||
                volume.Identity is { Length: > 0 } id && _volumePathIdentity!(volume.Path) != id)
                throw new IOException("An archive volume changed since its catalog was built.");
    }
    // A volume without an opened identity cannot be tied to its path on the next request. Its change token
    // guards the current open handle, but is not sufficient to authorize reuse of a multipart catalog.
    public bool CanReuse => !_stale && (!PasswordUnlocked || Volatile.Read(ref _views) >= 0) && _openedChangeToken is not null &&
        _volumes.All(volume => volume.Token is not null && volume.Identity is { Length: > 0 });
    private ArchiveSourceLease? _source;
    internal string? ContainerPath => _source?.Path;
    internal string? ContainerSession { get; set; }
    internal Location? ContainerLocation { get; set; }
    internal string? SourceIdentity { get; set; }
    internal bool PasswordUnlocked { get; set; }
    private ArchiveListingRevision? _revision;
    /// <summary>
    /// Where this archive can be written: the revision token its listings carry, read through the witness handle in the
    /// background once a listing is shown, or by the first command (ArchiveListingRevision). Null elsewhere.
    /// </summary>
    internal ArchiveListingRevision? Revision => Volatile.Read(ref _revision);

    /// <summary>Gives this index its listing revision (once; cheap: nothing is read yet). Call after the witness is kept.</summary>
    internal ArchiveListingRevision RequireRevision(Action<string, string>? resolved = null)
    {
        if (Volatile.Read(ref _revision) is { } existing) return existing;
        var handle = _witnessHandle ?? throw new InvalidOperationException("The archive witness is not kept yet.");
        string? problem = _openedChangeToken is null || !_stableListing ? "This location cannot identify a stable archive listing for member changes."
            : _volumes.Length > 1 ? "Members of a multi-volume archive are read-only."
            : !CompleteListing ? "This listing has archive warnings and cannot safely identify members for changes." : null;
        var created = new ArchiveListingRevision(handle,
            () => SourceChangeToken.Holds(SourceChangeToken.FromHandle(handle), _openedChangeToken),
            TryLease, problem, resolved, MarkStale);
        var kept = Interlocked.CompareExchange(ref _revision, created, null) ?? created;
        if (_closing || _closed) kept.Close();
        return kept;
    }

    /// <summary>Keeps this index's archive open until disposed, even if the cache drops the index meanwhile; null once closing.</summary>
    internal IDisposable? TryLease()
    {
        lock (_lock)
        {
            if (_closing || _closed) return null;
            _leases++;
            return new IndexLease(this);
        }
    }

    private sealed class IndexLease(ArchiveIndex owner) : IDisposable
    {
        private ArchiveIndex? _owner = owner;
        public void Dispose()
        {
            if (Interlocked.Exchange(ref _owner, null) is not { } index) return;
            lock (index._lock) { if (--index._leases == 0 && index._closing && index.ViewCount == 0) index.Close(); }
        }
    }
    public void KeepSource(ArchiveSourceLease source) => _source = source.Retain();
    private readonly long _archiveLength;

    public sealed record Node(string Name, bool IsDirectory, long Size, long Modified, ArchiveMemberTag? Tag);

    private ArchiveIndex(IMemberReader reader, long archiveLength, Dictionary<string, List<Node>> children, List<string> warnings, long estimatedBytes)
    {
        _reader = reader;
        _archiveLength = archiveLength;
        Children = children;
        Warnings = warnings;
        EstimatedBytes = estimatedBytes;
        LastUsed = DateTime.UtcNow;
    }

    /// <summary>
    /// What this index holds in memory, estimated: FileCat's node and tag per member, and their names. Measured with
    /// members of 30-character names in a TAR (ArchiveIndexScaleTests): 305 bytes a member at a million, 312 at 200,000.
    /// </summary>
    public long EstimatedBytes { get; }

    public void Touch() => LastUsed = DateTime.UtcNow;

    internal void VerifyPassword(CancellationToken ct)
    {
        lock (_lock)
        {
            ct.ThrowIfCancellationRequested();
            // Header encryption is checked while opening. Data-only protection also needs an actual
            // bounded, checksum-verified member read before the tab accepts this password.
            var tag = Children.Values.SelectMany(nodes => nodes).Select(node => node.Tag)
                .FirstOrDefault(tag => tag is { Encrypted: true, Kind: MemberKind.File });
            if (tag is not null)
            {
                if (_reader is PasswordMemberReader passwordReader && !passwordReader.SupportsPasswordRead(tag.Index))
                    throw new NotSupportedException("Password reading for this older RAR encryption format is not implemented.");
                using var stream = new DamageReportingStream(_reader.Open(tag.Index, ct));
                var limits = MemberLimits.Of(tag.Size, tag.CompressedSize > 0 ? tag.CompressedSize : _archiveLength,
                    ArchiveProvider.MaxSpooledMember, ArchiveProvider.MaxExpansionRatio);
                (limits with { MaxLength = Math.Min(limits.MaxLength, ArchiveProvider.MaxSpooledMember) }).CopyAll(stream, Stream.Null, ct);
            }
            VerifySource(); VerifyVolumePaths(); ct.ThrowIfCancellationRequested();
        }
    }

    private int _views;
    internal int ViewCount => Math.Max(0, Volatile.Read(ref _views));
    internal bool AcquireView()
    {
        while (true)
        {
            int previous = Volatile.Read(ref _views);
            if (previous < 0) return false;
            if (Interlocked.CompareExchange(ref _views, previous + 1, previous) == previous) return true;
        }
    }
    internal int ReturnView()
    {
        while (true)
        {
            int previous = Volatile.Read(ref _views);
            if (previous <= 0) throw new InvalidOperationException("Unbalanced archive password view.");
            int next = previous == 1 ? -1 : previous - 1; // Last close cannot race a new runtime grant.
            if (Interlocked.CompareExchange(ref _views, next, previous) == previous) return Math.Max(0, next);
        }
    }

    public Dictionary<string, List<Node>> Children { get; }

    private Dictionary<(string Folder, string Name, int Ordinal), Node>? _files;

    /// <summary>
    /// A file member by folder, name, and duplicate ordinal. The lookup is built on first use, so extracting a folder of
    /// many members does not search the folder's list once per member.
    /// </summary>
    public Node? FindFile(string folder, string name, int ordinal) =>
        LazyInitializer.EnsureInitialized(ref _files, () =>
        {
            var files = new Dictionary<(string, string, int), Node>();
            foreach (var (path, nodes) in Children)
                foreach (var node in nodes)
                    if (!node.IsDirectory) files.TryAdd((path, node.Name, node.Tag?.DuplicateOrdinal ?? 0), node);
            return files;
        }).GetValueOrDefault((folder, name, ordinal));

    public List<string> Warnings { get; }
    internal bool CompleteListing { get; private init; }
    public DateTime LastUsed { get; private set; }
    public string Format => _reader.Format;

    public static ArchiveIndex Build(IMemberReader reader, long archiveLength, CancellationToken ct)
    {
        var warnings = new List<string>();
        var children = new Dictionary<string, List<Node>>(StringComparer.Ordinal) { [string.Empty] = [] };
        var dirs = new HashSet<string>(StringComparer.Ordinal) { string.Empty };
        var seen = new Dictionary<string, int>(StringComparer.Ordinal);
        long directoryChars = 0;
        long directoryCount = 0;
        void EnsureDir(string dir, long modified = 0)
        {
            // A single archive name can contain thousands of segments. Its depth must not consume the call stack.
            var missing = new Stack<string>();
            for (string current = dir; dirs.Add(current);)
            {
                if (current.Length > MaxGeneratedDirectoryChars - directoryChars)
                    throw new IndexBudgetExceededException("The archive's generated directory paths exceed FileCat's index budget.");
                directoryChars += current.Length;
                directoryCount++;
                missing.Push(current);
                int slash = current.LastIndexOf('/');
                current = slash < 0 ? string.Empty : current[..slash];
            }
            while (missing.TryPop(out var current))
            {
                int slash = current.LastIndexOf('/');
                var parent = slash < 0 ? string.Empty : current[..slash];
                children[parent].Add(new Node(slash < 0 ? current : current[(slash + 1)..], true, -1,
                    current == dir ? modified : 0, null));
                children.TryAdd(current, []);
            }
        }
        int count = 0;
        long nameChars = 0;
        try
        {
            foreach (var m in reader.List(warnings.Add, ct))
            {
                if (m.Path.Length > MaxRetainedNameChars - nameChars)
                    throw new IndexBudgetExceededException("The archive's member names exceed FileCat's index budget.");
                nameChars += m.Path.Length;
                if (++count > ArchiveProvider.MaxEntries)
                {
                    warnings.Add($"The archive has more than {ArchiveProvider.MaxEntries:N0} entries; only the first ones are listed.");
                    break;
                }
                var raw = m.Path.Replace('\\', '/');
                string? unsafeReason = null;
                if (raw.StartsWith('/') || raw.Length > 1 && raw[1] == ':') unsafeReason = "absolute path";
                var parts = raw.Split('/', StringSplitOptions.RemoveEmptyEntries).ToList();
                if (parts.Count > MaxMemberSegments)
                    throw new IndexBudgetExceededException("An archive member has too many path components to index safely.");
                if (parts.Any(p => p == "..")) unsafeReason = "\"..\" path traversal";
                parts.RemoveAll(p => p is "." or "..");
                if (parts.Count == 0) continue;
                long modified = m.ModifiedUtc?.Ticks ?? 0;
                var parent = string.Join('/', parts.Take(parts.Count - 1));
                EnsureDir(parent);
                if (m.Kind == MemberKind.Directory)
                {
                    EnsureDir(string.Join('/', parts), modified);
                    continue;
                }
                var name = parts[^1];
                if (Core.Jobs.SafeNames.Validate(name) is { } bad) unsafeReason ??= bad;
                var key = parent + "/" + name;
                int ordinal = seen.TryGetValue(key, out var n) ? n + 1 : 0;
                seen[key] = ordinal;
                var tag = new ArchiveMemberTag(m.Path, m.Index, m.Size, m.CompressedSize, m.Encrypted, ordinal, unsafeReason, m.Kind, m.LinkTarget);
                children[parent].Add(new Node(name, false, m.Size, modified, tag));
            }
        }
        catch (Exception ex) when (ex is not (OperationCanceledException or IndexBudgetExceededException) && count > 0)
        {
            // Damage after some members (any engine's error type): what was listed stays usable.
            warnings.Add("The archive is damaged after the members listed: " + ex.Message);
        }
        catch (Exception ex) when (ex is not (OperationCanceledException or IOException or UnauthorizedAccessException or InvalidDataException))
        {
            CloseAfterFailure();
            throw new InvalidDataException("The archive cannot be read: " + ex.Message, ex);
        }
        catch
        {
            CloseAfterFailure();
            throw;
        }
        void CloseAfterFailure()
        {
            try { reader.Dispose(); }
            catch (Exception ex) { FileCat.Core.Diagnostics.AppLog.Warn("Archive cleanup after listing failure: " + ex.GetType().Name); }
        }

        bool completeListing = warnings.Count == 0;
        if (seen.Values.Any(v => v > 0)) warnings.Add("The archive contains duplicate names; each copy is listed separately.");
        // Include the retained ancestor strings and directory-node overhead, even when the archive
        // has only one member with many path segments.
        return new ArchiveIndex(reader, archiveLength, children, warnings,
            count * 201L + nameChars * 4 + directoryChars * 2 + directoryCount * 160) { CompleteListing = completeListing };
    }

    /// <summary>
    /// Opens one member. Small ones, and ones whose size the format does not tell, are extracted at once (into memory, or
    /// privately spooled); larger ones are decompressed as they are read (<see cref="ProgressiveContent"/>), so the first
    /// bytes are there at once. Sizes are never trusted.
    /// </summary>
    public IContentSource Extract(ArchiveMemberTag tag, string tempDirectory)
    {
        LastUsed = DateTime.UtcNow;
        lock (_lock)
        {
            VerifySource();
            if (_closing && _leases == 0) throw new IOException("The archive was closed; open it again.");
            long declared = tag.Size;
            var limits = MemberLimits.Of(declared, tag.CompressedSize > 0 ? tag.CompressedSize : _archiveLength, ArchiveProvider.MaxSpooledMember,
                ArchiveProvider.MaxExpansionRatio);
            if (declared > ArchiveProvider.MaxMemberInMemory)
            {
                _leases++;
                ProgressiveContent? content = null;
                content = new ProgressiveContent(tag.FullName, _lock, () => new DamageReportingStream(OpenFor(content, tag.Index)), limits,
                    ArchiveProvider.MaxSpooledMember, tempDirectory, () => Returned(content!), VerifySource);
                return content;
            }
            Stream dst;
            if (declared >= 0) dst = new MemoryStream((int)declared);
            else
            {
                if (FileCat.Core.State.WindowsTokenAuthority.IsHighIntegrity)
                    throw new IOException("This archive member has no declared size and cannot be viewed safely while FileCat runs as administrator.");
                Directory.CreateDirectory(tempDirectory);
                string spoolPath = Path.Combine(tempDirectory, $"member-{Guid.NewGuid():N}.tmp");
                dst = new FileStream(spoolPath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.Read | FileShare.Delete, 1, FileOptions.DeleteOnClose);
            }
            try
            {
                using var src = new DamageReportingStream(OpenFor(null, tag.Index));
                limits.CopyAll(src, dst);
                VerifySource();
            }
            catch (Exception ex)
            {
                dst.Dispose();
                if (ex is IOException or InvalidDataException or UnauthorizedAccessException) throw;
                throw new InvalidDataException("The member could not be decompressed: " + ex.Message, ex);
            }
            if (dst is MemoryStream ms)
            {
                // Keep the exact logical member length without copying its entire extraction buffer.
                // A damaged size may expand the stream geometrically; trim a substantially oversized buffer.
                if (ms.Capacity - ms.Length > MemberLimits.Slack)
                    return new MemoryContentSource(tag.FullName, ms.ToArray());
                return new MemoryContentSource(tag.FullName,
                    new ArraySegment<byte>(ms.GetBuffer(), 0, checked((int)ms.Length)));
            }
            dst.Position = 0;
            return new StreamContentSource(tag.FullName, (FileStream)dst);
        }
    }

    // The progressively read member that holds a shared forward cursor (compressed TAR, 7z, solid RAR, single files).
    private ProgressiveContent? _cursorOwner;

    /// <summary>
    /// A member's stream (under the lock). Where members share one forward cursor, opening one invalidates the stream
    /// handed out before, so the member that held it gives it up first and reopens it when it needs more.
    /// </summary>
    private Stream OpenFor(ProgressiveContent? content, int index)
    {
        if (_cursorOwner is { } previous && !ReferenceEquals(previous, content)) previous.Abandon();
        _cursorOwner = _reader.SharesCursor ? content : null;
        return _reader.Open(index, CancellationToken.None);
    }

    // Members being read keep the archive open: an index dropped from the cache closes when the last one is disposed.
    private int _leases;
    private bool _closing;

    private void Returned(ProgressiveContent content)
    {
        lock (_lock)
        {
            if (ReferenceEquals(_cursorOwner, content)) _cursorOwner = null;
            if (--_leases == 0 && _closing && ViewCount == 0) Close();
        }
    }

    public void Dispose()
    {
        ArchiveListingRevision? revision;
        lock (_lock)
        {
            if (_closed) return;
            _closing = true;
            revision = Volatile.Read(ref _revision);
            if (_leases == 0 && ViewCount == 0) Close();
        }
        // Outside the index lock (the revision takes its own lock, then this one for a lease): a revision read nothing waits
        // for stops at its next block and returns its lease, and the archive then closes.
        revision?.Close();
    }
    private void Close()
    {
        if (_closed) return;
        _closed = true;
        Exception? failure = null;
        void CloseOne(Action action, string name)
        {
            try { action(); }
            catch (Exception ex)
            {
                if (failure is null) failure = ex;
                else FileCat.Core.Diagnostics.AppLog.Warn("Secondary archive " + name + " cleanup failure: " + ex.GetType().Name);
            }
        }
        CloseOne(_reader.Dispose, "reader");
        CloseOne(() => Interlocked.Exchange(ref _witness, null)?.Dispose(), "witness");
        CloseOne(() => Interlocked.Exchange(ref _source, null)?.Dispose(), "source");
        if (failure is not null) System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(failure).Throw();
    }
    private bool _closed;
}

/// <summary>
/// Reports a decompressor's own error types as damage (<see cref="InvalidDataException"/>), which every reader of
/// content handles; I/O errors and cancellation pass through.
/// </summary>
internal sealed class DamageReportingStream(Stream inner) : Stream
{
    public override bool CanRead => true;
    public override bool CanSeek => inner.CanSeek;
    public override bool CanWrite => false;
    public override long Length => inner.Length;
    public override long Position { get => inner.Position; set => inner.Position = value; }

    public override int Read(byte[] buffer, int offset, int count) => Read(buffer.AsSpan(offset, count));

    public override int Read(Span<byte> buffer)
    {
        try
        {
            return inner.Read(buffer);
        }
        catch (Exception ex) when (ex is not (IOException or InvalidDataException or OperationCanceledException or ObjectDisposedException or UnauthorizedAccessException))
        {
            throw new InvalidDataException("The member could not be decompressed: " + ex.Message, ex);
        }
    }

    public override long Seek(long offset, SeekOrigin origin) => inner.Seek(offset, origin);
    public override void Flush() { }
    public override void SetLength(long value) => throw new NotSupportedException();
    public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();

    protected override void Dispose(bool disposing)
    {
        if (disposing) inner.Dispose();
        base.Dispose(disposing);
    }
}
