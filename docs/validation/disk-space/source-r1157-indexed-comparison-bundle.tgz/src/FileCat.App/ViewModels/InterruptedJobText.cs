using FileCat.App.Services;
using FileCat.Core.Jobs;
using FileCat.Core.Resources;

namespace FileCat.App.ViewModels;

/// <summary>Wording shared by both reviews of an interrupted operation: Operations' review and Run again.</summary>
internal static class InterruptedJobText
{
    /// <summary>Up to <paramref name="max"/> bullet lines, then how many more there are.</summary>
    public static string Bullets(IReadOnlyList<string> items, int max = 10) =>
        string.Join("\n", items.Take(max).Select(i => "• " + Formatters.SafeName(i))) + (items.Count > max ? $"\n• … and {items.Count - max:N0} more" : string.Empty);

    public static string TransferReview(JobKind kind, Location destination, IReadOnlyList<ItemRef> sources, string? newName,
        TransferOptions options, QueueMode mode, bool continuing)
    {
        string mapping = Bullets(sources.Select(item =>
        {
            string folder = options.Flatten || string.IsNullOrEmpty(item.RelativeFolder)
                ? destination.Path : RelativeFolders.Resolve(destination.Path, item.RelativeFolder);
            return item.FileSystemPath + " → " + Path.Combine(folder, sources.Count == 1 && newName is { Length: > 0 } ? newName : item.Name);
        }).ToArray(), max: RecoverableTransferIntent.RootLimit);
        string conflict = options.Conflicts switch
        {
            ConflictPolicy.Skip => "Skip existing files" + (continuing ? " (recovery policy)" : ""),
            ConflictPolicy.Replace => "Replace existing files",
            ConflictPolicy.ReplaceIfNewer => "Replace only if newer",
            ConflictPolicy.KeepBothRenameIncoming => "Keep both; rename the incoming item",
            ConflictPolicy.KeepBothRenameExisting => "Keep both; rename the existing item",
            _ => "Ask about each conflict",
        };
        return $"\n\nDestination: {Formatters.SafeName(destination.Path)}" +
            $"\nFiles matching: {(options.Filter is null ? "All files" : Formatters.SafeName(options.Filter.Text))}" +
            (options.Filter is null ? "" : "\nResolved matching rules: " + Formatters.SafeName(options.Filter.ResolvedDescription)) +
            $"\nFolder layout: {(options.Flatten ? "Put selected roots directly into the destination" : "Keep recorded relative folders")}" +
            $"\nVerification: {(options.Verify == VerifyMode.ReadBack ? "Read back and compare copied content" : "Size and metadata")}" +
            $"\nTimestamps: {(options.PreserveTimestamps ? "Preserve" : "Do not preserve")} · Attributes: {(options.PreserveAttributes ? "Preserve" : "Do not preserve")}" +
            $"\nSpeed limit: {(options.RateLimit == 0 ? "Unlimited" : options.RateLimit.ToString("N0") + " bytes/s")} · Start: {(mode == QueueMode.Queue ? "Queue" : "Now")}" +
            $"\nExisting items: {conflict}." +
            (options.Conflicts == ConflictPolicy.Skip
                ? " Existing files are kept; skipping does not verify their contents. Existing folders can receive missing descendants. Same-item aliases and incompatible file/folder types still use the existing safe decisions."
                : " Existing folders can receive missing descendants; conflicts are resolved using the policy just selected.") +
            (kind == JobKind.Move ? " A skipped destination does not authorize deleting a remaining source." : "") +
            "\n\nSource → destination mapping for every available root:\n" + mapping;
    }

    public static IReadOnlyList<string> ApprovalHighlights(JobKind kind, Location destination,
        IReadOnlyList<ItemRef> sources, int recordedSources, string? newName,
        TransferOptions options, QueueMode mode, bool newTransfer)
    {
        string action = (newTransfer ? "Start a new " : "Continue the recorded ") +
            (kind == JobKind.Move ? "move" : "copy");
        string conflict = options.Conflicts switch
        {
            ConflictPolicy.Skip => "Skip existing files",
            ConflictPolicy.Replace => "Replace existing files",
            ConflictPolicy.ReplaceIfNewer => "Replace only if newer",
            ConflictPolicy.KeepBothRenameIncoming => "Keep both; rename incoming",
            ConflictPolicy.KeepBothRenameExisting => "Keep both; rename existing",
            _ => "Ask about each conflict",
        };
        var highlights = new List<string>
        {
            $"Action: {action} · {sources.Count:N0} of {recordedSources:N0} recorded source roots available",
            $"Destination: {Formatters.SafeName(destination.Path)}",
            $"Files matching: {(options.Filter is null ? "All files" : Formatters.SafeName(options.Filter.Text))}",
            $"Existing items: {conflict} · Verification: {(options.Verify == VerifyMode.ReadBack ? "Read back copied content" : "Size and metadata")}",
            $"Start: {(mode == QueueMode.Queue ? "Queue" : "Now")}",
        };
        if (sources.Count == 1)
        {
            var item = sources[0];
            string name = newName is { Length: > 0 } ? newName : item.Name;
            string target = options.Flatten || string.IsNullOrEmpty(item.RelativeFolder)
                ? name : Path.Combine(item.RelativeFolder, name);
            highlights.Insert(2, $"Source → target name: {Formatters.SafeName(item.Name)} → {Formatters.SafeName(target)}");
        }
        return highlights;
    }

    public static IReadOnlyList<string> ApprovalWarnings(JobKind kind, int availableSources,
        int recordedSources, TransferOptions options, bool newTransfer, int partialFiles,
        int unreviewedStaged, int differingCopies, bool reviewLimited)
    {
        var warnings = new List<string>();
        if (newTransfer)
            warnings.Add("Original mapping and options are incomplete; this starts a newly reviewed transfer");
        if (availableSources < recordedSources)
            warnings.Add($"{Formatters.Plural(recordedSources - availableSources, "unavailable recorded source root", "unavailable recorded source roots")} will be omitted");
        if (partialFiles > 0)
            warnings.Add($"First delete {Formatters.Plural(partialFiles, "interrupted partial file", "interrupted partial files")}");
        switch (options.Conflicts)
        {
            case ConflictPolicy.Skip:
                warnings.Add("Skipped existing files are kept, and their contents are not verified");
                break;
            case ConflictPolicy.Replace:
                warnings.Add("Existing destination files may be replaced");
                break;
            case ConflictPolicy.ReplaceIfNewer:
                warnings.Add("Existing destination files may be replaced when the source is newer");
                break;
            case ConflictPolicy.KeepBothRenameExisting:
                warnings.Add("Existing destination items may be renamed to keep both copies");
                break;
        }
        if (kind == JobKind.Move)
        {
            warnings.Add("Successfully moved source items are removed from their original location");
            if (options.Conflicts == ConflictPolicy.Skip)
                warnings.Add("A skipped destination does not authorize deleting its remaining source");
        }
        if (unreviewedStaged > 0)
            warnings.Add($"Manual review: {Formatters.Plural(unreviewedStaged, "staged file", "staged files")} could not be fully checked");
        if (differingCopies > 0)
            warnings.Add($"Manual review: {Formatters.Plural(differingCopies, "copied file differs", "copied files differ")} from the source");
        if (reviewLimited)
            warnings.Add("Review limit reached; other affected files may be unknown");
        return warnings;
    }

    /// <summary>
    /// What recovery leaves as it is, as paragraphs to append (empty when there is nothing to say): files that differ from
    /// their source in a way an interrupted copy does not explain are never deleted (release issue I19).
    /// </summary>
    public static string CopyNotes(CopyReview review)
    {
        var text = string.Empty;
        if (review.Differing.Count > 0)
            text += $"\n\n{Formatters.Plural(review.Differing.Count, "file this operation may have copied differs", "files this operation may have copied differ")} from the source but not as a copy cut short does (changed since, or its source changed since). FileCat leaves them as they are; compare them with their sources yourself:\n"
                + Bullets(review.Differing);
        if (review.LimitReached)
            text += "\n\nNot every file this operation copied could be checked or listed here; after this, compare the destination with the source.";
        return text;
    }
}
