using FileCat.Core.Resources;
using FileCat.Core.Verification;

namespace FileCat.App.ViewModels;

/// <summary>Checksums and signatures beside files (D-57): which rows have them, what each row's check found, and the folder's sum.</summary>
public sealed partial class TabViewModel
{
    /// <summary>Folders with more entries than this are not searched for checksum files (a manifest there is still checked on request).</summary>
    private const int SidecarScanLimit = 200_000;
    private bool _hasSidecars;
    private string? _verificationSummary;
    private bool _summaryRunning, _summaryAgain;

    /// <summary>Whether this folder holds checksum files or signatures: only then do its rows ask what they verify.</summary>
    public bool HasSidecars => _hasSidecars;

    /// <summary>After a load: whether the folder has sidecars (from the names; nothing is read), and the service told to look again.</summary>
    private void NoteSidecars()
    {
        bool had = _hasSidecars;
        _hasSidecars = false;
        _verificationSummary = null;
        if (Location is not { IsFileSystem: true } location || Listing.Store.Count > SidecarScanLimit) return;
        var store = Listing.Store;
        int count = store.Count;
        for (int i = 0; i < count && !_hasSidecars; i++)
        {
            var e = store[i];
            _hasSidecars = e.Kind == EntryKind.File && SidecarNames.IsSidecar(e.Name);
        }
        if (!_hasSidecars || VerificationService.Current is not { } service) return;
        string folder = location.Path;
        // The metadata key uses size and mtime. A writer can restore both, so a refreshed
        // listing must retire its prior good mark before the service returns historical status.
        Services.Metadata.ForgetFolder("verified", folder);
        // A refresh may be about a changed checksum file: the service reads them again, and a change makes the shown results stale.
        if (had) _ = Task.Run(() =>
        {
            try { service.FolderChanged(folder, CancellationToken.None); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
        });
        RefreshVerificationSummary();
    }

    /// <summary>
    /// What a file beside checksum files or signatures shows while FileCat runs elevated, where it checks no file by
    /// itself: not checked, rather than the empty cell of a file nothing covers, also where its checksum says it differs
    /// (review finding P8 of f134ba37).
    /// </summary>
    internal static readonly VerificationResult Elevated = new(VerificationState.NotChecked, "not checked (elevated)",
        ["FileCat runs as administrator and checks no file by itself.", "File → Verify checks this file now."]);

    /// <summary>
    /// A row's check, once known (null for rows nothing covers, and while it is worked out): asked of the metadata
    /// service, which checks visible rows in the background on their device's queue.
    /// </summary>
    public VerificationResult? Verification(in EntryData e, int storeIndex)
    {
        if (!_hasSidecars || e.Kind != EntryKind.File || Location is not { IsFileSystem: true } location) return null;
        if (Core.State.WindowsTokenAuthority.IsHighIntegrity) return Elevated;
        var store = Listing.Store;
        string path = Path.Join(location.Path, e.Name);
        string device = Services.Providers.For(location).GetDeviceKey(location);
        var value = Services.Metadata.Get("verified", path, e, device, IsSlowLocation, () => ReferenceEquals(store, Listing.Store) && VisibleStoreIndices.Contains(storeIndex));
        var result = value.State == Core.Metadata.MetadataState.Available ? value.Value as VerificationResult : null;
        if (result is { Settling: true }) AskAgainWhenStill(path);
        return result;
    }

    private readonly HashSet<string> _settling = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>A file changed a moment ago (it may be being written): its row asks again once it has been still.</summary>
    private void AskAgainWhenStill(string path)
    {
        if (VerificationService.Current is not { } service || !_settling.Add(path)) return;
        _ = Task.Delay(service.Settle + TimeSpan.FromMilliseconds(250)).ContinueWith(_ => Services.Ui.Post(() =>
        {
            _settling.Remove(path);
            if (!_disposed) Services.Metadata.Forget("verified", path);
        }), TaskScheduler.Default);
    }

    /// <summary>The focused file's result for the status line (" · ✓ SHA-256 · signed by …"), once known.</summary>
    private string FocusedVerification(in EntryData e, int storeIndex) =>
        _hasSidecars && Verification(e, storeIndex) is { Text.Length: > 0 } r ? " · " + r.Text : string.Empty;

    /// <summary>The words for a row's tooltip: what its check found and why, and when (a kept result is not read again).</summary>
    public string? VerificationTip(in EntryData e, int storeIndex)
    {
        if (Verification(e, storeIndex) is not { } r || r.Text.Length == 0 && r.Details.Count == 0) return null;
        var lines = new List<string> { r.Text };
        lines.AddRange(r.Details);
        if (r.CheckedUtc is { } at)
            lines.Add($"Checked {at.ToLocalTime().ToString("g", System.Globalization.CultureInfo.CurrentCulture)}; File → Verify checksums and signatures reads it again.");
        return string.Join("\n", lines);
    }

    /// <summary>
    /// The folder's results so far for the status line, worked out off the UI thread from the kept results (UI thread). A
    /// request while one is under way runs again after it: results that arrived meanwhile are counted.
    /// </summary>
    internal void RefreshVerificationSummary()
    {
        if (!_hasSidecars || Location is not { IsFileSystem: true } location || VerificationService.Current is not { } service) return;
        if (_summaryRunning)
        {
            _summaryAgain = true;
            return;
        }
        _summaryRunning = true;
        var store = Listing.Store;
        int count = store.Count;
        var names = new List<string>(Math.Min(count, SidecarScanLimit));
        for (int i = 0; i < count; i++)
            if (store[i] is { Kind: EntryKind.File } e) names.Add(e.Name);
        string folder = location.Path;
        _ = Task.Run(() =>
        {
            string? text = null;
            try
            {
                var (good, bad, unknown, notChecked, historical) = service.Summary(folder, names);
                // Worst first.
                var parts = new List<string>();
                if (bad > 0) parts.Add($"{bad} failed");
                if (unknown > 0) parts.Add($"{unknown} unsure");
                if (good > 0) parts.Add($"{good} verified");
                if (historical > 0) parts.Add($"{historical} previously checked");
                if (notChecked > 0) parts.Add($"{notChecked} not checked");
                text = parts.Count > 0 ? "checksums: " + string.Join(", ", parts) : null;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException) { }
            finally
            {
                Services.Ui.Post(() =>
                {
                    _summaryRunning = false;
                    if (_disposed) return;
                    if (ReferenceEquals(store, Listing.Store))
                    {
                        _verificationSummary = text;
                        UpdateStatus();
                    }
                    if (_summaryAgain)
                    {
                        _summaryAgain = false;
                        RefreshVerificationSummary();
                    }
                });
            }
        });
    }
}
