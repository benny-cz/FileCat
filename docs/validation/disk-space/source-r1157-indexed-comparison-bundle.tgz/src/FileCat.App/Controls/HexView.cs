using System.Globalization;
using System.Text;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Threading;
using FileCat.App.Services;
using FileCat.Core.Content;

namespace FileCat.App.Controls;

/// <summary>
/// Hex view over a <see cref="PagedReader"/> (plan §13.1): opens without scanning, addresses 64-bit offsets,
/// draws only visible rows, and never blocks the UI thread on I/O (missing bytes show as "··" until loaded).
/// </summary>
public sealed class HexView : Control
{
    private const int MinimumBytesPerRow = 4;
    private const int MaximumBytesPerRow = 128;
    private int _bytesPerRow = 16;
    public int BytesPerRow => _bytesPerRow;
    internal long TopByteOffset => _topRow * _bytesPerRow;
    private readonly ScrollBar _vbar, _hbar;
    private readonly WheelRowAccumulator _wheelRows = new();
    private double _horizontalOffset;
    private Size _viewportSize;
    private bool _updatingScroll;
    private PagedReader? _reader;
    private long _topRow;
    private long _cursor;
    private long _anchor = -1;
    private IPointer? _selectionPointer;
    private Typeface _typeface = new(new FontFamily("Cascadia Mono,Consolas,Menlo,DejaVu Sans Mono,monospace"));
    private double _fontSize = 13;
    private double _charWidth = 8;
    private double _rowHeight = 18;
    private Action? _pageLoaded;
    private long _readerGeneration;
    private string _committedValue = "No content", _editingState = "Read-only inspection";
    private IBrush _text = Brushes.Black, _muted = Brushes.Gray, _selection = Brushes.LightBlue, _selectionText = Brushes.Black, _hitText = Brushes.Black, _modifiedText = Brushes.Black, _cursorBrush = Brushes.Blue, _bg = Brushes.White, _hit = Brushes.Yellow, _modified = Brushes.Orange;
    private (long Start, long Length)? _highlight;

    public HexView()
    {
        Focusable = true;
        ClipToBounds = true;
        CursorMoved += RefreshSemanticState;
        _vbar = new ScrollBar { Orientation = Avalonia.Layout.Orientation.Vertical, AllowAutoHide = false };
        _hbar = new ScrollBar { Orientation = Avalonia.Layout.Orientation.Horizontal, AllowAutoHide = false };
        Avalonia.Automation.AutomationProperties.SetName(_vbar, "Hex vertical position");
        Avalonia.Automation.AutomationProperties.SetName(_hbar, "Hex horizontal position");
        _vbar.PropertyChanged += (_, e) =>
        {
            if (e.Property == RangeBase.ValueProperty && !_updatingScroll && _reader is not null)
            {
                _wheelRows.Reset();
                long top = (long)Math.Round(_vbar.Value);
                if (top != _topRow)
                {
                    _topRow = top;
                    RefreshSemanticState();
                    InvalidateVisual();
                }
            }
        };
        VisualChildren.Add(_vbar);
        LogicalChildren.Add(_vbar);
        _hbar.PropertyChanged += (_, e) =>
        {
            if (e.Property != RangeBase.ValueProperty || _updatingScroll) return;
            _horizontalOffset = _hbar.Value;
            RefreshSemanticState();
            InvalidateVisual();
        };
        VisualChildren.Add(_hbar);
        LogicalChildren.Add(_hbar);
        PointerCaptureLost += (_, _) => _selectionPointer = null;
    }

    public event Action? CursorMoved;
    /// <summary>Optional sparse edit marker; queried only for visible bytes.</summary>
    public Func<long, bool>? IsModified { get; set; }

    /// <summary>Editing: the high nibble typed at the cursor, shown as "A_" until the low nibble arrives (-1: none).</summary>
    public int PendingNibble
    {
        get => _pendingNibble;
        set
        {
            if (_pendingNibble == value) return;
            _pendingNibble = value;
            InvalidateVisual();
            RefreshSemanticState();
        }
    }

    /// <summary>Editing: typing goes to the text column; the cursor there is drawn as the stronger one.</summary>
    public bool TextColumnActive
    {
        get => _textColumnActive;
        set
        {
            if (_textColumnActive == value) return;
            _textColumnActive = value;
            EnsureHorizontalVisible();
            InvalidateVisual();
            CursorMoved?.Invoke();
        }
    }

    /// <summary>Clicks choose the active column (hex or text) for an editor.</summary>
    public bool TracksActiveColumn { get; set; }

    /// <summary>Describes the host's actual byte-editing eligibility without turning this descriptive Value into SetValue.</summary>
    public void SetEditingState(bool canEdit, int unsavedBytes, string? blockedReason = null)
    {
        string state = canEdit ? "Byte editing available" : "Byte editing blocked: " + (blockedReason ?? "Editing is unavailable");
        state += unsavedBytes > 0 ? $"; {unsavedBytes:N0} modified bytes, unsaved" : "; no unsaved changes";
        if (_editingState == state) return;
        _editingState = state;
        RefreshSemanticState();
    }

    private string SearchPhrase => string.IsNullOrEmpty(_searchFeedback) ? "" : $"Find: {_searchFeedback}; ";
    internal string SemanticStatus => SearchPhrase + DescribeState();
    private string? _searchFeedback;

    internal void SetSearchFeedback(string? feedback, bool announce = true)
    {
        if (_searchFeedback == feedback) return;
        _searchFeedback = feedback;
        if (announce) RefreshSemanticState();
    }
    internal double HorizontalOffset => _horizontalOffset;
    private double VerticalBarWidth => _vbar.DesiredSize.Width > 0 ? _vbar.DesiredSize.Width : 12;
    private double HorizontalBarHeight => _hbar.DesiredSize.Height > 0 ? _hbar.DesiredSize.Height : 12;
    internal Rect ContentViewport => new(0, 0, Math.Max(0, _viewportSize.Width - VerticalBarWidth), Math.Max(0, _viewportSize.Height - HorizontalBarHeight));

    private int _pendingNibble = -1;
    private bool _textColumnActive;

    public void ClearSelection()
    {
        if (_anchor < 0) return;
        _anchor = -1;
        InvalidateVisual();
        CursorMoved?.Invoke();
    }

    private HexViewAutomationPeer? _automationPeer;

    protected override Avalonia.Automation.Peers.AutomationPeer OnCreateAutomationPeer() => _automationPeer = new HexViewAutomationPeer(this);

    /// <summary>The cursor byte and its row, for assistive technology (never blocks on I/O).</summary>
    internal string DescribeCursor()
        => _committedValue;

    private string DescribeState()
    {
        var (start, length) = Selection;
        return (length > 0 ? $"Selected bytes {start:N0} through {start + length - 1:N0}, {length:N0} bytes; " : "No byte selection; ")
            + (TracksActiveColumn ? $"active typing column: {(_textColumnActive ? "text (ASCII)" : "hex")}; " : "read-only byte inspection; ")
            + (_pendingNibble >= 0 ? $"pending first nibble {_pendingNibble:X}, type the second digit; " : "")
            + _editingState + $"; viewport begins at byte {_topRow * BytesPerRow:N0}, horizontal position {_horizontalOffset:0}.";
    }

    /// <summary>Commit a bounded cached-row snapshot, then publish it. Getters and event payloads never start I/O.</summary>
    private void RefreshSemanticState()
    {
        if (_reader is null) { _committedValue = "No content"; _automationPeer?.AnnounceCursor(); return; }
        long row = _cursor / BytesPerRow * BytesPerRow;
        Span<byte> bytes = stackalloc byte[BytesPerRow];
        _reader.TryRead(row, bytes, out int n);
        int at = (int)(_cursor - row);
        var hex = string.Join(" ", bytes[..n].ToArray().Select(b => b.ToString("X2", System.Globalization.CultureInfo.InvariantCulture)));
        var value = at < n ? $"byte {bytes[at]:X2} hex" : "byte not loaded yet";
        _committedValue = SearchPhrase + $"Offset {_cursor:N0} of {_reader.Length:N0}, {value}; row {row:X8}: {hex}. " + DescribeState();
        if (_reader.ReadError is { } error) _committedValue += " Incomplete reading: " + error;
        _automationPeer?.AnnounceCursor();
    }

    public long CursorOffset => _cursor;

    public (long Start, long Length) Selection
    {
        get
        {
            if (_anchor < 0) return (_cursor, 0);
            long a = Math.Min(_anchor, _cursor), b = Math.Max(_anchor, _cursor);
            return (a, b - a + 1);
        }
    }

    public double FontSize
    {
        get => _fontSize;
        set
        {
            _wheelRows.Reset();
            _fontSize = Math.Clamp(value, 8, 32);
            Measure();
            ReflowRows();
            EnsureHorizontalVisible();
            UpdateScroll();
            RefreshSemanticState();
            InvalidateVisual();
        }
    }

    public void SetReader(PagedReader? reader)
    {
        if (_selectionPointer is { } selecting && ReferenceEquals(selecting.Captured, this)) selecting.Capture(null);
        _selectionPointer = null;
        _wheelRows.Reset();
        if (_reader is not null && _pageLoaded is not null) _reader.PageLoaded -= _pageLoaded;
        _reader = reader;
        long generation = ++_readerGeneration;
        if (reader is not null)
        {
            int queued = 0;
            _pageLoaded = () =>
            {
                if (Interlocked.Exchange(ref queued, 1) != 0) return;
                Dispatcher.UIThread.Post(() =>
                {
                    Interlocked.Exchange(ref queued, 0);
                    if (!ReferenceEquals(_reader, reader) || generation != _readerGeneration) return;
                    RefreshSemanticState(); InvalidateVisual();
                }, DispatcherPriority.Background);
            };
            reader.PageLoaded += _pageLoaded;
        }
        _topRow = 0;
        _cursor = 0;
        _anchor = -1;
        _pendingNibble = -1;
        _horizontalOffset = 0;
        Measure();
        ReflowRows();
        UpdateScroll();
        InvalidateVisual();
        RefreshSemanticState();
    }

    public void SourceChanged()
    {
        _anchor = -1; _pendingNibble = -1;
        _cursor = Math.Clamp(_cursor, 0, Math.Max(0, (_reader?.Length ?? 0) - 1));
        ReflowRows(); UpdateScroll(); RefreshSemanticState(); InvalidateVisual();
    }

    public void ContentChanged() { RefreshSemanticState(); InvalidateVisual(); }

    public void ResolveBrushes()
    {
        IBrush B(string k, IBrush f) => this.TryFindResource(k, ActualThemeVariant, out var v) && v is IBrush b ? b : f;
        _text = B("FcText", Brushes.Black);
        _muted = B("FcTextMuted", Brushes.Gray);
        _selection = B("FcFocusBackground", Brushes.LightBlue);
        _selectionText = B("FcFocusText", Brushes.Black);
        _cursorBrush = B("FcFocusBorder", Brushes.Blue);
        _bg = B("FcPanel", Brushes.White);
        _hit = B("FcSearchHit", Brushes.Yellow);
        _hitText = B("FcOnSearchHit", Brushes.Black);
        _modified = B("FcChangedByte", Brushes.Orange);
        _modifiedText = B("FcOnChangedByte", Brushes.Black);
        InvalidateVisual();
    }

    protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
    {
        base.OnAttachedToVisualTree(e);
        ThemeManager.ThemeChanged += ResolveBrushes;
        ResolveBrushes();
    }

    protected override void OnDetachedFromVisualTree(VisualTreeAttachmentEventArgs e)
    {
        ThemeManager.ThemeChanged -= ResolveBrushes;
        base.OnDetachedFromVisualTree(e);
    }

    private void Measure()
    {
        var ft = new FormattedText("0", CultureInfo.InvariantCulture, FlowDirection.LeftToRight, _typeface, _fontSize, Brushes.Black);
        _charWidth = ft.WidthIncludingTrailingWhitespace;
        _rowHeight = Math.Ceiling(_fontSize * 1.45);
    }

    private long RowCount => _reader is null ? 0 : _reader.Length / BytesPerRow + (_reader.Length % BytesPerRow > 0 ? 1 : 0);
    private int VisibleRows => Math.Max(1, (int)(ContentViewport.Height / _rowHeight));
    private int OffsetDigits => _reader is null || _reader.Length <= 0xFFFFFFFFL ? 8 : _reader.Length <= 0xFFFFFFFFFFFFL ? 12 : 16;

    /// <summary>Room left of the offsets, so they do not touch the window's edge.</summary>
    private const double Gutter = 8;

    private double HexColumnX => Gutter + (OffsetDigits + 2) * _charWidth;
    private static int HexColumn(int column) => column * 3 + column / 8;
    private int TextColumnCharacters(int bytes) => bytes * 3 + (bytes - 1) / 8 + 1;
    private double ContentWidth(int bytes) => HexColumnX + (TextColumnCharacters(bytes) + bytes) * _charWidth + Gutter;

    /// <summary>Keep the first visible byte near the top while row boundaries change.</summary>
    private bool ReflowRows()
    {
        double width = ContentViewport.Width;
        if (width <= 0 || _charWidth <= 0) return false;
        int bytes = MinimumBytesPerRow;
        for (int candidate = MinimumBytesPerRow + 4; candidate <= MaximumBytesPerRow; candidate += 4)
        {
            if (ContentWidth(candidate) > width) break;
            bytes = candidate;
        }
        if (bytes == _bytesPerRow) return false;
        long firstByte = _topRow * _bytesPerRow;
        _bytesPerRow = bytes;
        _topRow = firstByte / bytes;
        _wheelRows.Reset();
        return true;
    }

    protected override Size ArrangeOverride(Size finalSize)
    {
        _viewportSize = finalSize;
        bool reflowed = ReflowRows();
        _vbar.Arrange(new Rect(Math.Max(0, finalSize.Width - VerticalBarWidth), 0, VerticalBarWidth, ContentViewport.Height));
        _hbar.Arrange(new Rect(0, ContentViewport.Height, ContentViewport.Width, HorizontalBarHeight));
        EnsureHorizontalVisible();
        UpdateScroll();
        if (reflowed) { RefreshSemanticState(); InvalidateVisual(); }
        return finalSize;
    }

    protected override Size MeasureOverride(Size availableSize)
    {
        _vbar.Measure(availableSize);
        _hbar.Measure(availableSize);
        return new Size(double.IsInfinity(availableSize.Width) ? 600 : availableSize.Width, double.IsInfinity(availableSize.Height) ? 400 : availableSize.Height);
    }

    private void UpdateScroll()
    {
        _updatingScroll = true;
        long max = Math.Max(0, RowCount - VisibleRows);
        _topRow = Math.Clamp(_topRow, 0, max);
        _vbar.Maximum = max;
        _vbar.ViewportSize = VisibleRows;
        _vbar.LargeChange = Math.Max(1, VisibleRows - 1);
        _vbar.SmallChange = 1;
        _vbar.Value = _topRow;
        _hbar.Maximum = Math.Max(0, TextColumnX + BytesPerRow * _charWidth + Gutter - ContentViewport.Width);
        _hbar.ViewportSize = Math.Max(1, ContentViewport.Width);
        _hbar.SmallChange = _charWidth * 4;
        _hbar.LargeChange = Math.Max(_charWidth, ContentViewport.Width * .8);
        _horizontalOffset = Math.Clamp(_horizontalOffset, 0, _hbar.Maximum);
        _hbar.Value = _horizontalOffset;
        _updatingScroll = false;
    }

    public override void Render(DrawingContext dc)
    {
        dc.FillRectangle(_bg, new Rect(Bounds.Size));
        if (_reader is null) return;
        using var clip = dc.PushClip(ContentViewport);
        int digits = OffsetDigits;
        double xHex = HexColumnX - _horizontalOffset;
        double xText = TextColumnX - _horizontalOffset;
        var sel = Selection;
        var buffer = new byte[BytesPerRow];
        Span<byte> fillState = stackalloc byte[BytesPerRow];
        long len = _reader.Length;
        for (int r = 0; r <= VisibleRows; r++)
        {
            long row = _topRow + r;
            if (row >= RowCount && len > 0) break;
            long offset = row * BytesPerRow;
            if (offset >= len && len > 0 || len == 0 && r > 0) break;
            double y = r * _rowHeight;
            bool ok = _reader.TryRead(offset, buffer, out int n);
            DrawText(dc, offset.ToString("X" + digits, CultureInfo.InvariantCulture), Gutter - _horizontalOffset, y, _muted);
            var hex = new StringBuilder(BytesPerRow * 3 + 2);
            var text = new StringBuilder(BytesPerRow);
            fillState.Clear();
            for (int i = 0; i < BytesPerRow; i++)
            {
                if (i >= len - offset)
                {
                    hex.Append("   ");
                    continue;
                }
                long pos = offset + i;
                bool inSel = sel.Length > 0 && pos >= sel.Start && pos < sel.Start + sel.Length;
                bool isHit = _highlight is { } h && pos >= h.Start && pos < h.Start + h.Length;
                double bx = xHex + HexColumn(i) * _charWidth;
                double tx = xText + i * _charWidth;
                bool modified = IsModified?.Invoke(pos) == true;
                fillState[i] = inSel ? (byte)1 : isHit ? (byte)2 : modified ? (byte)3 : (byte)0;
                if (inSel || isHit || modified)
                {
                    var brush = inSel ? _selection : isHit ? _hit : _modified;
                    dc.FillRectangle(brush, new Rect(bx - 1, y, _charWidth * 2 + 2, _rowHeight));
                    dc.FillRectangle(brush, new Rect(tx, y, _charWidth, _rowHeight));
                }
                if (modified)
                {
                    // A non-color cue as well (plan PI-04): modified bytes are underlined in both columns.
                    var mark = new Pen(_text, 1.5);
                    dc.DrawLine(mark, new Point(bx, y + _rowHeight - 1.5), new Point(bx + _charWidth * 2, y + _rowHeight - 1.5));
                    dc.DrawLine(mark, new Point(tx, y + _rowHeight - 1.5), new Point(tx + _charWidth, y + _rowHeight - 1.5));
                }
                if (pos == _cursor)
                {
                    double hexPen = TracksActiveColumn && _textColumnActive ? 1 : 1.5, textPen = TracksActiveColumn && _textColumnActive ? 2 : 1;
                    dc.DrawRectangle(null, new Pen(_cursorBrush, hexPen), new Rect(bx - 1, y + 0.5, _charWidth * 2 + 2, _rowHeight - 1));
                    dc.DrawRectangle(null, new Pen(_cursorBrush, textPen), new Rect(tx, y + 0.5, _charWidth, _rowHeight - 1));
                }
                if (pos == _cursor && _pendingNibble >= 0)
                {
                    hex.Append(_pendingNibble.ToString("X", CultureInfo.InvariantCulture)).Append("_ ");
                    text.Append(i < n ? Printable(buffer[i]) : '·');
                }
                else if (i < n)
                {
                    byte b = buffer[i];
                    hex.Append(b.ToString("X2", CultureInfo.InvariantCulture)).Append(' ');
                    text.Append(Printable(b));
                }
                else
                {
                    hex.Append("·· ");
                    text.Append('·');
                }
                if (i % 8 == 7 && i + 1 < BytesPerRow) hex.Append(' ');
            }
            string hexLine = hex.ToString(), textLine = text.ToString();
            DrawText(dc, hexLine, xHex, y, ok ? _text : _muted);
            DrawText(dc, textLine, xText, y, ok ? _text : _muted);
            // Paint selected glyphs in the paired foreground. Clipping or recoloring the
            // entire row would also change neighboring, unselected bytes.
            for (int i = 0; i < textLine.Length; i++)
            {
                var foreground = fillState[i] switch
                {
                    1 => _selectionText,
                    2 => _hitText,
                    3 => _modifiedText,
                    _ => null,
                };
                if (foreground is null) continue;
                int column = HexColumn(i);
                DrawText(dc, hexLine.Substring(column, 2), xHex + column * _charWidth, y, foreground);
                DrawText(dc, textLine.Substring(i, 1), xText + i * _charWidth, y, foreground);
            }
        }
    }

    private static char Printable(byte b) => b is >= 0x20 and < 0x7F ? (char)b : b >= 0xA0 ? (char)b : '.';

    private void DrawText(DrawingContext dc, string s, double x, double y, IBrush brush)
    {
        var ft = new FormattedText(s, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, _typeface, _fontSize, brush);
        dc.DrawText(ft, new Point(x, y + (_rowHeight - ft.Height) / 2));
    }

    public void GoTo(long offset, bool select = false, long length = 0)
    {
        if (_reader is null) return;
        long max = Math.Max(0, _reader.Length - 1);
        offset = Math.Clamp(offset, 0, max);
        if (select && length > 0)
        {
            _anchor = offset;
            _cursor = offset + Math.Min(max - offset, length - 1);
        }
        else
        {
            _anchor = -1;
            _cursor = offset;
        }
        _highlight = length > 0 ? (offset, length) : null;
        EnsureVisible();
    }

    private void EnsureVisible()
    {
        long row = _cursor / BytesPerRow;
        if (row < _topRow) _topRow = row;
        else if (row >= _topRow + VisibleRows) _topRow = row - VisibleRows + 1;
        EnsureHorizontalVisible();
        UpdateScroll();
        InvalidateVisual();
        CursorMoved?.Invoke();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (_reader is null || e.Handled) return;
        if ((e.KeyModifiers & KeyModifiers.Alt) != 0 && e.Key is Key.Left or Key.Right)
        {
            _horizontalOffset += (e.Key == Key.Left ? -1 : 1) * _charWidth * 8;
            UpdateScroll(); RefreshSemanticState(); InvalidateVisual(); e.Handled = true; return;
        }
        bool shift = (e.KeyModifiers & KeyModifiers.Shift) != 0;
        bool ctrl = (e.KeyModifiers & KeyModifiers.Control) != 0;
        long len = _reader.Length;
        long target = e.Key switch
        {
            Key.Left => _cursor - 1,
            Key.Right => _cursor + Math.Min(1, Math.Max(0, len - 1 - _cursor)),
            Key.Up => _cursor - BytesPerRow,
            Key.Down => _cursor + Math.Min(BytesPerRow, Math.Max(0, len - 1 - _cursor)),
            Key.PageUp => _cursor - BytesPerRow * Math.Max(1, VisibleRows - 1),
            Key.PageDown => _cursor + Math.Min(BytesPerRow * (long)Math.Max(1, VisibleRows - 1), Math.Max(0, len - 1 - _cursor)),
            Key.Home => ctrl ? 0 : _cursor - _cursor % BytesPerRow,
            Key.End => ctrl ? len - 1 : _cursor + Math.Min(BytesPerRow - 1 - _cursor % BytesPerRow, Math.Max(0, len - 1 - _cursor)),
            _ => long.MinValue,
        };
        if (target == long.MinValue) return;
        _wheelRows.Reset();
        e.Handled = true;
        if (shift && _anchor < 0) _anchor = _cursor;
        if (!shift) _anchor = -1;
        _highlight = null;
        _cursor = Math.Clamp(target, 0, Math.Max(0, len - 1));
        EnsureVisible();
    }

    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);
        var p = e.GetPosition(this);
        if (!ContentViewport.Contains(p) || !e.GetCurrentPoint(this).Properties.IsLeftButtonPressed) return;
        long pos = HitTest(p);
        if (pos < 0) return;
        Focus();
        _textColumnActive = p.X + _horizontalOffset >= TextColumnX;
        if ((e.KeyModifiers & KeyModifiers.Shift) != 0)
        {
            if (_anchor < 0) _anchor = _cursor;
        }
        else _anchor = -1;
        _cursor = pos;
        _highlight = null;
        EnsureVisible();
        _selectionPointer = e.Pointer;
        e.Pointer.Capture(this);
    }

    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);
        // A scrollbar thumb's routed pointer movement also reaches this control.
        // Only a press begun in the byte canvas may extend a byte selection.
        if (!ReferenceEquals(e.Pointer, _selectionPointer) ||
            !ReferenceEquals(e.Pointer.Captured, this) ||
            !e.GetCurrentPoint(this).Properties.IsLeftButtonPressed) return;
        long pos = HitTest(e.GetPosition(this));
        if (pos < 0 || pos == _cursor) return;
        if (_anchor < 0) _anchor = _cursor;
        _cursor = pos;
        EnsureVisible();
    }

    protected override void OnPointerReleased(PointerReleasedEventArgs e)
    {
        base.OnPointerReleased(e);
        if (!ReferenceEquals(e.Pointer, _selectionPointer)) return;
        _selectionPointer = null;
        if (ReferenceEquals(e.Pointer.Captured, this)) e.Pointer.Capture(null);
    }

    private double TextColumnX => HexColumnX + TextColumnCharacters(BytesPerRow) * _charWidth;

    internal Rect CursorBounds(bool textColumn)
    {
        int col = (int)(_cursor % BytesPerRow);
        double x = textColumn ? TextColumnX + col * _charWidth : HexColumnX + HexColumn(col) * _charWidth - 1;
        return new Rect(x - _horizontalOffset, (_cursor / BytesPerRow - _topRow) * _rowHeight,
            textColumn ? _charWidth : _charWidth * 2 + 2, _rowHeight);
    }

    private void EnsureHorizontalVisible()
    {
        if (_reader is null || ContentViewport.Width <= 0) return;
        Rect cursor = CursorBounds(_textColumnActive);
        if (cursor.Left < Gutter) _horizontalOffset += cursor.Left - Gutter;
        else if (cursor.Right > ContentViewport.Width - Gutter) _horizontalOffset += cursor.Right - ContentViewport.Width + Gutter;
        UpdateScroll();
    }

    private long HitTest(Point p)
    {
        if (_reader is null) return -1;
        long row = _topRow + (long)(p.Y / _rowHeight);
        p = new Point(p.X + _horizontalOffset, p.Y);
        double xHex = HexColumnX;
        double xText = TextColumnX;
        int col;
        if (p.X >= xText) col = (int)((p.X - xText) / _charWidth);
        else
        {
            double rel = (p.X - xHex) / _charWidth;
            col = 0;
            for (int next = 1; next < BytesPerRow; next++)
            {
                if (rel < HexColumn(next)) break;
                col = next;
            }
        }
        col = Math.Clamp(col, 0, BytesPerRow - 1);
        return Math.Clamp(row * BytesPerRow + col, 0, Math.Max(0, _reader.Length - 1));
    }

    protected override void OnPointerWheelChanged(PointerWheelEventArgs e)
    {
        base.OnPointerWheelChanged(e);
        if ((e.KeyModifiers & KeyModifiers.Shift) != 0 || Math.Abs(e.Delta.X) > Math.Abs(e.Delta.Y))
        {
            _wheelRows.Reset();
            _horizontalOffset -= (e.Delta.X != 0 ? e.Delta.X : e.Delta.Y) * _charWidth * 4;
            UpdateScroll();
        }
        else
        {
            long maxTop = Math.Max(0, RowCount - VisibleRows);
            bool beyondEnd = e.Delta.Y > 0 && _topRow == 0 || e.Delta.Y < 0 && _topRow >= maxTop;
            if (beyondEnd) _wheelRows.Reset();
            int rows = beyondEnd ? 0 : _wheelRows.Consume(e.Delta.Y);
            long previousTop = _topRow;
            _topRow -= rows;
            UpdateScroll();
            if (rows != 0 && _topRow == previousTop) _wheelRows.Reset();
        }
        RefreshSemanticState();
        InvalidateVisual();
        e.Handled = true;
    }

    /// <summary>Selected bytes (bounded) for copy; background read.</summary>
    public byte[] ReadSelection(int max = 16 * 1024 * 1024)
    {
        if (_reader is null) return [];
        var (start, length) = Selection;
        if (length == 0) length = 1;
        var buf = new byte[(int)Math.Min(length, max)];
        int n = _reader.Read(start, buf);
        return buf[..n];
    }
}
