using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using FileCat.App.Controls;

namespace FileCat.App.Views;

/// <summary>
/// Settings → Columns: profiles in Alt+0–9 order with their columns. Widths are pixels; 0 fills the remaining
/// space. Changes apply on OK.
/// </summary>
internal sealed class ColumnProfilesEditor
{
    private sealed class Profile(string name, List<(string Key, double Width)> columns)
    {
        public string Name { get; set; } = name;
        public List<(string Key, double Width)> Columns { get; } = columns;
    }

    private readonly ColumnProfileSet _set;
    private readonly List<Profile> _profiles;
    private readonly ListBox _profileList = new() { Height = 200 };
    private readonly ListBox _columnList = new() { Height = 200 };
    private readonly TextBox _name = new();
    private readonly NumericUpDown _width = new() { Minimum = 0, Maximum = 2000, Increment = 10, FormatString = "0", MinWidth = 140 };
    private readonly ComboBox _add = new() { MinWidth = 180, ItemsSource = ColumnProfileSet.Choices.Select(c => c.Title).ToList(), SelectedIndex = 0 };
    private readonly Dictionary<string, Button> _profileActions = [];
    private readonly Dictionary<string, Button> _columnActions = [];
    private readonly Button _addButton = new() { Content = "Add" };
    /// <summary>Why the action just used stopped being available, said where the keyboard went instead.</summary>
    private readonly TextBlock _status = new() { Classes = { "muted", "small" }, TextWrapping = TextWrapping.Wrap, IsVisible = false };
    private Button? _statusFor;
    private bool _updating;
    /// <summary>Settings that cannot be saved (read-only): profiles and columns can be looked through, not changed.</summary>
    private readonly bool _readOnly;

    public ColumnProfilesEditor(ColumnProfileSet set, bool readOnly = false)
    {
        _set = set;
        _readOnly = readOnly;
        _profiles = Load(set.Profiles);
        AutomationProperties.SetName(_profileList, "Column profiles");
        AutomationProperties.SetName(_columnList, "Columns of the selected profile");
        AutomationProperties.SetName(_name, "Profile name");
        AutomationProperties.SetName(_width, "Column width in pixels, 0 fills the remaining space");
        AutomationProperties.SetName(_add, "Column to add");
        AutomationProperties.SetAutomationId(_status, "Column editor action status");
        AutomationProperties.SetLiveSetting(_status, AutomationLiveSetting.Polite);

        _profileList.SelectionChanged += (_, _) => { if (!_updating) ShowProfile(); };
        _columnList.SelectionChanged += (_, _) => { if (!_updating) ShowColumn(); };
        _add.SelectionChanged += (_, _) => UpdateActions();
        _name.TextChanged += (_, _) =>
        {
            if (_updating || Selected is not { } p) return;
            p.Name = _name.Text ?? string.Empty;
            RefreshProfiles();
        };
        _width.ValueChanged += (_, _) =>
        {
            int ci = _columnList.SelectedIndex;
            if (_updating || Selected is not { } p || ci < 0 || ci >= p.Columns.Count) return;
            p.Columns[ci] = (p.Columns[ci].Key, (double)(_width.Value ?? 0));
            RefreshColumns();
        };

        var profileButtons = Buttons(_profileActions, "profile",
            ("New", () => AddProfile(new Profile("New profile", [("name", 0), ("size", 86), ("modified", 128)]))),
            ("Duplicate", () => { if (Selected is { } p) AddProfile(new Profile(p.Name + " copy", [.. p.Columns])); }),
            ("Remove", RemoveProfile),
            ("Up", () => MoveProfile(-1)),
            ("Down", () => MoveProfile(1)));
        var restore = new Button { Content = "Restore defaults" };
        restore.Click += (_, _) =>
        {
            _profiles.Clear();
            _profiles.AddRange(Load(ColumnProfiles.Defaults));
            RefreshProfiles(select: 0);
        };
        AutomationProperties.SetName(_addButton, "Add column");
        _addButton.Click += (_, _) => AddColumn();
        var columnButtons = Buttons(_columnActions, "column",
            ("Remove", RemoveColumn),
            ("Up", () => MoveColumn(-1)),
            ("Down", () => MoveColumn(1)));

        var left = new StackPanel
        {
            Spacing = 6,
            Children = { Label("Profiles (Alt+0 is the first)"), _profileList, profileButtons, restore, Label("Name"), _name },
        };
        var right = new StackPanel
        {
            Spacing = 6,
            Children =
            {
                Label("Columns"), _columnList,
                DialogLayout.Actions(_add, _addButton),
                columnButtons,
                DialogLayout.Actions(Label("Width"), _width, Note("pixels; 0 fills the remaining space")),
                Note("Dragging a column border in a panel also stores its width here. The Name column is always kept."),
            },
        };
        View = new StackPanel { Spacing = 6, Margin = new Thickness(8), Children = { new DialogColumns(left, right), _status } };
        RefreshProfiles(select: 0);
        UpdateActions();
    }

    public Control View { get; }

    /// <summary>Where the keyboard starts when Settings opens on this page: the list of profiles.</summary>
    internal Control InitialFocus => _profileList;

    /// <summary>Selects a profile by its Alt+ number (a panel's own, when Settings opens from its column header).</summary>
    internal void SelectProfile(int profile) => RefreshProfiles(select: Math.Clamp(profile, 0, _profiles.Count - 1));

    public bool HasChanges()
    {
        var original = Load(_set.Profiles);
        return _profiles.Count != original.Count || _profiles.Where((profile, index) =>
            profile.Name != original[index].Name || !profile.Columns.SequenceEqual(original[index].Columns)).Any();
    }

    private Profile? Selected
    {
        get
        {
            int i = _profileList.SelectedIndex;
            return i >= 0 && i < _profiles.Count ? _profiles[i] : null;
        }
    }

    /// <summary>Stores the edited profiles; tabs pick them up immediately.</summary>
    public void Apply() =>
        _set.Replace(_profiles.Select((p, i) => (
            string.IsNullOrWhiteSpace(p.Name) ? $"Profile {i}" : p.Name.Trim(),
            p.Columns.Select(c => ColumnProfileSet.Create(c.Key, c.Width)).OfType<ColumnSpec>().ToArray())));

    private static List<Profile> Load(IEnumerable<(string Name, ColumnSpec[] Columns)> profiles) =>
        profiles.Select(p => new Profile(p.Name, p.Columns.Select(c => (ColumnProfileSet.KeyOf(c), c.Star ? 0d : c.Width)).ToList())).ToList();

    private void AddProfile(Profile p)
    {
        if (_profiles.Count >= ColumnProfileSet.MaxProfiles) return;
        _profiles.Add(p);
        RefreshProfiles(select: _profiles.Count - 1);
        // New and Duplicate are naming tasks; put the suggested name under the caret so
        // typing replaces it, while leaving it intact if the user accepts the suggestion.
        _name.Focus();
        _name.SelectAll();
    }

    private void RemoveProfile()
    {
        int i = _profileList.SelectedIndex;
        if (i < 0 || _profiles.Count <= 1) return;
        _profiles.RemoveAt(i);
        RefreshProfiles(select: Math.Min(i, _profiles.Count - 1));
    }

    private void MoveProfile(int delta)
    {
        int i = _profileList.SelectedIndex, k = i + delta;
        if (i < 0 || k < 0 || k >= _profiles.Count) return;
        (_profiles[i], _profiles[k]) = (_profiles[k], _profiles[i]);
        RefreshProfiles(select: k);
    }

    private void AddColumn()
    {
        if (Selected is not { } p || _add.SelectedIndex < 0) return;
        var choice = ColumnProfileSet.Choices[_add.SelectedIndex];
        if (p.Columns.Any(c => c.Key == choice.Key)) return;
        p.Columns.Add((choice.Key, choice.DefaultWidth));
        RefreshColumns(select: p.Columns.Count - 1);
    }

    private void RemoveColumn()
    {
        int i = _columnList.SelectedIndex;
        if (Selected is not { } p || i < 0 || i >= p.Columns.Count || p.Columns[i].Key == "name") return;
        p.Columns.RemoveAt(i);
        RefreshColumns(select: Math.Min(i, p.Columns.Count - 1));
    }

    private void MoveColumn(int delta)
    {
        int i = _columnList.SelectedIndex, k = i + delta;
        if (Selected is not { } p || i < 0 || k < 0 || k >= p.Columns.Count) return;
        (p.Columns[i], p.Columns[k]) = (p.Columns[k], p.Columns[i]);
        RefreshColumns(select: k);
    }

    private void RefreshProfiles(int? select = null)
    {
        _updating = true;
        int index = select ?? _profileList.SelectedIndex;
        _profileList.ItemsSource = _profiles.Select((p, i) => $"Alt+{i}   {p.Name}").ToList();
        _profileList.SelectedIndex = Math.Clamp(index, 0, _profiles.Count - 1);
        _updating = false;
        if (select is not null) ShowProfile();
        UpdateActions();
    }

    private void ShowProfile()
    {
        _updating = true;
        _name.Text = Selected?.Name ?? string.Empty;
        _updating = false;
        RefreshColumns(select: 0);
        UpdateActions();
    }

    private void RefreshColumns(int? select = null)
    {
        _updating = true;
        int index = select ?? _columnList.SelectedIndex;
        var p = Selected;
        _columnList.ItemsSource = p?.Columns.Select(c =>
        {
            var title = ColumnProfileSet.Choices.FirstOrDefault(x => x.Key == c.Key)?.Title ?? c.Key;
            return $"{title}   —   {(c.Width <= 0 ? "fills" : c.Width.ToString("0") + " px")}";
        }).ToList() ?? [];
        _columnList.SelectedIndex = p is null || p.Columns.Count == 0 ? -1 : Math.Clamp(index, 0, p.Columns.Count - 1);
        _updating = false;
        ShowColumn();
    }

    private void ShowColumn()
    {
        _updating = true;
        var p = Selected;
        int i = _columnList.SelectedIndex;
        _width.Value = p is not null && i >= 0 && i < p.Columns.Count ? (decimal)Math.Max(0, p.Columns[i].Width) : 0;
        _updating = false;
        UpdateActions();
    }

    private void UpdateActions()
    {
        if (_profileActions.Count == 0 || _columnActions.Count == 0) return;
        int pi = _profileList.SelectedIndex;
        int ci = _columnList.SelectedIndex;
        var profile = Selected;
        bool atLimit = _profiles.Count >= ColumnProfileSet.MaxProfiles;
        ActionState(_profileActions["New"], !atLimit, "Maximum profiles reached (10).", _profileList);
        ActionState(_profileActions["Duplicate"], profile is not null && !atLimit,
            atLimit ? "Maximum profiles reached (10)." : "Select a profile to duplicate.", _profileList);
        ActionState(_profileActions["Remove"], profile is not null && _profiles.Count > 1,
            _profiles.Count <= 1 ? "At least one profile is required." : "Select a profile to remove.", _profileList);
        ActionState(_profileActions["Up"], pi > 0, "The first profile cannot move up.", _profileList);
        ActionState(_profileActions["Down"], pi >= 0 && pi < _profiles.Count - 1,
            "The last profile cannot move down.", _profileList);

        bool choiceAvailable = profile is not null && _add.SelectedIndex >= 0 &&
            _add.SelectedIndex < ColumnProfileSet.Choices.Count;
        bool duplicate = choiceAvailable && profile!.Columns.Any(c => c.Key == ColumnProfileSet.Choices[_add.SelectedIndex].Key);
        ActionState(_addButton, choiceAvailable && !duplicate,
            duplicate ? "This column is already in the profile." : "Choose a profile and column to add.", _add);
        bool selectedColumn = profile is not null && ci >= 0 && ci < profile.Columns.Count;
        bool requiredName = selectedColumn && profile!.Columns[ci].Key == "name";
        ActionState(_columnActions["Remove"], selectedColumn && !requiredName,
            requiredName ? "The Name column is required." : "Select a column to remove.", _columnList);
        ActionState(_columnActions["Up"], selectedColumn && ci > 0,
            "The first column cannot move up.", _columnList);
        ActionState(_columnActions["Down"], selectedColumn && ci < profile!.Columns.Count - 1,
            "The last column cannot move down.", _columnList);
        _name.IsEnabled = profile is not null;
        _width.IsEnabled = selectedColumn && !_readOnly;
    }

    /// <summary>
    /// An unavailable action says why, on hover and to a screen reader; an available one needs no note. An action that
    /// stops being available while it has the keyboard (New at the limit, Add once its column is in, Up at the top)
    /// would drop focus out of the dialog: it goes to <paramref name="fallback"/>, the list or box the action works on,
    /// and the reason is said.
    /// </summary>
    private void ActionState(Button button, bool enabled, string unavailableReason, Control fallback)
    {
        // Read-only settings: every action stays off however the lists are moved through (Settings says why at the top).
        if (_readOnly) (enabled, unavailableReason) = (false, "These settings are read-only.");
        if (!enabled && button.IsEnabled && button.IsFocused)
        {
            TakeKeyboard(fallback);
            bool again = _status.IsVisible && _status.Text == unavailableReason;
            _status.Text = unavailableReason;
            _status.IsVisible = true;
            if (again) LiveRegions.Repeat(_status);
            _statusFor = button;
        }
        else if (enabled && ReferenceEquals(_statusFor, button))
        {
            _status.IsVisible = false;
            _statusFor = null;
        }
        button.IsEnabled = enabled;
        string? help = enabled ? null : unavailableReason;
        ToolTip.SetTip(button, help);
        ToolTip.SetShowOnDisabled(button, true);
        AutomationProperties.SetHelpText(button, help);
    }

    /// <summary>
    /// The keyboard to a list's selected row (its rows were just rebuilt and it may be out of sight, so it is brought into
    /// view and laid out first), or to the control.
    /// </summary>
    private static void TakeKeyboard(Control target)
    {
        if (target is ListBox list)
        {
            int index = Math.Max(0, list.SelectedIndex);
            list.ScrollIntoView(index);
            list.UpdateLayout();
            if (list.ContainerFromIndex(index) is Control row && row.Focus(NavigationMethod.Tab)) return;
        }
        target.Focus(NavigationMethod.Tab);
    }

    private static WrapPanel Buttons(Dictionary<string, Button> actions, string noun,
        params (string Text, Action Click)[] buttons)
    {
        var panel = DialogLayout.Actions();
        foreach (var (text, click) in buttons)
        {
            var b = new Button { Content = text };
            AutomationProperties.SetName(b, text + " " + noun);
            b.Click += (_, _) => click();
            panel.Children.Add(b);
            actions[text] = b;
        }
        return panel;
    }

    private static TextBlock Label(string text) => new() { Text = text, TextWrapping = TextWrapping.Wrap, FontWeight = FontWeight.SemiBold, VerticalAlignment = VerticalAlignment.Center };

    private static TextBlock Note(string text) =>
        new() { Text = text, Classes = { "muted", "small" }, TextWrapping = TextWrapping.Wrap, MaxWidth = 420, VerticalAlignment = VerticalAlignment.Center };
}
