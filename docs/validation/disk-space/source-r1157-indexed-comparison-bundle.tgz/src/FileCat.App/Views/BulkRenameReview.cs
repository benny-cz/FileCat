using Avalonia;
using Avalonia.Automation;
using Avalonia.Automation.Peers;
using Avalonia.Automation.Provider;
using Avalonia.Controls;
using Avalonia.Controls.Templates;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using FileCat.App.Controls;
using FileCat.App.Services;
using FileCat.Core.Operations;

namespace FileCat.App.Views;

/// <summary>A complete, virtualized review of the exact rows submitted to bulk rename.</summary>
internal sealed class BulkRenameReview : StackPanel
{
    internal sealed class Row
    {
        public Row(int index, RenamePreview plan)
        {
            Index = index;
            Plan = plan;
            OldPath = plan.Item.FileSystemPath ?? plan.OldName;
            string? folder = Path.GetDirectoryName(OldPath);
            NewPath = folder is null ? plan.NewName : folder + Path.DirectorySeparatorChar + plan.NewName;
        }

        public int Index { get; }
        public RenamePreview Plan { get; }
        public bool ProposedChange => !string.Equals(Plan.OldName, Plan.NewName, StringComparison.Ordinal);
        public string OldPath { get; }
        public string NewPath { get; }
        public string Label => $"{Index + 1:N0}. {Formatters.SafeName(Plan.OldName)}  →  {Formatters.SafeName(Plan.NewName)}";
        public string Detail => $"From: {Formatters.SafeName(OldPath)}\nTo: {Formatters.SafeName(NewPath)}" +
            (Plan.Problem is { } problem ? $"\nProblem: {Formatters.SafeName(problem)}" : "");
    }

    private readonly ComboBox _filter;
    private readonly TextBox _search;
    private readonly ListBox _list;
    private readonly TextBox _details;
    private readonly Button _problems;
    private readonly Button _nextProblem;
    private readonly Button _previousMapping;
    private readonly Button _nextMapping;
    private readonly TextBlock _position;
    private readonly WrapPanel _tools;
    private readonly StackPanel _mappingNavigation;
    private IReadOnlyList<Row> _all = [];
    private int _initialSpeechRevision;
    private bool _initialMappingSpoken;

    internal BulkRenameReview()
    {
        Spacing = 5;
        _filter = new ComboBox { MinWidth = 145, ItemsSource = new[] { "All (0)", "Problems (0)", "Changed (0)" }, SelectedIndex = 0 };
        AutomationProperties.SetName(_filter, "Preview filter");
        _search = new TextBox { Width = 190, PlaceholderText = "Search names or paths" };
        AutomationProperties.SetName(_search, "Search rename preview");
        _problems = new Button { Content = "Problems (0)", IsEnabled = false };
        AutomationProperties.SetName(_problems, "Show blocking rename problems");
        _nextProblem = new Button { Content = "Next problem", IsEnabled = false };
        _tools = new WrapPanel { Orientation = Orientation.Horizontal, ItemWidth = double.NaN };
        _tools.Children.Add(_filter);
        _tools.Children.Add(_search);
        _tools.Children.Add(_problems);
        _tools.Children.Add(_nextProblem);
        _list = new ListBox { Height = 280 };
        _list.ItemsPanel = new FuncTemplate<Panel?>(() => new VirtualizingStackPanel());
        _list.ItemTemplate = new FuncDataTemplate<Row>((row, _) => row is null ? new TextBlock() : Render(row));
        AutomationProperties.SetName(_list, "Preview of new names");
        AutomationProperties.SetHelpText(_list, "Every selected item is available here. Filter to problems or changed names, search paths, or use Previous and Next mapping to inspect every full path above.");
        _previousMapping = new Button { Content = "Previous", IsEnabled = false };
        _nextMapping = new Button { Content = "Next", IsEnabled = false };
        _position = new TextBlock { Text = "No mappings shown", VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(4, 0, 0, 0), MaxWidth = 160,
            TextWrapping = TextWrapping.NoWrap, TextTrimming = TextTrimming.CharacterEllipsis };
        AutomationProperties.SetName(_previousMapping, "Previous rename mapping");
        AutomationProperties.SetName(_nextMapping, "Next rename mapping");
        AutomationProperties.SetLiveSetting(_position, AutomationLiveSetting.Polite);
        _position.AttachedToVisualTree += (_, _) => ScheduleInitialMappingSpeech();
        _position.DetachedFromVisualTree += (_, _) => _initialSpeechRevision++;
        var mappingButtons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6,
            Children = { _previousMapping, _nextMapping } };
        _mappingNavigation = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6,
            Children = { mappingButtons, _position } };
        _details = new TextBox
        {
            IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap,
            MinHeight = 75, MaxHeight = 160,
        };
        AutomationProperties.SetName(_details, "Full old and new paths of selected rename");
        Children.Add(_tools);
        Children.Add(_mappingNavigation);
        Children.Add(_details);
        Children.Add(_list);
        _filter.SelectionChanged += (_, _) => UpdateView();
        _search.TextChanged += (_, _) => UpdateView();
        _list.SelectionChanged += (_, _) => UpdateSelectionPresentation();
        _problems.Click += (_, _) => ShowProblems();
        _nextProblem.Click += (_, _) => NextProblem();
        _previousMapping.Click += (_, _) => StepMapping(-1);
        _nextMapping.Click += (_, _) => StepMapping(1);
    }

    /// <summary>Keep the exact decision visible below a scrolling rename form on every desktop.</summary>
    internal StackPanel DetachNavigationForDialog()
    {
        Children.Remove(_mappingNavigation);
        Children.Remove(_details);
        // The fixed section must leave room for the scrollable form at the smallest supported dialog size.
        // The complete text remains in the read-only field and its own scroll/selection route.
        _details.MaxHeight = 96;
        return new StackPanel { Spacing = 5, Children = { _mappingNavigation, _details } };
    }

    internal IReadOnlyList<Row> AllRows => _all;
    internal IReadOnlyList<Row> ShownRows { get; private set; } = [];
    internal int ProblemCount { get; private set; }
    internal int ChangedCount { get; private set; }

    internal void SetRows(IReadOnlyList<RenamePreview> rows)
    {
        int selected = (_list.SelectedItem as Row)?.Index ?? -1;
        int filter = _filter.SelectedIndex;
        _all = rows.Select((row, index) => new Row(index, row)).ToArray();
        ProblemCount = _all.Count(r => r.Plan.Problem is not null);
        ChangedCount = _all.Count(r => r.ProposedChange);
        _filter.ItemsSource = new[] { $"All ({_all.Count:N0})", $"Problems ({ProblemCount:N0})", $"Changed ({ChangedCount:N0})" };
        _filter.SelectedIndex = filter;
        _problems.Content = $"Problems ({ProblemCount:N0})";
        _problems.IsEnabled = _nextProblem.IsEnabled = ProblemCount > 0;
        UpdateView(selected);
    }

    private void ShowProblems()
    {
        _search.Text = string.Empty;
        _filter.SelectedIndex = 1;
        Select(_all.FirstOrDefault(r => r.Plan.Problem is not null));
    }

    private void NextProblem()
    {
        if (ProblemCount == 0) return;
        int selected = (_list.SelectedItem as Row)?.Index ?? -1;
        var next = _all.FirstOrDefault(r => r.Index > selected && r.Plan.Problem is not null)
            ?? _all.First(r => r.Plan.Problem is not null);
        _search.Text = string.Empty;
        _filter.SelectedIndex = 1;
        Select(next);
    }

    private void Select(Row? row)
    {
        if (row is null) return;
        _list.SelectedItem = row;
        _list.ScrollIntoView(row);
        _list.Focus();
    }

    private void StepMapping(int direction)
    {
        int current = SelectedShownIndex();
        int next = current + direction;
        if (next < 0 || next >= ShownRows.Count) return;
        _list.SelectedItem = ShownRows[next];
        _list.ScrollIntoView(ShownRows[next]);
    }

    private int SelectedShownIndex()
    {
        for (int i = 0; i < ShownRows.Count; i++)
            if (ReferenceEquals(ShownRows[i], _list.SelectedItem)) return i;
        return -1;
    }

    private void UpdateSelectionPresentation()
    {
        int index = SelectedShownIndex();
        var selected = index >= 0 ? ShownRows[index] : null;
        _details.Text = selected?.Detail ?? string.Empty;
        // The live region must carry the complete utterance in Text. On Windows, NVDA speaks a
        // live TextBlock's text rather than its AutomationProperties.Name. Trim only the visible
        // rendering; the selected, read-only detail below remains fully readable and selectable.
        _position.Text = selected is null ? "No rename mappings match the current preview filter."
            : $"{index + 1:N0} of {ShownRows.Count:N0} shown · " +
              selected.Detail.Replace("\n", " · ", StringComparison.Ordinal);
        AutomationProperties.SetName(_position, _position.Text);
        ToolTip.SetTip(_position, _position.Text);
        _previousMapping.IsEnabled = index > 0;
        _nextMapping.IsEnabled = index >= 0 && index < ShownRows.Count - 1;
        AutomationProperties.SetHelpText(_previousMapping, index > 0
            ? "Previous mapping: " + ShownRows[index - 1].Detail : "No previous mapping.");
        AutomationProperties.SetHelpText(_nextMapping, index >= 0 && index < ShownRows.Count - 1
            ? "Next mapping: " + ShownRows[index + 1].Detail : "No next mapping.");
        if (selected is not null) ScheduleInitialMappingSpeech();
    }

    private void ScheduleInitialMappingSpeech()
    {
        if (_initialMappingSpoken || ShownRows.Count == 0 || !OperatingSystem.IsMacOS() ||
            TopLevel.GetTopLevel(_position) is not Window window ||
            ControlAutomationPeer.CreatePeerForElement(window) is not IRootProvider { PlatformImpl: { } platform } ||
            platform.GetType().Assembly.GetName().Name == "Avalonia.Headless") return;
        int revision = ++_initialSpeechRevision;
        // The dialog title and asynchronous count can otherwise displace the
        // initial mapping before VoiceOver speaks it. Its full path is the
        // consequential choice, so repeat it once after those events settle.
        DispatcherTimer.RunOnce(() =>
        {
            if (revision != _initialSpeechRevision || _initialMappingSpoken ||
                !_position.IsEffectivelyVisible || !_position.IsEffectivelyEnabled ||
                TopLevel.GetTopLevel(_position) is not Window) return;
            LiveRegions.Repeat(_position);
            _initialMappingSpoken = true;
        }, TimeSpan.FromMilliseconds(350));
    }

    private void UpdateView(int selected = -1)
    {
        string query = (_search.Text ?? string.Empty).Trim();
        if (query.Length > 256) query = query[..256];
        int filter = _filter.SelectedIndex;
        ShownRows = _all.Where(row => (filter switch
            {
                1 => row.Plan.Problem is not null,
                2 => row.ProposedChange,
                _ => true,
            }) && (query.Length == 0 || row.OldPath.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                row.NewPath.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                row.Plan.Problem?.Contains(query, StringComparison.OrdinalIgnoreCase) == true)).ToArray();
        _list.ItemsSource = ShownRows;
        _list.SelectedItem = ShownRows.FirstOrDefault(row => row.Index == selected) ?? ShownRows.FirstOrDefault();
        UpdateSelectionPresentation();
    }

    private static Control Render(Row row)
    {
        var panel = new StackPanel { Spacing = 2 };
        panel.Children.Add(new TextBlock { Text = row.Label, TextTrimming = TextTrimming.CharacterEllipsis });
        if (row.Plan.Problem is { } problem)
            panel.Children.Add(new TextBlock { Text = "⚠ " + Formatters.SafeName(problem), Classes = { "error" }, TextTrimming = TextTrimming.CharacterEllipsis });
        AutomationProperties.SetName(panel, row.Detail);
        ToolTip.SetTip(panel, row.Detail);
        return panel;
    }
}
