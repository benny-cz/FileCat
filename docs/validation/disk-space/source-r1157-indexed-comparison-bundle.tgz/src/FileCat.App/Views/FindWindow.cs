using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using FileCat.App.Controls;
using FileCat.App.Services;
using FileCat.App.ViewModels;
using FileCat.Core.Commands;
using FileCat.Core.Listing;
using FileCat.Core.Resources;
using FileCat.Core.Search;
using Location = FileCat.Core.Resources.Location;

namespace FileCat.App.Views;

/// <summary>
/// Find files (Alt+F7) as Salamander has it (plan §11, SEARCH-002): a window of its own that leaves the panels free, so
/// a search runs while you work and several can run at once. The criteria are above; the found items are below in a
/// panel's list, which acts on the original items with the panels' own commands (F3, F4, F5, F6, F8, …). A new search
/// can replace the found items, keep only those it matches too, remove those it matches, or add its matches.
/// </summary>
public sealed class FindWindow : Window, IViewActions
{
    // Screen readers follow a list's focused row and, on Linux, hear focus after window activation.
    protected override Avalonia.Automation.Peers.AutomationPeer OnCreateAutomationPeer() =>
        new FileCat.App.Controls.DescendantFocusWindowAutomationPeer(this);

    private static readonly List<FindWindow> s_open = [];

    /// <summary>
    /// Panel commands that act on the found items (their shortcuts are the panels'); Enter opens, Space shows the item
    /// in the active panel, and Ctrl+H hides it from the list.
    /// </summary>
    private static readonly HashSet<string> ListCommands =
    [
        CommandIds.View, CommandIds.ViewAlternate, CommandIds.Edit, CommandIds.HexEdit, CommandIds.Copy, CommandIds.Move,
        CommandIds.Delete, CommandIds.DeletePermanent, CommandIds.Properties, CommandIds.UserMenu, CommandIds.OpenWithSystem,
        CommandIds.Reveal, CommandIds.CopyNames, CommandIds.CopyPaths, CommandIds.CopyUncPaths, CommandIds.CopyToClipboard,
        CommandIds.CutToClipboard, CommandIds.MarkToggleDown, CommandIds.MarkAll, CommandIds.MarkNone, CommandIds.MarkInvert,
        CommandIds.MarkInvertAll, CommandIds.MarkSelectMask, CommandIds.MarkUnselectMask, CommandIds.MarkSameExt,
        CommandIds.UnmarkSameExt, CommandIds.MarkSameName, CommandIds.UnmarkSameName, CommandIds.MarkRestore, CommandIds.ReviewMarks, CommandIds.Checksum,
        CommandIds.Pack, CommandIds.Attributes, CommandIds.AddToWorkingSet, CommandIds.RemoveFromSet, CommandIds.CompareFiles,
        CommandIds.ApplyCommand, CommandIds.BulkRename, CommandIds.SortName, CommandIds.SortExtension, CommandIds.SortTime,
        CommandIds.SortSize, CommandIds.SortNone, CommandIds.Refresh,
    ];

    private readonly MainViewModel _vm;
    private readonly AppServices _services;
    private readonly Location? _origin;
    private readonly bool _requiresLocalChoice;
    private bool _localChoiceMade;
    private bool _applyingSavedSearch;
    private string? _loadedSearchName;
    private bool _loadedSearchHasScope;
    private readonly OverlayDialogService _dialogs;
    private readonly Panel _overlay = new() { IsVisible = false };
    private readonly Menu _menu = new();
    // The found items live in a tab of a panel outside the workspace, so the panels' commands work on them.
    private readonly PanelViewModel _panel;
    private readonly FileListControl _list = new() { IsActivePanel = true };
    private readonly TextBlock _placeholder = new()
    {
        Text = "Found items appear here. Enter searches; Ctrl+I keeps only the items a new search finds too, Ctrl+S removes them, and Ctrl+W adds its finds.",
        Classes = { "muted" },
        TextWrapping = TextWrapping.Wrap,
        HorizontalAlignment = HorizontalAlignment.Center,
        VerticalAlignment = VerticalAlignment.Center,
        MaxWidth = 560,
        TextAlignment = TextAlignment.Center,
    };
    private TabViewModel? _tab;
    private CommandScope? _scope;

    private readonly TextBox _names = new() { PlaceholderText = "* (a word finds names containing it; masks: *.cs;*.txt|*test*)" };
    private readonly TextBox _lookIn = new() { PlaceholderText = "Folders to search, separated by semicolons" };
    private readonly TextBox _text = new() { PlaceholderText = "Text inside files (optional)" };
    private readonly CheckBox _subfolders = new() { Content = "Subfolders", IsChecked = true };
    private readonly CheckBox _hidden = new() { Content = "Hidden items" };
    private readonly CheckBox _matchCase = new() { Content = "Match case" };
    private readonly CheckBox _wholeWords = new() { Content = "Whole words" };
    private readonly CheckBox _regex = new() { Content = "Regular expression" };
    private readonly CheckBox _unicode = new() { Content = "Unicode" };
    private readonly CheckBox _hex = new() { Content = "Hex" };
    private readonly CheckBox _archives = new() { Content = "Inside archives" };
    private readonly Button _find = new() { Content = "Find", Classes = { "primary" } };
    private readonly Button _stop = new() { Content = "Stop", IsEnabled = false };
    private readonly Button _skip = new() { Content = "Skip current folder", IsEnabled = false };
    private readonly Button _logButton = new() { Content = "Log", IsEnabled = false };
    private readonly TextBlock _advancedSummary = new() { TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _advancedButton = new() { Content = "Advanced…" };
    private readonly Button _advancedReset = new() { Content = "Reset" };
    private AdvancedSearchCriteria _advanced = new();
    private readonly TextBlock _status = new() { TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock _qualifications = new() { Classes = { "small" }, TextWrapping = TextWrapping.Wrap, IsVisible = false };
    private readonly TextBlock _archiveContentNotice = new()
    {
        Text = "Inside archives is ignored when Containing has text. This search checks local file contents only; archive member names and contents are not searched.",
        Classes = { "small" }, TextWrapping = TextWrapping.Wrap, IsVisible = false,
    };
    private readonly TextBlock _activity = new() { Classes = { "small", "muted" }, TextTrimming = TextTrimming.CharacterEllipsis };
    private readonly Border _emptyResults = new() { IsVisible = false };
    private readonly TextBlock _emptyHeadline = new() { TextWrapping = TextWrapping.Wrap, FontSize = 18 };
    private readonly TextBlock _emptyExplanation = new() { TextWrapping = TextWrapping.Wrap };
    private readonly Button _editCriteria = new() { Content = "Edit criteria" };
    private readonly Button _emptyLog = new() { Content = "Review search log", IsVisible = false };
    private readonly TextBlock _error = new() { Classes = { "error" }, IsVisible = false, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(10, 4, 10, 0) };
    private readonly TextBlock _message = new() { Classes = { "small" }, TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock _scopeNotice = new() { Classes = { "small" }, TextWrapping = TextWrapping.Wrap, IsVisible = false };
    private readonly Button _useLocalHome = new() { Content = "Use local home", IsVisible = false };
    private readonly Grid _scopeHost = new() { ColumnDefinitions = new ColumnDefinitions("*,Auto"), Margin = new Thickness(10, 6, 10, 0), IsVisible = false };
    private readonly Panel _lookInHost = new();
    private readonly PathCompletion _completion;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(250) };

    // Searching within a result set (Find in a panel that shows one): its items are the scope.
    private IReadOnlyList<(ItemRef Item, string Relative)>? _within;

    private ResultSet? _set;           // the found items
    private ResultSet? _refineScratch; // a refining search's own matches
    private RefineMode _mode;
    private int _appended;
    private SearchSession? _session;
    private string _searchScope = string.Empty;
    private CancellationTokenSource? _cts;
    private DateTime _lastRefresh;
    private int _shownCount = -1;
    private bool _closed;
    // Duplicates: what makes files alike (asked before the search), the groups found, and their comparison's cancel.
    private DuplicateCriteria? _duplicates;
    private IReadOnlyList<IReadOnlyList<ItemRef>> _groups = [];
    private CancellationTokenSource? _grouping;
    private bool _comparing;

    /// <summary>Open Find windows, oldest first.</summary>
    public static IReadOnlyList<FindWindow> OpenWindows => s_open;

    /// <summary>Opens Find for a local root or result snapshot; an unsupported origin requires a deliberate local choice.</summary>
    public static FindWindow Open(MainViewModel vm, string root, ResultSet? within, Location? origin = null)
    {
        var window = new FindWindow(vm, root, within, origin);
        s_open.Add(window);
        window.Closed += (_, _) => s_open.Remove(window);
        window.Show();
        return window;
    }

    private FindWindow(MainViewModel vm, string root, ResultSet? within, Location? origin)
    {
        _vm = vm;
        _services = vm.Services;
        _origin = origin;
        _requiresLocalChoice = within is null && origin is not null && !origin.IsFileSystem;
        _panel = new PanelViewModel(vm.Workspace, vm.Services);
        _within = within?.Snapshot();
        Title = within is null ? "Find files" : "Find within results";
        Width = 1040; Height = 720; MinWidth = 640; MinHeight = 420;
        WindowFit.Attach(this);
        try { Icon = new WindowIcon(Avalonia.Platform.AssetLoader.Open(new Uri("avares://FileCat/Assets/filecat.ico"))); } catch (Exception) { }
        _dialogs = new OverlayDialogService(_overlay, () => _tab is null ? _names : _list);
        _list.FontSize = vm.ListFontSize;
        _list.ComfortableRows = vm.ComfortableDensity;
        Classes.Set("comfortable", vm.ComfortableDensity);
        AutomationName(_list, "Found items");
        AutomationName(_names, "Names");
        AutomationName(_lookIn, within is null ? "Look in" : "Search within");
        AutomationName(_scopeNotice, "Find scope guidance");
        AutomationName(_useLocalHome, "Choose local home as Find scope");
        AutomationName(_text, "Containing");
        AutomationName(_logButton, "Search log");
        AutomationName(_status, "Find completion");
        AutomationName(_qualifications, "Search qualifications");
        AutomationName(_archiveContentNotice, "Archive content search limitation");
        AutomationName(_activity, "Search progress");
        AutomationName(_emptyResults, "Search result summary");
        AutomationProperties.SetLiveSetting(_status, AutomationLiveSetting.Off);
        AutomationProperties.SetLiveSetting(_qualifications, AutomationLiveSetting.Off);

        var history = _services.History;
        _names.Text = history.SearchNames.FirstOrDefault() ?? "*";
        _lookIn.Text = _within is not null ? $"{within!.Title} ({_within.Count:N0} items)"
            : _requiresLocalChoice ? string.Empty : root;
        _lookIn.IsReadOnly = _within is not null;
        _hidden.IsChecked = _services.Settings.ShowHidden;
        HistoryKeys(_names, () => history.SearchNames);
        HistoryKeys(_text, () => history.SearchTexts);
        if (_within is null) HistoryKeys(_lookIn, () => history.SearchFolders);
        _hex.IsCheckedChanged += (_, _) => UpdateContentOptions();
        _regex.IsCheckedChanged += (_, _) => UpdateContentOptions();
        _archives.IsCheckedChanged += (_, _) => UpdateArchiveContentNotice();
        _text.TextChanged += (_, _) => UpdateArchiveContentNotice();
        UpdateContentOptions();
        UpdateArchiveContentNotice();

        var root_ = new Grid();
        var dock = new DockPanel();
        BuildMenu();
        DockPanel.SetDock(_menu, Dock.Top);
        dock.Children.Add(_menu);
        var criteria = BuildCriteria();
        _lookIn.PropertyChanged += (_, change) =>
        {
            if (change.Property != TextBox.TextProperty) return;
            if (_requiresLocalChoice) _localChoiceMade = !string.IsNullOrWhiteSpace(_lookIn.Text);
            if (!_applyingSavedSearch) { _loadedSearchName = null; _loadedSearchHasScope = false; }
            UpdateScopeNotice();
        };
        _useLocalHome.Click += (_, _) =>
        {
            _lookIn.Text = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            _localChoiceMade = !string.IsNullOrWhiteSpace(_lookIn.Text);
            UpdateScopeNotice();
            _lookIn.CaretIndex = _lookIn.Text.Length;
            _lookIn.Focus();
        };
        _completion = new PathCompletion(_lookIn, _lookInHost, () => _services.Settings.ShowHidden, () => root);
        _completion.Chosen += path =>
        {
            _lookIn.Text = path;
            _lookIn.CaretIndex = path.Length;
        };
        DockPanel.SetDock(criteria, Dock.Top);
        dock.Children.Add(criteria);
        var statusBar = new DockPanel { Margin = new Thickness(10, 4, 10, 6) };
        statusBar.Children.Add(_message);
        DockPanel.SetDock(statusBar, Dock.Bottom);
        dock.Children.Add(statusBar);
        _emptyResults[!Border.BackgroundProperty] = new Avalonia.Markup.Xaml.MarkupExtensions.DynamicResourceExtension("FcPanel");
        var emptyActions = new WrapPanel { ItemSpacing = 8, LineSpacing = 6, Children = { _editCriteria, _emptyLog } };
        _emptyResults.Child = new ScrollViewer
        {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Content = new StackPanel
            {
                Spacing = 10, Margin = new Thickness(20), MaxWidth = 720,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Children = { _emptyHeadline, _emptyExplanation, emptyActions },
            },
        };
        var results = new Border
        {
            Margin = new Thickness(8, 4, 8, 0),
            BorderThickness = new Thickness(1),
            Child = new Panel { Children = { _list, _placeholder, _emptyResults } },
            [!Border.BorderBrushProperty] = new Avalonia.Markup.Xaml.MarkupExtensions.DynamicResourceExtension("FcBorder"),
        };
        _list.IsVisible = false;
        dock.Children.Add(results);
        root_.Children.Add(dock);
        root_.Children.Add(_overlay);
        Content = ThemeLayers.Over(root_, results);
        if (_services.Settings.SavedSearches.FirstOrDefault(s => s.LoadOnOpen) is { } preset) Apply(preset.Criteria, preset.Name);
        else UpdateScopeNotice();

        _find.Click += (_, _) => StartSearch(RefineMode.Replace);
        _stop.Click += (_, _) => Stop();
        _skip.Click += (_, _) => _session?.SkipCurrentFolder();
        _logButton.Click += (_, _) => _ = ShowLogAsync();
        _editCriteria.Click += (_, _) => { _names.Focus(); _names.SelectAll(); };
        _emptyLog.Click += (_, _) => _ = ShowLogAsync();
        _timer.Tick += (_, _) => OnTick();
        _list.OpenRequested += (_, _) => OpenFocused();
        _list.ContextMenuRequested += (_, point) => ShowListMenu(point);
        _list.DragRequested += async (_, press) => await DragAsync(press);
        AddHandler(KeyDownEvent, OnPreviewKeyDown, RoutingStrategies.Tunnel);
        Controls.AltChords.Attach(this);
        Opened += (_, _) =>
        {
            var focusAtOpen = FocusManager?.GetFocusedElement();
            Dispatcher.UIThread.Post(() =>
            {
                // A dialog opened during this frame owns its initial focus. The window's older
                // callback must also yield to deliberate focus elsewhere or to deactivation/close.
                if (_closed || !IsActive || _dialogs.IsOpen ||
                    !ReferenceEquals(FocusManager?.GetFocusedElement(), focusAtOpen)) return;
                if (_names.Focus()) _names.SelectAll();
            }, DispatcherPriority.Input);
        };
        Closing += (_, _) => _dialogs.CancelAll();
        Closed += (_, _) =>
        {
            _closed = true;
            _timer.Stop();
            Stop();
            _tab?.Dispose();
            // Published results belong to the session provider; these private indexes belong to this window.
            _within = null;
            _groups = [];
            _refineScratch = null;
            _session = null;
        };
    }

    private static void AutomationName(Control control, string name) => Avalonia.Automation.AutomationProperties.SetName(control, name);

    // ---- Layout ------------------------------------------------------------------------------------------------

    private Control BuildCriteria()
    {
        var grid = new Grid { ColumnDefinitions = new ColumnDefinitions("Auto,*,Auto"), Margin = new Thickness(10, 8, 10, 4) };
        int row = 0;
        void Row(string label, Control input, Control? extra = null)
        {
            grid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            var text = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 3, 10, 3) };
            Grid.SetRow(text, row);
            Grid.SetRow(input, row);
            Grid.SetColumn(input, 1);
            input.Margin = new Thickness(0, 3);
            grid.Children.Add(text);
            grid.Children.Add(input);
            if (extra is not null)
            {
                Grid.SetRow(extra, row);
                Grid.SetColumn(extra, 2);
                extra.Margin = new Thickness(6, 3, 0, 3);
                grid.Children.Add(extra);
            }
            row++;
        }
        Row("Named:", _names, HistoryButton(_names, () => _services.History.SearchNames, "Earlier names"));
        var lookInButtons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
        if (_within is null)
        {
            lookInButtons.Children.Add(HistoryButton(_lookIn, () => _services.History.SearchFolders, "Earlier folders"));
            var local = new Button { Content = "Local drives" };
            var all = new Button { Content = "All drives" };
            ToolTip.SetTip(local, "Searches every local drive");
            ToolTip.SetTip(all, "Searches every local and network drive");
            local.Click += (_, _) => _lookIn.Text = string.Join("; ", Drives(network: false));
            all.Click += (_, _) => _lookIn.Text = string.Join("; ", Drives(network: true));
            lookInButtons.Children.Add(local);
            lookInButtons.Children.Add(all);
        }
        _lookInHost.Children.Add(_lookIn);
        Row(_within is null ? "Look in:" : "Search within:", _lookInHost, lookInButtons);
        // Each field's options under it, as in Salamander: where to look, then how to read the text.
        var where = new WrapPanel { ItemSpacing = 12, LineSpacing = 4 };
        foreach (var box in new[] { _subfolders, _hidden, _archives }) where.Children.Add(box);
        Row(string.Empty, where);
        Row("Containing:", _text, HistoryButton(_text, () => _services.History.SearchTexts, "Earlier texts"));
        var options = new WrapPanel { ItemSpacing = 12, LineSpacing = 4 };
        foreach (var box in new[] { _matchCase, _wholeWords, _regex, _unicode, _hex }) options.Children.Add(box);
        ToolTip.SetTip(_archives, "Also finds names inside ZIP, 7z, RAR, TAR, and the other archives FileCat opens (not their contents, and not archives inside archives)");
        ToolTip.SetTip(_unicode, "Also finds the text where a file keeps it as UTF-16 (either byte order) or UTF-8: in programs, fonts, the Registry's files, and other binary files, not only in text files");
        ToolTip.SetTip(_hex, "The text is bytes: hex pairs (4D 5A) and text in quotes (\"MZ\")");
        ToolTip.SetTip(_wholeWords, "No letter, digit, or underscore right before or after the text");
        if (_within is not null) _subfolders.IsEnabled = false;
        Row(string.Empty, options);
        ToolTip.SetTip(_advancedReset, "Clears the advanced criteria");
        Row("Advanced:", _advancedSummary, new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6, Children = { _advancedButton, _advancedReset } });
        _advancedButton.Click += (_, _) => _ = EditAdvancedAsync();
        _advancedReset.Click += (_, _) => SetAdvanced(new AdvancedSearchCriteria());
        SetAdvanced(_advanced);
        var actions = new StackPanel { Margin = new Thickness(10, 6, 10, 0), Spacing = 4 };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, Children = { _find, _stop, _skip } };
        actions.Children.Add(buttons);
        actions.Children.Add(_archiveContentNotice);
        var headline = new DockPanel();
        DockPanel.SetDock(_logButton, Dock.Right);
        headline.Children.Add(_logButton);
        headline.Children.Add(_status);
        actions.Children.Add(headline);
        actions.Children.Add(_qualifications);
        actions.Children.Add(_activity);
        Grid.SetColumn(_useLocalHome, 1);
        _useLocalHome.Margin = new Thickness(8, 0, 0, 0);
        _scopeHost.Children.Add(_scopeNotice);
        _scopeHost.Children.Add(_useLocalHome);
        // The criteria can exceed the minimum window height (especially with a
        // wrapped scope or enlarged text). Keep the actions and completion
        // summary outside their scroll area so the result view retains space.
        var fields = new ScrollViewer
        {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = new StackPanel { Children = { _scopeHost, grid } },
        };
        AutomationName(fields, "Find criteria fields");
        void FitFields() => fields.MaxHeight = Math.Max(112, ClientSize.Height - 300);
        FitFields();
        SizeChanged += (_, _) => FitFields();
        fields.AddHandler(InputElement.GotFocusEvent, (_, e) =>
        {
            if (e.Source is Control focused && !ReferenceEquals(focused, fields)) focused.BringIntoView();
        }, RoutingStrategies.Bubble);
        return new StackPanel { Children = { fields, actions, _error } };
    }

    /// <summary>A small button that lists a field's history; choosing an entry puts it in the field.</summary>
    private static Button HistoryButton(TextBox box, Func<IReadOnlyList<string>> history, string name)
    {
        var button = new Button { Content = "▾", Padding = new Thickness(8, 2), VerticalAlignment = VerticalAlignment.Stretch };
        AutomationName(button, name);
        ToolTip.SetTip(button, name + " (Up and Down in the box go through them too)");
        button.Click += (_, _) =>
        {
            var flyout = new MenuFlyout();
            var entries = history();
            if (entries.Count == 0) flyout.Items.Add(new MenuItem { Header = "(nothing yet)", IsEnabled = false });
            foreach (var entry in entries.Take(25))
            {
                var item = new MenuItem { Header = entry };
                item.Click += (_, _) =>
                {
                    box.Text = entry;
                    box.CaretIndex = entry.Length;
                    box.Focus();
                };
                flyout.Items.Add(item);
            }
            flyout.ShowAt(box);
        };
        return button;
    }

    /// <summary>Up and Down go through a field's history, as in prompts.</summary>
    private static void HistoryKeys(TextBox box, Func<IReadOnlyList<string>> history)
    {
        int index = -1;
        box.KeyDown += (_, e) =>
        {
            var h = history();
            if (h.Count == 0 || e.KeyModifiers != KeyModifiers.None) return;
            if (e.Key == Key.Up && index < h.Count - 1) index++;
            else if (e.Key == Key.Down && index > 0) index--;
            else return;
            box.Text = h[index];
            box.CaretIndex = box.Text.Length;
            e.Handled = true;
        };
    }

    private static IEnumerable<string> Drives(bool network)
    {
        if (!OperatingSystem.IsWindows()) return ["/"];
        // The type is known without touching the drive (a sleeping disk or a lost share would hold the window).
        return DriveInfo.GetDrives()
            .Where(d => d.DriveType is DriveType.Fixed or DriveType.Removable || network && d.DriveType == DriveType.Network)
            .Select(d => d.Name);
    }

    private void UpdateContentOptions()
    {
        bool hex = _hex.IsChecked == true;
        _matchCase.IsEnabled = !hex;
        _wholeWords.IsEnabled = !hex;
        _regex.IsEnabled = !hex;
        _unicode.IsEnabled = !hex;
        _text.PlaceholderText = hex ? "Bytes: hex pairs (4D 5A 90) and text in quotes (\"MZ\")" : "Text inside files (optional)";
    }

    // ---- Menus -------------------------------------------------------------------------------------------------

    private void BuildMenu()
    {
        _menu.Items.Clear();
        _menu.Items.Add(Submenu("_Files", FileItems()));
        _menu.Items.Add(Submenu("_Edit", [
            CommandItem(CommandIds.MarkAll, "Select all"), CommandItem(CommandIds.MarkNone, "Unselect all"),
            CommandItem(CommandIds.MarkInvert, "Invert selection"), CommandItem(CommandIds.MarkSelectMask, "Select…"),
            CommandItem(CommandIds.MarkUnselectMask, "Unselect…"), CommandItem(CommandIds.ReviewMarks, "Review marked items…"), new Separator(),
            FindActionItem(CommandIds.FindHideSelected, "Hide selected items", HideSelected, () => _tab is not null, "find.hideSelected"),
            ActionItem("Hide duplicate names", null, HideDuplicateNames, () => _tab is not null, "find.hideDuplicates"),
            new Separator(),
            ActionItem("Select all but one in each group", null, SelectAllButOnePerGroup, () => _groups.Count > 0, "find.allButOne"),
        ]));
        _menu.Items.Add(Submenu("F_ind", [
            FindActionItem(CommandIds.FindRun, "Find", () => StartSearch(RefineMode.Replace), icon: "find.run"),
            FindActionItem(CommandIds.FindIntersect, "Keep only items found again", () => StartSearch(RefineMode.Intersect), () => _set is not null, "find.keepAgain"),
            FindActionItem(CommandIds.FindSubtract, "Remove items found again", () => StartSearch(RefineMode.Subtract), () => _set is not null, "find.removeAgain"),
            FindActionItem(CommandIds.FindAppend, "Add new finds", () => StartSearch(RefineMode.Append), () => _set is not null, "find.addNew"),
            new Separator(),
            FindActionItem(CommandIds.FindStopOrClose, "Stop", Stop, () => IsSearching, "find.stop"),
            FindActionItem(CommandIds.FindSkipCurrent, "Skip current folder", () => _session?.SkipCurrentFolder(), () => IsSearching, "find.skipFolder"),
            new Separator(),
            ActionItem("Find duplicates…", null, () => _ = FindDuplicatesAsync(), icon: "find.duplicates"),
            new Separator(),
            ActionItem("Show in panel", null, ShowInPanel, () => _set is not null, CommandIds.OpenInTarget),
            ActionItem("Search log…", null, () => _ = ShowLogAsync(), () => _session?.Log.Count > 0, "find.log"),
        ]));
        _menu.Items.Add(Submenu("_View", [
            CommandItem(CommandIds.SortName), ActionItem("Sort by folder", null, () => _tab?.SortByMetadata(ColumnSpec.FolderSortKey), () => _tab is not null, "find.sortFolder"),
            CommandItem(CommandIds.SortExtension), CommandItem(CommandIds.SortTime),
            CommandItem(CommandIds.SortSize), CommandItem(CommandIds.SortNone), new Separator(), CommandItem(CommandIds.Refresh, "Check the items again"),
        ]));
        var logOnErrors = new MenuItem
        {
            Header = "Show the log after a search that could not read something",
            ToggleType = MenuItemToggleType.CheckBox,
            IsChecked = _services.Settings.SearchLogOnErrors,
        };
        logOnErrors.Click += (_, _) =>
        {
            _services.Settings.SearchLogOnErrors = !_services.Settings.SearchLogOnErrors;
            logOnErrors.IsChecked = _services.Settings.SearchLogOnErrors;
            _services.SaveSettings();
        };
        _menu.Items.Add(Submenu("_Options", [
            FindActionItem(CommandIds.FindAdvanced, "Advanced criteria…", () => _ = EditAdvancedAsync(), icon: CommandIds.QuickFilter),
            ActionItem("Ignored folders…", null, () => _ = EditIgnoredFoldersAsync(), icon: "find.ignored"),
            new Separator(),
            ActionItem("Save search…", null, () => _ = SaveSearchAsync(), icon: CommandIds.SaveWorkspace),
            ActionItem("Saved searches…", null, () => _ = LoadSearchAsync(), icon: CommandIds.LoadWorkspace),
            new Separator(),
            logOnErrors,
        ]));
        UpdateShortcutHints();
    }

    private List<Control> FileItems() =>
    [
        FindActionItem(CommandIds.FindOpen, "Open", OpenFocused, () => _tab is not null, CommandIds.Open),
        FindActionItem(CommandIds.FindShowInPanel, "Show in the active panel", () => FocusInPanel(enter: false), () => _tab is not null, CommandIds.GoTo),
        CommandItem(CommandIds.View), CommandItem(CommandIds.ViewAlternate), CommandItem(CommandIds.Edit), new Separator(),
        CommandItem(CommandIds.Copy), CommandItem(CommandIds.Move), CommandItem(CommandIds.Delete), CommandItem(CommandIds.DeletePermanent),
        new Separator(),
        CommandItem(CommandIds.Properties), CommandItem(CommandIds.UserMenu), CommandItem(CommandIds.Checksum), CommandItem(CommandIds.Pack),
        new Separator(),
        CommandItem(CommandIds.CopyNames), CommandItem(CommandIds.CopyPaths), CommandItem(CommandIds.CopyToClipboard),
        CommandItem(CommandIds.AddToWorkingSet),
    ];

    private static MenuItem Submenu(string header, List<Control> items)
    {
        var top = new MenuItem { Header = header, ItemsSource = items };
        top.SubmenuOpened += (_, _) =>
        {
            foreach (var item in items.OfType<MenuItem>())
                if (item.Tag is Func<(bool Enabled, string? Reason)> state)
                {
                    var (enabled, reason) = state();
                    item.IsEnabled = enabled;
                    ToolTip.SetTip(item, enabled ? null : reason);
                }
        };
        return top;
    }

    private MenuItem ActionItem(string header, string? gesture, Action run, Func<bool>? available = null, string? icon = null)
    {
        var item = new MenuItem { Header = header, Icon = MenuIcon(icon) };
        if (gesture is not null) item.InputGesture = KeyGesture.Parse(gesture);
        item.Click += (_, _) => run();
        if (available is not null) item.Tag = new Func<(bool, string?)>(() => (available(), null));
        return item;
    }

    private MenuItem FindActionItem(string id, string header, Action run, Func<bool>? available = null, string? icon = null)
    {
        var item = ActionItem(header, null, run, available, icon);
        var chord = _services.Keymap.GetChords(id).FirstOrDefault();
        if (chord.Key is not null) item.InputGesture = KeyMapper.ToGesture(chord);
        return item;
    }

    private void UpdateShortcutHints()
    {
        string Hint(string id) => _services.Keymap.GetGestureText(id) is { Length: > 0 } gesture ? gesture : "the Find menu";
        _placeholder.Text = $"Found items appear here. {Hint(CommandIds.FindRun)} searches; " +
            $"{Hint(CommandIds.FindIntersect)} keeps only items found again, " +
            $"{Hint(CommandIds.FindSubtract)} removes them from the list, and " +
            $"{Hint(CommandIds.FindAppend)} adds new finds.";
        ToolTip.SetTip(_find, $"{Hint(CommandIds.FindRun)} searches · {Hint(CommandIds.FindIntersect)} keeps matching results · " +
            $"{Hint(CommandIds.FindSubtract)} removes matching results · {Hint(CommandIds.FindAppend)} adds new finds");
        ToolTip.SetTip(_stop, Hint(CommandIds.FindStopOrClose));
        ToolTip.SetTip(_advancedButton, $"Attributes, size, and times ({Hint(CommandIds.FindAdvanced)})");
    }

    private MenuItem CommandItem(string id, string? header = null)
    {
        var def = _services.Commands.Get(id);
        var item = new MenuItem { Header = header ?? def?.Title ?? id, Icon = MenuIcon(id) };
        var chord = _services.Keymap.GetChords(id).FirstOrDefault();
        // Find's effective binding wins over the inherited panel gesture in this window.
        if (chord.Key is not null && !IsFindCommand(_services.Keymap.Resolve(chord, CommandContext.FindResults, CommandContext.Find))
            && KeyMapper.ToGesture(chord) is { } gesture) item.InputGesture = gesture;
        item.Click += (_, _) => Run(id);
        item.Tag = new Func<(bool, string?)>(() =>
        {
            if (_scope is null) return (false, "Search first: these act on the items found.");
            var availability = _vm.GetAvailability(id, _scope);
            return (availability.Enabled, availability.Reason);
        });
        return item;
    }

    /// <summary>The icon a command shows in every menu (D-49), and this window's own for its actions.</summary>
    private static Image? MenuIcon(string? id) => id is not null && CommandIcons.Get(id) is { } icon ? new Image { Source = icon, Width = 16, Height = 16 } : null;

    private void ShowListMenu(Point point)
    {
        var menu = new ContextMenu { ItemsSource = FileItems().Concat([new Separator(), FindActionItem(CommandIds.FindHideSelected, "Hide selected items", HideSelected, icon: "find.hideSelected")]).ToList() };
        foreach (var item in menu.Items.OfType<MenuItem>())
            if (item.Tag is Func<(bool Enabled, string? Reason)> state) item.IsEnabled = state().Enabled;
        menu.Open(_list);
    }

    // ---- Searching ---------------------------------------------------------------------------------------------

    private bool IsSearching => _session is { Finished: false };

    /// <summary>The criteria the window shows.</summary>
    internal SearchCriteria Criteria => new()
    {
        Names = _names.Text ?? "*",
        LookIn = _within is null ? _lookIn.Text ?? string.Empty : string.Empty,
        Subfolders = _subfolders.IsChecked == true,
        IncludeHidden = _hidden.IsChecked == true,
        InsideArchives = _archives.IsChecked == true,
        Text = _text.Text ?? string.Empty,
        MatchCase = _matchCase.IsChecked == true,
        WholeWords = _wholeWords.IsChecked == true,
        Regex = _regex.IsChecked == true,
        Hex = _hex.IsChecked == true,
        Unicode = _unicode.IsChecked == true,
        Advanced = _advanced.Clone(),
    };

    private void SetAdvanced(AdvancedSearchCriteria advanced)
    {
        _advanced = advanced;
        string summary = advanced.Summary();
        _advancedSummary.Text = summary.Length == 0 ? "none" : summary;
        _advancedSummary.Classes.Set("muted", summary.Length == 0);
        _advancedReset.IsEnabled = summary.Length > 0;
    }

    private async Task EditAdvancedAsync()
    {
        if (_dialogs.IsOpen) return;
        if (await FindDialogs.AdvancedAsync(_dialogs, _advanced) is { } edited) SetAdvanced(edited);
    }

    private async Task EditIgnoredFoldersAsync()
    {
        if (_dialogs.IsOpen) return;
        if (await FindDialogs.IgnoredFoldersAsync(_dialogs, _services.Settings.SearchIgnoredFolders) is not { } edited) return;
        _services.Settings.SearchIgnoredFolders = edited;
        _services.SaveSettings();
        int on = edited.Count(e => e.Enabled);
        ShowNotification(on == 0 ? "Find searches every folder." : $"Find skips {Formatters.Plural(on, "folder", "folders")} from the next search on.");
    }

    /// <summary>Puts saved criteria in the window (where to search only when they say, and not within results).</summary>
    internal void Apply(SearchCriteria c, string? savedSearchName = null)
    {
        _applyingSavedSearch = savedSearchName is not null;
        try
        {
            _names.Text = string.IsNullOrWhiteSpace(c.Names) ? "*" : c.Names;
            if (_within is null && c.LookIn.Length > 0)
            {
                _lookIn.Text = c.LookIn;
                if (_requiresLocalChoice) _localChoiceMade = !string.IsNullOrWhiteSpace(_lookIn.Text);
            }
            _subfolders.IsChecked = c.Subfolders;
            _hidden.IsChecked = c.IncludeHidden;
            _archives.IsChecked = c.InsideArchives;
            _text.Text = c.Text;
            _matchCase.IsChecked = c.MatchCase;
            _wholeWords.IsChecked = c.WholeWords;
            _regex.IsChecked = c.Regex;
            _hex.IsChecked = c.Hex;
            _unicode.IsChecked = c.Unicode;
            SetAdvanced(c.Advanced.Clone());
        }
        finally { _applyingSavedSearch = false; }
        _loadedSearchName = savedSearchName;
        _loadedSearchHasScope = savedSearchName is not null && _within is null && !string.IsNullOrWhiteSpace(c.LookIn);
        UpdateScopeNotice();
    }

    private static string OriginDescription(Location origin) => origin.Scheme switch
    {
        Schemes.Sftp => "SFTP folder",
        Schemes.Ftp => "FTP folder",
        Schemes.Zip or Schemes.Archive => "folder inside an archive",
        Schemes.Computer => "This PC view",
        Schemes.Network => "network share list",
        Schemes.Mtp => "portable-device folder",
        _ => "current " + origin.Scheme + " view",
    };

    private void UpdateScopeNotice()
    {
        if (_within is not null)
        {
            _scopeNotice.Text = _loadedSearchName is { } name
                ? $"Loaded saved search \"{Formatters.SafeName(name)}\". The search remains within this result-set snapshot; its saved folders do not replace that scope."
                : "Find will search only this result-set snapshot.";
        }
        else if (_requiresLocalChoice)
        {
            string origin = OriginDescription(_origin!);
            _scopeNotice.Text = _loadedSearchName is { } name && _loadedSearchHasScope
                ? $"Opened from the {origin}. Loaded saved search \"{Formatters.SafeName(name)}\"; Look in now names its local folders. Find will not search the original provider."
                : _loadedSearchName is { } noScopeName
                    ? _localChoiceMade
                        ? $"Opened from the {origin}. Loaded saved search \"{Formatters.SafeName(noScopeName)}\" without folders; Look in keeps your previously chosen local scope."
                        : $"Opened from the {origin}. Loaded saved search \"{Formatters.SafeName(noScopeName)}\", but it has no local folders. Choose a local scope before searching."
                : _localChoiceMade
                    ? $"Opened from the {origin}. Find will search the local folders shown in Look in, not the original provider."
                    : $"Find cannot search the {origin}. Choose local folders in Look in, choose drives, or use local home before searching.";
        }
        else
        {
            _scopeNotice.Text = _loadedSearchName is { } name
                ? _loadedSearchHasScope
                    ? $"Loaded saved search \"{Formatters.SafeName(name)}\". Look in shows its search folders instead of the previously open folder."
                    : $"Loaded saved search \"{Formatters.SafeName(name)}\". Look in still shows the previously open folder."
                : string.Empty;
        }
        _scopeNotice.IsVisible = !string.IsNullOrEmpty(_scopeNotice.Text);
        _scopeNotice.Classes.Set("warning", _requiresLocalChoice && !_localChoiceMade);
        _scopeHost.IsVisible = _scopeNotice.IsVisible;
        _useLocalHome.IsVisible = _requiresLocalChoice && !_localChoiceMade;
        UpdateButtons();
    }

    private async Task SaveSearchAsync()
    {
        if (_dialogs.IsOpen) return;
        var saved = _services.Settings.SavedSearches;
        var r = await _dialogs.PromptAsync(new PromptOptions("Save search", "Name for these criteria (a saved search with the same name is replaced):")
        {
            Text = saved.FirstOrDefault(s => s.LoadOnOpen)?.Name ?? string.Empty,
            Validate = text => string.IsNullOrWhiteSpace(text) ? "Enter a name." : null,
            CheckboxText = "Load it whenever Find opens",
            ConfirmText = "Save",
        });
        if (r is null) return;
        string name = r.Text.Trim();
        saved.RemoveAll(s => string.Equals(s.Name, name, StringComparison.CurrentCultureIgnoreCase));
        if (r.Checked) foreach (var s in saved) s.LoadOnOpen = false;
        saved.Add(new SavedSearch { Name = name, Criteria = Criteria, LoadOnOpen = r.Checked });
        saved.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.CurrentCultureIgnoreCase));
        _services.SaveSettings();
        ShowNotification($"Saved the search \"{name}\"" + (r.Checked ? "; it loads whenever Find opens." : "."));
    }

    /// <summary>Saved searches: Enter loads one, Ctrl+Delete deletes, Insert marks the one loaded when Find opens.</summary>
    private async Task LoadSearchAsync()
    {
        if (_dialogs.IsOpen) return;
        var saved = _services.Settings.SavedSearches;
        if (saved.Count == 0)
        {
            ShowNotification("No saved searches yet: Options → Save search keeps the criteria shown.");
            return;
        }
        var items = saved.Select(s => new ChoiceItem(s.Name, FindDialogs.Describe(s.Criteria)) { Pinned = s.LoadOnOpen }).ToList();
        var r = await _dialogs.ChooseAsync(new ChoiceOptions("Saved searches", items)
        {
            AllowDelete = true,
            AllowPin = true,
            Hint = "Enter loads · Ctrl+Del deletes · Insert marks the search loaded whenever Find opens · Esc closes",
        });
        var list = saved.ToList();
        bool changed = false;
        foreach (int index in r.PinToggled)
        {
            bool on = !list[index].LoadOnOpen;
            foreach (var s in list) s.LoadOnOpen = false;
            list[index].LoadOnOpen = on;
            changed = true;
        }
        if (r.Index >= 0) Apply(list[r.Index].Criteria, list[r.Index].Name);
        foreach (int index in r.Deleted.OrderByDescending(i => i)) saved.Remove(list[index]);
        if (changed || r.Deleted.Count > 0) _services.SaveSettings();
        if (r.Index >= 0) ShowNotification($"Loaded \"{list[r.Index].Name}\". Enter searches.");
    }

    /// <summary>
    /// Starts a search; a refining one combines its matches with the items found so far when it finishes, and one for
    /// <paramref name="duplicates"/> groups the files it finds when it finishes.
    /// </summary>
    internal void StartSearch(RefineMode mode, DuplicateCriteria? duplicates = null)
    {
        if (_closed) return;
        ShowError(null);
        if (_requiresLocalChoice && !_localChoiceMade)
        {
            ShowError("Choose local folders in Look in before searching; Find cannot search the original provider.");
            return;
        }
        if (mode != RefineMode.Replace && _set is null) mode = RefineMode.Replace;
        var criteria = Criteria;
        var ignored = _services.Settings.SearchIgnoredFolders.Where(f => f.Enabled).Select(f => f.Folder).ToList();
        if (!criteria.TryBuildQuery(DateTime.UtcNow, ignored, _within, out var query, out var error, new ProviderArchiveMembers(_services.Providers), _services.Platform.HiddenData))
        {
            ShowError(error);
            return;
        }
        var history = _services.History;
        AppServices.RememberText(history.SearchNames, string.IsNullOrWhiteSpace(criteria.Names) ? "*" : criteria.Names);
        if (criteria.Text.Length > 0) AppServices.RememberText(history.SearchTexts, criteria.Text);
        if (_within is null) AppServices.RememberText(history.SearchFolders, criteria.LookIn.Trim());
        _cts?.Cancel();
        _grouping?.Cancel();
        _groups = [];
        _duplicates = mode == RefineMode.Replace ? duplicates : null;
        var title = TitleOf(criteria);
        var provenance = query!.Describe();
        _searchScope = provenance;
        // Refinement matches are private scratch data; only the displayed set needs a provider location.
        var found = mode == RefineMode.Replace
            ? _services.ResultSets.Create(title, provenance)
            : new ResultSet(Guid.NewGuid().ToString("N")[..12], title, provenance);
        found.FullFolders = true;
        _mode = mode;
        _appended = 0;
        if (mode == RefineMode.Replace)
        {
            _set = found;
            _refineScratch = null;
            ShowSet(found);
            Title = (_within is null ? "Find: " : "Find within results: ") + found.Title[("Search ".Length)..];
        }
        else
        {
            _refineScratch = found;
            _set!.Provenance += mode switch
            {
                RefineMode.Intersect => "; kept only those also matching " + query.Describe(),
                RefineMode.Subtract => "; removed those matching " + query.Describe(),
                _ => "; added " + query.Describe(),
            };
        }
        _session = new SearchSession(query, found);
        _cts = new CancellationTokenSource();
        var session = _session;
        var token = _cts.Token;
        _ = Task.Run(() => session.Run(token), token);
        _message.Text = string.Empty;
        UpdateButtons();
        _timer.Start();
        OnTick();
    }

    private static string TitleOf(SearchCriteria c)
    {
        var what = c.Text.Length > 0 ? $"\"{c.Text}\"" : string.IsNullOrWhiteSpace(c.Names) ? "*" : c.Names;
        return $"Search {what}";
    }

    private void ShowSet(ResultSet set)
    {
        var location = ResultSetProvider.LocationOf(set);
        if (_tab is null)
        {
            _tab = _panel.OpenTab(location);
            _scope = new CommandScope(_tab, _dialogs, this);
            _list.Tab = _tab;
            _placeholder.IsVisible = false;
        }
        else
        {
            _tab.Navigate(location, record: false);
        }
        _shownCount = 0;
        _lastRefresh = DateTime.UtcNow;
    }

    private void Stop()
    {
        _cts?.Cancel();
        _grouping?.Cancel();
    }

    /// <summary>Asks what makes files alike, then searches with the criteria shown and groups what it finds.</summary>
    private async Task FindDuplicatesAsync()
    {
        if (_dialogs.IsOpen) return;
        if (await FindDialogs.DuplicatesAsync(_dialogs) is not { } alike) return;
        StartSearch(RefineMode.Replace, alike);
    }

    /// <summary>
    /// Compares the found files off the UI thread (contents can take a while), then lists only the duplicates, each
    /// group together and named, in the order the groups were found.
    /// </summary>
    private async Task GroupDuplicatesAsync(DuplicateCriteria alike)
    {
        if (_set is not { } found) return;
        _grouping = new CancellationTokenSource();
        var token = _grouping.Token;
        var items = found.Snapshot().Select(s => s.Item).ToList();
        _status.Text = $"Comparing {Formatters.Plural(items.Count(i => !i.IsContainer), "file", "files")}…";
        _comparing = true;
        UpdateButtons();
        DuplicateResult result;
        try
        {
            var fs = _services.Platform.FileOperations;
            result = await Task.Run(() => DuplicateFinder.Find(items, alike, token, fs.GetFileIdentity), token);
        }
        catch (OperationCanceledException)
        {
            _status.Text = "Comparing stopped; the list shows everything found.";
            return;
        }
        finally
        {
            _comparing = false;
            UpdateButtons();
        }
        if (_closed || !ReferenceEquals(found, _set)) return;
        var groups = _services.ResultSets.Create(found.Title.Replace("Search", "Duplicates", StringComparison.Ordinal),
            found.Provenance + "; duplicates by " + Describe(alike));
        groups.FullFolders = true;
        groups.ShowsGroups = true;
        var relative = found.Snapshot().ToDictionary(s => s.Item, s => s.Relative);
        for (int g = 0; g < result.Groups.Count; g++)
        {
            var group = result.Groups[g];
            foreach (var item in group)
            {
                groups.Add(item, relative.GetValueOrDefault(item, string.Empty));
                groups.SetNote(item, $"group {g + 1} · {group.Count} files");
            }
        }
        groups.IsComplete = true;
        _groups = result.Groups;
        _set = groups;
        _searchScope = groups.Provenance;
        ShowSet(groups);
        // The groups keep the order found; a column header sorts them otherwise.
        _tab!.Listing.Sort = new Core.Listing.SortSpec(Core.Listing.SortField.None);
        Refresh(force: true);
        int files = result.Groups.Sum(g => g.Count);
        _status.Text = result.Groups.Count == 0
            ? "No duplicates among the found files."
            : $"{Formatters.Plural(result.Groups.Count, "group", "groups")} of duplicates · {Formatters.Plural(files, "file", "files")}";
        UpdateEmptyResults(new FindFeedback(_status.Text, string.Empty, string.Empty, _status.Text,
            "Comparison scope: " + _searchScope, false));
        if (result.Unreadable.Count > 0)
            ShowNotification($"{Formatters.Plural(result.Unreadable.Count, "file", "files")} could not be read and were left out: {string.Join(", ", result.Unreadable.Take(3).Select(Path.GetFileName))}{(result.Unreadable.Count > 3 ? ", …" : "")}", true);
        else if (result.SameFile.Count > 0 || result.Links.Count > 0)
        {
            var notes = new List<string>();
            if (result.SameFile.Count > 0)
                notes.Add($"{Formatters.Plural(result.SameFile.Count, "name was", "names were")} left out as other names of a listed file (a hard link, or a path through a junction): not copies");
            if (result.Links.Count > 0)
                notes.Add($"{Formatters.Plural(result.Links.Count, "link", "links")} to files left out: a link is not a copy");
            ShowNotification(string.Join("; ", notes) + ".", false);
        }
    }

    private static string Describe(DuplicateCriteria alike)
    {
        var parts = new List<string>();
        if ((alike & DuplicateCriteria.Name) != 0) parts.Add("name");
        if ((alike & DuplicateCriteria.Content) != 0) parts.Add("content");
        else if ((alike & DuplicateCriteria.Size) != 0) parts.Add("size");
        return string.Join(" and ", parts);
    }

    /// <summary>Marks every duplicate but the first of its group (the copies to delete or move away).</summary>
    private void SelectAllButOnePerGroup()
    {
        if (_tab is null || _groups.Count == 0) return;
        var extra = _groups.SelectMany(g => g.Skip(1)).ToHashSet();
        var listing = _tab.Listing;
        for (int row = 0; row < listing.VisibleCount; row++)
        {
            if (listing.GetVisible(row).Kind == EntryKind.Parent) continue;
            listing.SetMark(row, extra.Contains(listing.GetItemRef(listing.GetStoreIndex(row))));
        }
        ShowNotification($"Selected {Formatters.Plural(extra.Count, "extra copy", "extra copies")}; the first file of each group stays unselected.");
    }

    private void OnTick()
    {
        if (_session is not { } session || _set is null) return;
        bool finished = session.Finished;
        if (_mode == RefineMode.Append && _refineScratch is { } scratch)
        {
            // New finds join the list as they come.
            var snapshot = scratch.Snapshot();
            if (snapshot.Count > _appended)
            {
                _set.AddRange(snapshot.Skip(_appended));
                _appended = snapshot.Count;
            }
        }
        if (finished)
        {
            _timer.Stop();
            if (_mode is RefineMode.Intersect or RefineMode.Subtract && _refineScratch is { } refine)
            {
                if (refine.IsComplete)
                {
                    var kept = Refine.Combine(_set.Snapshot(), refine.Snapshot(), _mode).Select(k => k.Item).ToHashSet();
                    _set.Remove(_set.Snapshot().Select(s => s.Item).Where(i => !kept.Contains(i)).ToList());
                }
                else
                {
                    _message.Text = "The search stopped before it finished, so the list was left as it was.";
                }
            }
            Refresh(force: true);
            UpdateButtons();
            if (_duplicates is { } alike && _mode == RefineMode.Replace)
            {
                _duplicates = null;
                if (_set.IsComplete) _ = GroupDuplicatesAsync(alike);
                else _message.Text = "The search stopped before it finished, so duplicates were not compared.";
            }
            if (session.Log.Count > 0 && _services.Settings.SearchLogOnErrors && !_closed) _ = ShowLogAsync();
        }
        else
        {
            Refresh(force: false);
        }
        UpdateStatus();
    }

    /// <summary>Shows new finds, at most about once a second while a search runs (each look checks every item again).</summary>
    private void Refresh(bool force)
    {
        if (_tab is null || _set is null) return;
        int count = _set.Count;
        if (!force && (count == _shownCount || (_shownCount > 0 && DateTime.UtcNow - _lastRefresh < TimeSpan.FromMilliseconds(900)))) return;
        _shownCount = count;
        _lastRefresh = DateTime.UtcNow;
        _tab.Refresh();
    }

    private void UpdateStatus()
    {
        if (_session is not { } s || _set is null) return;
        var log = s.Log;
        bool complete = _refineScratch?.IsComplete ?? _set.IsComplete;
        var feedback = FindFeedback.Create(s.Finished, complete, _set.Count, s.FoldersVisited, s.FilesExamined,
            s.Matches, s.CurrentFolder, log, s.RegexTimedOut, _searchScope);
        // Announce the outcome once. The rapidly changing folder and counters stay out of the live region.
        AutomationProperties.SetLiveSetting(_status, s.Finished ? AutomationLiveSetting.Polite : AutomationLiveSetting.Off);
        AutomationProperties.SetLiveSetting(_qualifications, s.Finished ? AutomationLiveSetting.Polite : AutomationLiveSetting.Off);
        _status.Text = feedback.Headline;
        _qualifications.Text = feedback.Qualifications;
        _qualifications.IsVisible = feedback.Qualifications.Length > 0;
        _activity.Text = feedback.Activity;
        _logButton.IsEnabled = log.Count > 0;
        _logButton.Content = log.Count > 0 ? $"Log ({log.Count:N0})" : "Log";
        UpdateEmptyResults(feedback);
    }

    private void UpdateArchiveContentNotice()
    {
        _archiveContentNotice.IsVisible = _archives.IsChecked == true && !string.IsNullOrWhiteSpace(_text.Text);
    }

    private void UpdateEmptyResults(FindFeedback feedback)
    {
        bool empty = _set is { Count: 0 };
        bool listHadFocus = _list.IsKeyboardFocusWithin;
        _emptyResults.IsVisible = empty;
        _list.IsVisible = !empty && _set is not null;
        if (!empty) return;
        if (listHadFocus) _names.Focus();
        _emptyHeadline.Text = feedback.EmptyHeadline;
        _emptyExplanation.Text = feedback.EmptyExplanation;
        _emptyLog.IsVisible = feedback.HasLog;
    }

    private void UpdateButtons()
    {
        bool searching = IsSearching || _comparing;
        _find.IsEnabled = !_requiresLocalChoice || _localChoiceMade;
        _stop.IsEnabled = searching;
        _skip.IsEnabled = searching && _within is null;
    }

    private void ShowError(string? error)
    {
        _error.Text = error ?? string.Empty;
        _error.IsVisible = error is not null;
    }

    // ---- The search log -----------------------------------------------------------------------------------------

    /// <summary>What was not searched; Enter shows the folder in the active panel.</summary>
    private async Task ShowLogAsync()
    {
        if (_session is not { } session || _dialogs.IsOpen) return;
        var log = session.Log;
        if (log.Count == 0) return;
        var items = log.Select(e => new ChoiceItem(e.Path, e.Kind switch
        {
            SearchLogKind.Inaccessible => "Not accessible" + (e.Detail is null ? string.Empty : ": " + e.Detail),
            SearchLogKind.Ignored => "On the ignore list",
            SearchLogKind.Skipped => "Skipped while searching",
            SearchLogKind.Warning => "Search warning" + (e.Detail is null ? string.Empty : ": " + e.Detail),
            _ => "No longer exists",
        })).ToList();
        var r = await _dialogs.ChooseAsync(new ChoiceOptions("Search log", items) { Hint = "Skipped items and warnings · Enter shows it in the active panel · Esc closes" });
        if (r.Index < 0) return;
        var entry = log[r.Index];
        if (entry.Parent is { } parent)
        {
            ShowInMainPanel(parent, entry.Name);
            return;
        }
        string folder = Directory.Exists(entry.Path) ? entry.Path : Path.GetDirectoryName(entry.Path) ?? entry.Path;
        string? name = Directory.Exists(entry.Path) ? null : Path.GetFileName(entry.Path);
        ShowInMainPanel(Location.FileSystem(folder), name);
    }

    // ---- Acting on found items --------------------------------------------------------------------------------

    private bool TryFocused(out ItemRef item)
    {
        item = null!;
        if (_tab is null || !_tab.Listing.TryGetFocused(out var e) || e.Kind == EntryKind.Parent) return false;
        item = _tab.Listing.GetItemRef(_tab.Listing.FocusedStoreIndex);
        return true;
    }

    /// <summary>Runs a panel command on the found items; its dialogs open in this window.</summary>
    internal void Run(string id)
    {
        if (_scope is null) return;
        _ = _vm.ExecuteInAsync(_scope, id);
    }

    /// <summary>Enter: a folder opens in the active panel; a file opens as the system opens it.</summary>
    private void OpenFocused()
    {
        if (!TryFocused(out var item)) return;
        if (item.IsContainer) FocusInPanel(enter: true);
        else Run(CommandIds.OpenWithSystem);
    }

    /// <summary>Space: the active panel shows the item's folder with the item focused (or, entering, the folder itself).</summary>
    private void FocusInPanel(bool enter)
    {
        if (!TryFocused(out var item)) return;
        if (enter && item.IsContainer && item.FileSystemPath is { } folder) ShowInMainPanel(Location.FileSystem(folder), null);
        else ShowInMainPanel(item.Parent, item.Name);
    }

    private void ShowInMainPanel(Location location, string? focusName)
    {
        var tab = _vm.Workspace.ActiveTab;
        if (tab is null) return;
        tab.Navigate(location, focusName);
        if (_vm.View.TopLevel is Window main) main.Activate();
        _vm.View.FocusActivePanel();
    }

    /// <summary>The found items as a result set in the active panel (the set stays shared with this window).</summary>
    private void ShowInPanel()
    {
        if (_set is null) return;
        _vm.OpenResultSet(_set, IsSearching ? _cts : null);
        if (_vm.View.TopLevel is Window main) main.Activate();
        _vm.View.FocusActivePanel();
    }

    /// <summary>Removes the selected items from the list; nothing is deleted.</summary>
    private void HideSelected()
    {
        if (_tab is null || _set is null) return;
        var selection = _tab.Listing.GetSelection();
        int hidden = _set.Remove(selection);
        _tab.Refresh();
        UpdateStatus();
        ShowNotification($"{Formatters.Plural(hidden, "item was", "items were")} hidden from the list. Nothing was deleted.");
    }

    /// <summary>Keeps the first item of each name and hides the others.</summary>
    private void HideDuplicateNames()
    {
        if (_tab is null || _set is null) return;
        var seen = new HashSet<string>(Core.FileSystem.PathUtil.SafetyComparer);
        var repeats = _set.Snapshot().Select(s => s.Item).Where(i => !seen.Add(i.Name)).ToList();
        int hidden = _set.Remove(repeats);
        _tab.Refresh();
        UpdateStatus();
        ShowNotification(hidden == 0 ? "No name is listed twice." : $"{Formatters.Plural(hidden, "item with a repeated name was", "items with repeated names were")} hidden. Nothing was deleted.");
    }

    private async Task DragAsync(PointerPressedEventArgs press)
    {
        if (_tab is null) return;
        var selection = _tab.Listing.GetSelection();
        var paths = selection.Select(s => s.FileSystemPath).OfType<string>().Take(10_000).ToList();
        ItemSources.Release(selection);
        if (paths.Count == 0) return;
        var transfer = new DataTransfer();
        foreach (var p in paths)
        {
            Avalonia.Platform.Storage.IStorageItem? item = Directory.Exists(p)
                ? await StorageProvider.TryGetFolderFromPathAsync(p)
                : await StorageProvider.TryGetFileFromPathAsync(p);
            if (item is not null) transfer.Add(DataTransferItem.CreateFile(item));
        }
        await DragDrop.DoDragDropAsync(press, transfer, DragDropEffects.Copy | DragDropEffects.Move | DragDropEffects.Link);
    }

    // ---- Keys --------------------------------------------------------------------------------------------------

    private void OnPreviewKeyDown(object? sender, KeyEventArgs e)
    {
        if (_dialogs.IsOpen || KeyMapper.IsModifierKey(e.Key)) return;
        if (_completion.Shown.Count > 0 && e.Key is Key.Escape or Key.Enter or Key.Up or Key.Down or Key.Tab) return;
        bool inList = _tab is not null && (_list.IsFocused || _list.IsKeyboardFocusWithin);
        if (!inList && e.Key == Key.Enter && FocusManager?.GetFocusedElement() is Button) return;
        // Native editing keys keep working in the criteria even if a Find action is mapped to one.
        if (!inList && FocusManager?.GetFocusedElement() is TextBox && e.KeyModifiers == KeyModifiers.Control &&
            e.Key is (Key.A or Key.C or Key.V or Key.X or Key.Y or Key.Z)) return;
        if (KeyMapper.ToChord(e.Key, e.KeyModifiers) is not { } chord) return;
        var id = inList
            ? _services.Keymap.Resolve(chord, CommandContext.FindResults, CommandContext.Find, CommandContext.Panel)
            : _services.Keymap.Resolve(chord, CommandContext.FindCriteria, CommandContext.Find);
        if (ExecuteFindCommand(id)) { e.Handled = true; return; }
        if (!inList) return;
        if (id is null || !ListCommands.Contains(id)) return;
        // With Alt held (Alt+Enter), after Avalonia's access-key handler saw it (or releasing Alt opens the menu bar).
        Controls.AltChords.Handle(this, e);
        Run(id);
    }

    private static bool IsFindCommand(string? id) => id is
        CommandIds.FindRun or CommandIds.FindIntersect or CommandIds.FindSubtract or CommandIds.FindAppend or
        CommandIds.FindAdvanced or CommandIds.FindHideSelected or CommandIds.FindOpen or CommandIds.FindShowInPanel or
        CommandIds.FindStopOrClose or CommandIds.FindSkipCurrent;

    private bool ExecuteFindCommand(string? id)
    {
        switch (id)
        {
            case CommandIds.FindRun: StartSearch(RefineMode.Replace); return true;
            case CommandIds.FindIntersect: StartSearch(RefineMode.Intersect); return true;
            case CommandIds.FindSubtract: StartSearch(RefineMode.Subtract); return true;
            case CommandIds.FindAppend: StartSearch(RefineMode.Append); return true;
            case CommandIds.FindAdvanced: _ = EditAdvancedAsync(); return true;
            case CommandIds.FindHideSelected: HideSelected(); return true;
            case CommandIds.FindOpen: OpenFocused(); return true;
            case CommandIds.FindShowInPanel: FocusInPanel(enter: false); return true;
            case CommandIds.FindStopOrClose:
                if (IsSearching || _comparing) Stop();
                else Close();
                return true;
            case CommandIds.FindSkipCurrent: _session?.SkipCurrentFolder(); return true;
            default: return false;
        }
    }

    // ---- IViewActions: commands run for the found items report and ask here ------------------------------------

    public void FocusActivePanel()
    {
        if (_tab is not null) _list.Focus();
        else _names.Focus();
    }

    public Task<string?> RenameInlineAsync(PromptOptions options) => Task.FromResult<string?>(null);

    public void FocusPathBox() => _lookIn.Focus();

    public void FocusPanelFilter() { }

    public void FocusCommandLine() { }

    public bool FocusCommandSearch() => false;

    public void CloseWhenIdle() { }

    public void OpenMenuBar() { }

    public void ShowContextMenu() => ShowListMenu(default);

    public void ShowNotification(string message, bool isError = false)
    {
        _message.Text = message;
        _message.Classes.Set("error", isError);
    }

    public void ReloadChrome()
    {
        Classes.Set("comfortable", _vm.ComfortableDensity);
        _list.FontSize = _vm.ListFontSize;
        _list.ComfortableRows = _vm.ComfortableDensity;
        BuildMenu();
    }

    IClipboard? IViewActions.Clipboard => Clipboard;

    TopLevel? IViewActions.TopLevel => this;

    // ---- For tests ---------------------------------------------------------------------------------------------

    internal OverlayDialogService Dialogs => _dialogs;

    internal TabViewModel? ResultsTab => _tab;

    internal FileListControl List => _list;

    internal SearchSession? Session => _session;

    /// <summary>The names of the found items, in the order found.</summary>
    internal IReadOnlyList<string> Found => _set?.Snapshot().Select(s => s.Item.Name).ToList() ?? [];

    /// <summary>Whether the last search, and the refining after it, have finished.</summary>
    internal bool IsIdle => _session is null || _session.Finished && !_timer.IsEnabled;

    internal TextBox NamesBox => _names;

    internal TextBox LookInBox => _lookIn;

    internal int CompletionSuggestionCount => _completion.Shown.Count;

    internal Menu FindMenu => _menu;

    internal string IntroText => _placeholder.Text ?? string.Empty;

    internal string Error => _error.IsVisible ? _error.Text ?? string.Empty : string.Empty;

    internal void OpenLog() => _ = ShowLogAsync();

    internal void OpenAdvanced() => _ = EditAdvancedAsync();

    internal void OpenIgnoredFolders() => _ = EditIgnoredFoldersAsync();

    internal void OpenSaveSearch() => _ = SaveSearchAsync();

    internal void OpenSavedSearches() => _ = LoadSearchAsync();

    internal void OpenDuplicates() => _ = FindDuplicatesAsync();

    internal void SelectDuplicateCopies() => SelectAllButOnePerGroup();

    internal IReadOnlyList<IReadOnlyList<ItemRef>> Groups => _groups;

    internal string AdvancedSummary => _advancedSummary.Text ?? string.Empty;

    internal void SetInsideArchives(bool on) => _archives.IsChecked = on;

    internal void SetContent(string text, bool hex, bool unicode = false)
    {
        _text.Text = text;
        _hex.IsChecked = hex;
        _unicode.IsChecked = unicode;
    }

    internal bool UnicodeAvailable => _unicode.IsEnabled;

    internal string Status => string.Join(" · ", new[] { _status.Text, _qualifications.Text }.Where(t => !string.IsNullOrEmpty(t)));

    internal string EmptyResultHeadline => _emptyResults.IsVisible ? _emptyHeadline.Text ?? string.Empty : string.Empty;

    internal string EmptyResultExplanation => _emptyResults.IsVisible ? _emptyExplanation.Text ?? string.Empty : string.Empty;

    internal string Message => _message.Text ?? string.Empty;
}
