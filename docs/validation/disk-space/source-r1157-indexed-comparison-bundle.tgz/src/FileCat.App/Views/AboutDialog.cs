using System.Reflection;
using System.Runtime.InteropServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Automation.Peers;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Input.Platform;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using FileCat.App.Controls;
using FileCat.App.Services;
using FileCat.App.ViewModels;


namespace FileCat.App.Views;

/// <summary>
/// About FileCat (Help → About): who made it, what it runs on, and where it keeps its data, dressed in the current
/// theme: Cyberpunk's circuitry, Psychedelic's drifting light, Steampunk's iron and glass behind the name, a text-mode
/// box with a cat for DOS Commander, an accent glow for Classic, and nothing but clear text for High Contrast. The
/// details copy as plain text for a bug report.
/// </summary>
internal static class AboutDialog
{
    public const string Author = "Marek Střihavka";
    public const string AuthorMail = "marek.strihavka@gmail.com";
    private const string Tagline = "Multiplatform File Manager on steroids";

    public static async Task ShowAsync(MainViewModel vm)
    {
        string version = Version();
        var facts = Facts(vm);
        var palette = ThemeManager.Current;
        using var logo = palette.Name == ThemePalette.DosCommander.Name ? null : Logo();
        var logoImage = new Image { Source = logo, Width = 84, Height = 84 };
        try
        {
            var body = new StackPanel { Spacing = 14, MaxWidth = 600 };
            body.Children.Add(Header(palette, version, logoImage));
            var made = new WrapPanel { ItemSpacing = 6, LineSpacing = 2 };
            made.Children.Add(new TextBlock { Text = "Made by " + Author, VerticalAlignment = VerticalAlignment.Center });
            var mail = new HyperlinkButton { Content = AuthorMail, NavigateUri = new Uri("mailto:" + AuthorMail), Padding = new Thickness(2, 0) };
            Avalonia.Automation.AutomationProperties.SetName(mail, "Write to " + Author);
            made.Children.Add(mail);
            body.Children.Add(made);
            body.Children.Add(FactsGrid(facts));
            var actions = new WrapPanel { ItemSpacing = 8, LineSpacing = 6 };
            var status = new TextBlock { IsVisible = false, Classes = { "muted" } };
            AutomationProperties.SetAutomationId(status, "About support action status");
            AutomationProperties.SetLiveSetting(status, AutomationLiveSetting.Polite);
            void Report(string message) { status.Text = message; status.IsVisible = true; }

            var copy = new Button { Content = "Copy details" };
            copy.Click += async (_, _) =>
            {
                try
                {
                    if (vm.View.Clipboard is not { } clipboard) { Report("Clipboard unavailable."); return; }
                    await clipboard.SetTextAsync(DetailsText(version, facts));
                    Report("Copied details.");
                }
                catch (Exception)
                {
                    Report("Could not copy details to the clipboard.");
                }
            };
            actions.Children.Add(copy);
            foreach (var (label, path) in SupportFolders(vm.Services.Paths.SettingsDirectory, vm.Services.Paths.LocalDirectory))
            {
                var open = new Button { Content = label };
                AutomationProperties.SetHelpText(open, $"Open {path} in a new tab without replacing the current tab.");
                open.Click += (_, _) =>
                {
                    if (vm.Workspace.ActivePanel is not { } panel) { Report("No panel is available to open the folder."); return; }
                    panel.OpenTab(FileCat.Core.Resources.Location.FileSystem(path));
                    Report($"Opened {path} in a new tab.");
                };
                actions.Children.Add(open);
            }
            body.Children.Add(actions);
            body.Children.Add(status);
            await vm.Dialogs.ShowCustomAsync("About FileCat", body,
                [new DialogButton("Close", "close", IsDefault: true, IsCancel: true)]);
        }
        finally
        {
            // The dialog owns this bitmap. Retired controls must not keep a disposed source in a later frame.
            logoImage.Source = null;
        }
    }

    /// <summary>The build's informational version, with its recorded source commit when available.</summary>
    internal static string Version()
    {
        var assembly = typeof(MainViewModel).Assembly;
        string? informational = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion;
        if (string.IsNullOrEmpty(informational)) return assembly.GetName().Version?.ToString() ?? "?";
        int plus = informational.IndexOf('+');
        // "1.0.0-dev+0874b79c…" reads as "1.0.0-dev (0874b79)".
        return plus < 0 ? informational : $"{informational[..plus]} ({informational[(plus + 1)..Math.Min(informational.Length, plus + 8)]})";
    }

    /// <summary>What a bug report wants to know, in the order it matters.</summary>
    internal static List<(string Label, string Value)> Facts(MainViewModel vm)
    {
        var services = vm.Services;
        var paths = services.Paths;
        // The platform names the system as people know it ("Windows 11 (build 26220, x64)").
        string system = services.Platform.Name;
        if (RuntimeInformation.ProcessArchitecture != RuntimeInformation.OSArchitecture) system += $" · FileCat runs as {RuntimeInformation.ProcessArchitecture.ToString().ToLowerInvariant()}";
        var facts = new List<(string, string)>
        {
            ("System", system),
            // Who FileCat runs as, and with which rights ("marek (administrator, not elevated)"), as its title says.
            ("Account", services.Shell.Account.Describe()),
            ("Runtime", $"{RuntimeInformation.FrameworkDescription} · Avalonia {typeof(Application).Assembly.GetName().Version?.ToString(3)}"),
            ("Theme", ThemeManager.Current.DisplayName),
            ("Profile", paths.ProfileName + (paths.IsPortable ? " (portable)" : "")),
            ("Settings", paths.SettingsDirectory),
            ("Local data", paths.LocalDirectory),
        };
        return facts;
    }

    internal static string DetailsText(string version, IEnumerable<(string Label, string Value)> facts) =>
        $"FileCat {version}\n{Tagline}\nMade by {Author} ({AuthorMail})\n" + string.Join("\n", facts.Select(f => $"{f.Label}: {f.Value}"));

    internal static IReadOnlyList<(string Label, string Path)> SupportFolders(string settings, string local)
    {
        var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
        bool same = string.Equals(Path.TrimEndingDirectorySeparator(Path.GetFullPath(settings)),
            Path.TrimEndingDirectorySeparator(Path.GetFullPath(local)), comparison);
        return same ? [("Open data folder", settings)] :
            [("Open settings folder", settings), ("Open local data folder", local)];
    }

    private static Control FactsGrid(List<(string Label, string Value)> facts)
    {
        var grid = new Grid { ColumnDefinitions = new ColumnDefinitions("Auto,*"), RowSpacing = 3, ColumnSpacing = 14 };
        for (int i = 0; i < facts.Count; i++)
        {
            grid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            var label = new TextBlock { Text = facts[i].Label, Classes = { "muted" } };
            // The value says what it is to a screen reader, so the label alone would be read twice.
            AutomationProperties.SetAccessibilityView(label, AccessibilityView.Raw);
            // Selectable, so a path can be copied as it is.
            var value = new FactValue(facts[i].Label) { Text = facts[i].Value, TextWrapping = TextWrapping.Wrap };
            Grid.SetRow(label, i);
            Grid.SetRow(value, i);
            Grid.SetColumn(value, 1);
            grid.Children.Add(label);
            grid.Children.Add(value);
        }
        return grid;
    }

    /// <summary>
    /// A fact's value, which a screen reader names with its label ("Theme: Classic", not "Classic"): a text block's own
    /// automation name is its text, whatever name it is given.
    /// </summary>
    private sealed class FactValue(string label) : SelectableTextBlock
    {
        protected override Type StyleKeyOverride => typeof(SelectableTextBlock);

        protected override AutomationPeer OnCreateAutomationPeer() => new FactValuePeer(this, label);

        private sealed class FactValuePeer(FactValue owner, string label) : ControlAutomationPeer(owner)
        {
            protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.Text;
            protected override string GetClassNameCore() => nameof(SelectableTextBlock);
            protected override string GetNameCore() => $"{label}: {owner.Text}";
        }
    }

    // ---- The header, in the theme's own dress --------------------------------------------------------------------

    private static Control Header(ThemePalette palette, string version, Image logoImage)
    {
        var band = new Border { Height = 132, CornerRadius = new CornerRadius(6), ClipToBounds = true, BorderThickness = new Thickness(1), BorderBrush = Brush(palette.Border) };
        var layers = new Grid();
        band.Child = layers;
        if (palette.Name == ThemePalette.DosCommander.Name)
        {
            band.Background = Brush(palette.Panel);
            layers.Children.Add(TextModeBox(palette, version));
            return band;
        }
        switch (palette.Effect)
        {
            case ThemeEffect.None when palette.Name == ThemePalette.HighContrast.Name:
                band.Background = Brush(palette.Card);
                break;
            case ThemeEffect.None:
                // Classic and Classic Dark: the accent's glow fading into the card.
                band.Background = new LinearGradientBrush
                {
                    StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative),
                    EndPoint = new RelativePoint(1, 1, RelativeUnit.Relative),
                    GradientStops =
                    {
                        new GradientStop(WithAlpha(palette.ActiveAccent, (byte)(palette.IsDark ? 0x66 : 0x40)), 0),
                        new GradientStop(WithAlpha(palette.TargetAccent, (byte)(palette.IsDark ? 0x22 : 0x18)), 0.7),
                        new GradientStop(Color.Parse(palette.Card), 1),
                    },
                };
                break;
            default:
                // The window's own backdrop, drawn for the band: circuitry, drifting light, or iron with glass above and below.
                band.Background = Brush(palette.Window);
                layers.Children.Add(new ThemeBackdrop { GlassBands = (26, 106) });
                break;
        }
        var row = new Grid { ColumnDefinitions = new ColumnDefinitions("Auto,*"), ColumnSpacing = 18,
            Margin = new Thickness(20, 0), VerticalAlignment = VerticalAlignment.Center };
        row.Children.Add(logoImage);
        var words = new StackPanel { Spacing = 2, VerticalAlignment = VerticalAlignment.Center };
        var name = new TextBlock { Text = "FileCat", FontSize = 30, FontWeight = FontWeight.Bold };
        switch (palette.Effect)
        {
            case ThemeEffect.Psychedelic:
                name.Foreground = new LinearGradientBrush
                {
                    StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative),
                    EndPoint = new RelativePoint(1, 0, RelativeUnit.Relative),
                    GradientStops =
                    {
                        new GradientStop(Color.Parse(palette.ActiveAccent), 0),
                        new GradientStop(Color.Parse(palette.SearchHit), 0.5),
                        new GradientStop(Color.Parse(palette.TargetAccent), 1),
                    },
                };
                break;
            case ThemeEffect.Steampunk:
                name.Foreground = Brush(palette.HeaderText);
                break;
            case ThemeEffect.Cyberpunk:
                name.Foreground = Brush(palette.ActiveAccent);
                break;
        }
        words.Children.Add(name);
        words.Children.Add(new TextBlock
        {
            Text = palette.Effect switch
            {
                ThemeEffect.Cyberpunk => "$ filecat --version  " + version,
                ThemeEffect.Steampunk => "Version " + version + " · Est. MMXXVI",
                _ => "Version " + version,
            },
            Classes = { "muted" },
            TextWrapping = TextWrapping.Wrap,
        });
        words.Children.Add(new TextBlock { Text = Tagline, TextWrapping = TextWrapping.Wrap, MaxWidth = 440 });
        // Over drifting light or riveted iron the words sit on a dark glass, so they stay readable.
        var wordHost = palette.Effect is ThemeEffect.Psychedelic or ThemeEffect.Steampunk
            ? new Border { Background = new SolidColorBrush(Color.FromArgb(0x8C, 0x10, 0x08, 0x18)), CornerRadius = new CornerRadius(8), Padding = new Thickness(12, 6), Child = words }
            : (Control)words;
        Grid.SetColumn(wordHost, 1);
        row.Children.Add(wordHost);
        layers.Children.Add(row);
        return band;
    }

    /// <summary>DOS Commander: a double-lined box in the text screen's colors, with a cat where the logo would be.</summary>
    private static Control TextModeBox(ThemePalette palette, string version)
    {
        string[] cat = [" /\\_/\\ ", "( o.o )", " > ^ < "];
        string[] words = ["FileCat " + version, "File manager and", "system-resource navigator"];
        int inner = Math.Max(40, words.Max(w => w.Length) + cat[0].Length + 6);
        var text = new TextBlock
        {
            FontFamily = new FontFamily(palette.FontFamily ?? "Cascadia Mono, Consolas, monospace"),
            FontSize = 15,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = new InlineCollection(),
        };
        var frame = Brush(palette.Text);
        text.Inlines.Add(new Run("╔" + new string('═', inner) + "╗\n") { Foreground = frame });
        for (int i = 0; i < 3; i++)
        {
            text.Inlines.Add(new Run("║  ") { Foreground = frame });
            text.Inlines.Add(new Run(cat[i]) { Foreground = Brush(palette.TextMarked) });
            text.Inlines.Add(new Run("   ") { Foreground = frame });
            string line = words[i].PadRight(inner - cat[i].Length - 5);
            text.Inlines.Add(new Run(line) { Foreground = i == 0 ? Brush(palette.TextMarked) : Brush(palette.Text), FontWeight = i == 0 ? FontWeight.Bold : FontWeight.Normal });
            text.Inlines.Add(new Run("║" + (i < 2 ? "\n" : "")) { Foreground = frame });
        }
        text.Inlines.Add(new Run("\n╚" + new string('═', inner) + "╝") { Foreground = frame });
        return text;
    }

    private static Bitmap? Logo()
    {
        try
        {
            using var stream = AssetLoader.Open(new Uri("avares://FileCat/Assets/filecat.png"));
            return new Bitmap(stream);
        }
        catch (Exception ex) when (ex is IOException or FileNotFoundException or InvalidOperationException)
        {
            return null;
        }
    }

    private static IBrush Brush(string hex) => new SolidColorBrush(Color.Parse(hex));

    private static Color WithAlpha(string hex, byte alpha)
    {
        var c = Color.Parse(hex);
        return Color.FromArgb(alpha, c.R, c.G, c.B);
    }
}
