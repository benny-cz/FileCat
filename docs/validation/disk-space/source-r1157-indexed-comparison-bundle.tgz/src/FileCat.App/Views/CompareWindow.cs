using System.Globalization;
using System.Text;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using Avalonia.VisualTree;
using FileCat.App.Controls;
using FileCat.App.Services;
using FileCat.App.ViewModels;
using FileCat.Core.Compare;
using FileCat.Core.Content;
using FileCat.Core.Resources;

namespace FileCat.App.Views;

/// <summary>One row of the side-by-side view: a line on either side (or a gap), how they relate, and a note row's text.</summary>
public sealed record CompareRow(DiffKind Kind, int? LeftLine, string LeftText, int? RightLine, string RightText, bool EndingDiffers = false, string? Note = null)
{
    // A list-item name must not stringify megabytes of source text. Full source text has its own selectable fields.
    public override string ToString() => $"{Kind}: left {(LeftLine is { } left ? $"line {left:N0}" : "gap")}, right {(RightLine is { } right ? $"line {right:N0}" : "gap")}";
}

/// <summary>
/// File comparison (plan §16.2, TV-08): text side by side with within-line changes, or both files' bytes side by side
/// (after Salamander's File Comparator). Every difference is listed and can be gone to, first to last. Both sides
/// scroll together because each row holds both. The summary claims "identical" only when every byte matched; a region
/// that could not be aligned within limits is shown and labelled, never presented as exact. A file that changes after
/// it was compared is reported when the window is activated again, and F5 compares anew.
/// </summary>
public sealed class CompareWindow : Window
{
    // Screen readers follow a list's focused row and, on Linux, hear focus after window activation.
    protected override Avalonia.Automation.Peers.AutomationPeer OnCreateAutomationPeer() =>
        new FileCat.App.Controls.DescendantFocusWindowAutomationPeer(this);

    private static readonly IBrush UnalignedBrush = new SolidColorBrush(Color.FromArgb(0x30, 0x90, 0x90, 0xA0));
    /// <summary>At most this many differences are listed to choose from; the arrows go through all of them.</summary>
    public const int MaxListed = 20_000;
    private const string BytesHint = "Select byte range (Alt+B) chooses a side, offset and count; Ctrl+C copies selected bytes as hex. Pointer selection also works.";

    private IContentSource _left, _right;
    private ViewSource _leftView, _rightView;
    private readonly string _leftName, _rightName;
    private Func<(IContentSource Left, IContentSource Right)>? _reopen;
    private Func<Task<(IContentSource Left, IContentSource Right)>>? _reopenAsync;
    private bool CanReopen => _reopen is not null || _reopenAsync is not null;
    private readonly ListBox _rows = new();
    private readonly CompareLineDetails _lineDetails;
    private readonly CompareTextView _textView;
    private readonly Grid _textBody = new() { RowDefinitions = RowDefinitions.Parse("*,1,*") };
    private readonly Button _fullLine = new() { Content = "Full-line details", VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _smallerText = new() { Content = "Text −" };
    private readonly Button _largerText = new() { Content = "Text +" };
    private readonly TextBlock _contentSize = new() { Classes = { "small" }, VerticalAlignment = VerticalAlignment.Center };
    private readonly WrapPanel _textTools = new() { Orientation = Orientation.Horizontal, IsVisible = false, Margin = new Thickness(8, 0, 8, 2) };
    private readonly WrapPanel _findBar = new() { Orientation = Orientation.Horizontal, IsVisible = false, Margin = new Thickness(8, 0, 8, 2) };
    private readonly ComboBox _copySide = new() { ItemsSource = new[] { "Left source", "Right source" }, SelectedIndex = 0, MinWidth = 120 };
    private readonly Button _copySelection = new() { Content = "Copy selection" };
    private readonly Button _copyLine = new() { Content = "Copy line" };
    private readonly Button _copyDifference = new() { Content = "Copy difference" };
    private readonly TextBlock _textActionStatus = new() { Classes = { "muted", "small" }, TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _findToggle = new() { Content = "Find…" };
    private readonly Button _closeFind = new() { Content = "Close Find" };
    private readonly TextBox _findText = new() { Width = 210, PlaceholderText = "Find in comparison",
        Classes = { "searchPending" } };
    private readonly ComboBox _findSide = new() { ItemsSource = new[] { "Both shown sides", "Left shown side", "Right shown side" }, SelectedIndex = 0, MinWidth = 150 };
    private readonly CheckBox _findChanged = new() { Content = "Changed rows only", VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _findPrevious = new() { Content = "Previous match" };
    private readonly Button _findNext = new() { Content = "Next match" };
    private readonly TextBlock _findStatus = new() { Classes = { "muted", "small" }, TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private readonly HexCompareView _hex = new() { IsVisible = false };
    private readonly ComboBox _differenceBox = new() { MinWidth = 320, MaxWidth = 560, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock _summary = new() { TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock _changed = new() { TextWrapping = TextWrapping.Wrap, Classes = { "warning" } };
    private readonly TextBlock _status = new() { TextTrimming = TextTrimming.CharacterEllipsis, Classes = { "muted" } };
    private readonly Border _changedBanner, _statusBar;
    private readonly CheckBox _ignoreWhitespace = new() { Content = "Ignore whitespace", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _ignoreCase = new() { Content = "Ignore case", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _binary = new() { Content = "Binary", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _collapse = new() { Content = "Hide equal lines", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _wrapLines = new() { Content = "Wrap long lines", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _align = new() { Content = "Align shifted bytes", VerticalAlignment = VerticalAlignment.Center, IsVisible = false };
    private readonly Button _first, _previous, _next, _last;
    private readonly Button _again = new() { Content = "Compare again", VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _selectBytes = new() { Content = "Select byte range…", VerticalAlignment = VerticalAlignment.Center, IsVisible = false };
    private readonly TextBox _selectedBytes = new() { IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MaxHeight = 56, IsVisible = false };
    private readonly Panel _overlayHost = new() { IsVisible = false };
    private readonly OverlayDialogService _dialogs;
    private DialogCloser? _rangeReview;
    private CancellationTokenSource? _previewStop;
    private (int Side, long Start, long Length)? _previewSelection;
    private int _previewView;
    private CancellationTokenSource? _work;
    private Task _loading = Task.CompletedTask;
    private BinaryDiffResult? _bytes;
    private (PagedReader Left, PagedReader Right)? _pages;
    /// <summary>
    /// The aligned comparison of the contents now shown, once asked for: computed off the UI thread, kept while the
    /// contents stay, and stopped when its view is left before it is ready (large files take a while).
    /// </summary>
    private Task<(AlignedBinaryResult Result, List<AlignedRange> Differences)>? _aligning;
    private CancellationTokenSource? _aligningStop;
    /// <summary>Every comparison, aligning and search for differences started, stopped ones too: the contents are released only after they stopped reading.</summary>
    private Task _runs = Task.CompletedTask;
    private TextSide? _leftText, _rightText;
    private string? _textProblem;
    private (ContentRevision? Left, ContentRevision? Right) _revisions;
    private bool _checkingInputs;
    private bool _closed, _reopening, _binaryForced, _settingOptions, _settingDifference, _searching, _contentFocused, _findOpen;
    private int _view;
    private int _findRequest, _matchIndex = -1;
    private CancellationTokenSource? _findStop;
    private IReadOnlyList<CompareTextMatch> _matches = [];
    private bool _matchesTruncated;
    private Shown _shown;

    /// <summary>What the window shows: the lines, the bytes at the same offsets, or the bytes aligned.</summary>
    private enum Shown { Nothing, Text, Bytes, Aligned }
    private enum TextCopyKind { Selection, Line, Difference }
    private const int MaximumTextCopyCharacters = 4 * 1024 * 1024;

    // The differences of the view shown. Text: the row each starts on. Bytes: the differing runs listed, in file order
    // (at the same offsets, the first ones found; more are searched for past them when the comparison had too many to
    // list). Aligned: every stretch that is not equal.
    private List<int> _differenceRows = [];
    private List<AlignedRange> _differences = [];
    private List<string> _descriptions = [];
    private bool _moreDifferences;
    /// <summary>The current difference: its index among those listed, or -1 (none, or one found past them: <see cref="_pastListed"/>).</summary>
    private int _current = -1;
    private AlignedRange? _pastListed;

    private static readonly List<CompareWindow> s_open = [];

    /// <summary>Open comparisons, oldest first.</summary>
    public static IReadOnlyList<CompareWindow> OpenWindows => s_open;

    /// <summary>
    /// Opens a comparison of two contents (opened by the caller off the UI thread); the window disposes them.
    /// <paramref name="reopen"/> opens both again off the UI thread. <paramref name="reopenAsync"/> instead lets a provider
    /// factory retain its own asynchronous admission and ownership boundaries. Without either the window cannot compare anew.
    /// </summary>
    public static CompareWindow Open(string leftName, IContentSource left, string rightName, IContentSource right,
        Func<(IContentSource Left, IContentSource Right)>? reopen = null,
        Func<Task<(IContentSource Left, IContentSource Right)>>? reopenAsync = null,
        double contentFontSize = ReadabilityPolicy.DefaultContentSize, bool comfortable = false)
    {
        var window = new CompareWindow(leftName, left, rightName, right, reopen, reopenAsync, contentFontSize, comfortable);
        s_open.Add(window);
        window.Closed += (_, _) => s_open.Remove(window);
        window.Show();
        return window;
    }

    internal CompareWindow(string leftName, IContentSource left, string rightName, IContentSource right,
        Func<(IContentSource, IContentSource)>? reopen, Func<Task<(IContentSource, IContentSource)>>? reopenAsync,
        double contentFontSize = ReadabilityPolicy.DefaultContentSize, bool comfortable = false)
    {
        ReadabilityPolicy.ApplyDensity(comfortable ? "Comfortable" : "Compact");
        _left = left;
        _right = right;
        _leftView = new ViewSource(left);
        _rightView = new ViewSource(right);
        _leftName = leftName;
        _rightName = rightName;
        _textView = new CompareTextView(_rows);
        SetContentSize(contentFontSize);
        Classes.Set("comfortable", comfortable);
        _lineDetails = new CompareLineDetails(leftName, rightName);
        _reopen = reopen;
        _reopenAsync = reopenAsync;
        Title = $"Compare: {Path.GetFileName(leftName.TrimEnd('/', '\\'))} ↔ {Path.GetFileName(rightName.TrimEnd('/', '\\'))}";
        Width = 1200; Height = 760; MinWidth = 640; MinHeight = 320;
        WindowFit.Attach(this);
        try { Icon = new WindowIcon(Avalonia.Platform.AssetLoader.Open(new Uri("avares://FileCat/Assets/filecat.ico"))); } catch (Exception) { }
        _first = NavigationButton("compare.first", "First difference", "Alt+Home", GoFirst);
        _previous = NavigationButton("compare.previous", "Previous difference", "Alt+Up or Shift+F8", () => Go(-1));
        _next = NavigationButton("compare.next", "Next difference", "Alt+Down or F8", () => Go(+1));
        _last = NavigationButton("compare.last", "Last difference", "Alt+End", GoLast);
        Avalonia.Automation.AutomationProperties.SetName(_rows, "Differences");
        Avalonia.Automation.AutomationProperties.SetName(_hex, "Bytes of both files");
        Avalonia.Automation.AutomationProperties.SetName(_differenceBox, "Difference");
        ToolTip.SetTip(_differenceBox, "Go to a difference (Alt+D)");
        ToolTip.SetTip(_again, "Read both files again and compare them (F5)");
        ToolTip.SetTip(_fullLine, "Inspect and copy both full source lines (Alt+L or double-click a row)");
        Avalonia.Automation.AutomationProperties.SetName(_fullLine, "Focus full-line comparison details");
        Avalonia.Automation.AutomationProperties.SetName(_selectBytes, "Select byte range in left or right file");
        Avalonia.Automation.AutomationProperties.SetName(_selectedBytes, "Selected source bytes and comparison view");
        ToolTip.SetTip(_selectBytes, "Select an exact source byte interval on either side (Alt+B). Alignment gaps contain no bytes.");
        Avalonia.Automation.AutomationProperties.SetHelpText(_rows, $"Aligned source lines scroll horizontally together; Alt+Left and Alt+Right move both panes. Wrap long lines preserves aligned source numbers and gaps. Lines over {CompareTextView.MaximumLineCharacters:N0} UTF-16 characters have an explicit complete-line action. Alt+L or a double-click focuses selectable full-line details.");
        Avalonia.Automation.AutomationProperties.SetName(_wrapLines, "Wrap long source lines in the aligned comparison");
        ToolTip.SetTip(_wrapLines, "Wrap both source panes, keeping each left/right line pair and gap aligned. Difference navigation reveals the changed text on both axes.");
        _again.IsVisible = CanReopen;
        foreach (var control in new Control[] { _copySide, _copySelection, _copyLine, _copyDifference, _findToggle, _textActionStatus })
        {
            control.Margin = new Thickness(0, 0, 8, 4);
            _textTools.Children.Add(control);
        }
        Avalonia.Automation.AutomationProperties.SetName(_copySide, "Source side for copying a line");
        Avalonia.Automation.AutomationProperties.SetName(_findText, "Find text in comparison (Ctrl+F)");
        Avalonia.Automation.AutomationProperties.SetName(_findToggle, "Show or hide comparison Find bar");
        Avalonia.Automation.AutomationProperties.SetName(_closeFind, "Close comparison Find bar");
        ToolTip.SetTip(_closeFind, "Close Find (Esc); the query stays for next time");
        _closeFind.Click += (_, _) => { SetFindOpen(false); _rows.Focus(); };
        Avalonia.Automation.AutomationProperties.SetName(_findSide, "Comparison search source scope");
        Avalonia.Automation.AutomationProperties.SetAutomationId(_findStatus, "Comparison match status");
        Avalonia.Automation.AutomationProperties.SetLiveSetting(_findStatus, Avalonia.Automation.AutomationLiveSetting.Polite);
        _findStatus.Text = "Find searches the shown comparison rows.";
        _findPrevious.IsEnabled = _findNext.IsEnabled = false;
        Avalonia.Automation.AutomationProperties.SetLiveSetting(_textActionStatus, Avalonia.Automation.AutomationLiveSetting.Polite);
        Avalonia.Automation.AutomationProperties.SetAutomationId(_textActionStatus, "Comparison navigation and action status");
        ToolTip.SetTip(_copySelection, "Copy selected source characters without line numbers. Lines are joined with LF; no final newline is added.");
        ToolTip.SetTip(_copyLine, "Copy the complete current source line from the chosen side, without its line number or terminator.");
        ToolTip.SetTip(_copyDifference, "Copy the current aligned row with Left and Right labels and explicit gaps.");
        // Long paths lose their middle, not the file name at their end.
        var header = new Grid { ColumnDefinitions = new ColumnDefinitions("*,*"), Margin = new Thickness(8, 4) };
        var leftHeader = new TextBlock { Text = leftName, TextTrimming = TextTrimming.PrefixCharacterEllipsis, FontWeight = FontWeight.SemiBold, Margin = new Thickness(0, 0, 8, 0) };
        var rightHeader = new TextBlock { Text = rightName, TextTrimming = TextTrimming.PrefixCharacterEllipsis, FontWeight = FontWeight.SemiBold };
        ToolTip.SetTip(leftHeader, leftName);
        ToolTip.SetTip(rightHeader, rightName);
        Grid.SetColumn(rightHeader, 1);
        header.Children.Add(leftHeader);
        header.Children.Add(rightHeader);
        var bar = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Margin = new Thickness(8, 6, 8, 2),
            Children = { _first, _previous, _next, _last, _differenceBox, _fullLine, _smallerText, _contentSize, _largerText, _wrapLines, _again, _binary, _align, _selectBytes, _ignoreWhitespace, _ignoreCase, _collapse },
        };
        Avalonia.Automation.AutomationProperties.SetName(_smallerText, "Decrease comparison content size");
        Avalonia.Automation.AutomationProperties.SetName(_largerText, "Increase comparison content size");
        Avalonia.Automation.AutomationProperties.SetName(_contentSize, "Comparison content size");
        ToolTip.SetTip(_smallerText, "Decrease comparison content size (Ctrl+minus)");
        ToolTip.SetTip(_largerText, "Increase comparison content size (Ctrl+plus)");
        _smallerText.Click += (_, _) => SetContentSize(_hex.FontSize - 1);
        _largerText.Click += (_, _) => SetContentSize(_hex.FontSize + 1);
        foreach (var child in bar.Children.OfType<Control>()) child.Margin = new Thickness(0, 0, child is Button { Content: Image } ? 2 : 10, 4);
        var root = new DockPanel();
        DockPanel.SetDock(bar, Dock.Top);
        DockPanel.SetDock(_textTools, Dock.Top);
        foreach (var control in new Control[] { _findText, _closeFind, _findSide, _findChanged, _findPrevious, _findNext, _findStatus })
        {
            control.Margin = new Thickness(0, 0, 8, 4);
            _findBar.Children.Add(control);
        }
        DockPanel.SetDock(_findBar, Dock.Top);
        DockPanel.SetDock(header, Dock.Top);
        var summaryBorder = new Border { Child = _summary, Padding = new Thickness(8, 4), Classes = { "banner" } };
        DockPanel.SetDock(summaryBorder, Dock.Top);
        _changedBanner = new Border { Child = _changed, Padding = new Thickness(8, 4), Classes = { "banner" }, IsVisible = false };
        DockPanel.SetDock(_changedBanner, Dock.Top);
        _statusBar = new Border { Child = new StackPanel { Spacing = 3, Children = { _status, _selectedBytes } }, Padding = new Thickness(8, 3), IsVisible = false };
        DockPanel.SetDock(_statusBar, Dock.Bottom);
        root.Children.Add(bar);
        root.Children.Add(_textTools);
        root.Children.Add(_findBar);
        root.Children.Add(summaryBorder);
        root.Children.Add(_changedBanner);
        root.Children.Add(header);
        root.Children.Add(_statusBar);
        Grid.SetRow(_lineDetails, 2);
        var divider = new Border { Background = UnalignedBrush, Height = 1 };
        Grid.SetRow(divider, 1);
        _textBody.Children.Add(_textView);
        _textBody.Children.Add(divider);
        _textBody.Children.Add(_lineDetails);
        var body = new Panel { Children = { _textBody, _hex } };
        root.Children.Add(body);
        Content = ThemeLayers.Over(new Grid { Children = { root, _overlayHost } }, body);
        _dialogs = new OverlayDialogService(_overlayHost, () => _hex);

        _again.Click += (_, _) => CompareAgain();
        _selectBytes.Click += (_, _) => _ = SelectByteRangeAsync();
        _fullLine.Click += (_, _) => FocusLineDetails();
        _copySelection.Click += async (_, _) => await CopyTextAsync(TextCopyKind.Selection);
        _copyLine.Click += async (_, _) => await CopyTextAsync(TextCopyKind.Line);
        _copyDifference.Click += async (_, _) => await CopyTextAsync(TextCopyKind.Difference);
        _textView.SelectionChanged += () =>
        {
            if (_textView.SelectedSide is { } side) _copySide.SelectedIndex = side;
            _copySelection.IsEnabled = _textView.HasSelection;
        };
        _textView.CopyRequested += (action, side) =>
        {
            if (action == CompareTextCopyAction.Selection && _textView.SelectedSide != side)
            {
                _textActionStatus.Text = "The selection is on the other source side. Right-click that side or select text here.";
                return;
            }
            if (action != CompareTextCopyAction.Selection) _copySide.SelectedIndex = side;
            _ = CopyTextAsync(action switch
            {
                CompareTextCopyAction.Line => TextCopyKind.Line,
                CompareTextCopyAction.Difference => TextCopyKind.Difference,
                _ => TextCopyKind.Selection,
            });
        };
        _copySelection.IsEnabled = false;
        _copySide.SelectionChanged += (_, _) => UpdateCopyLineAvailability();
        _findToggle.Click += (_, _) => SetFindOpen(!_findOpen);
        _findText.TextChanged += (_, _) => ScheduleFind();
        _findSide.SelectionChanged += (_, _) => ScheduleFind();
        _findChanged.IsCheckedChanged += (_, _) => ScheduleFind();
        _findPrevious.Click += (_, _) => MoveMatch(-1);
        _findNext.Click += (_, _) => MoveMatch(1);
        _wrapLines.IsCheckedChanged += (_, _) => _textView.Wrap = _wrapLines.IsChecked == true;
        _textView.DetailsRequested += focus =>
        {
            if (_shown != Shown.Text || _closed) return;
            if (focus) FocusLineDetails();
            else _lineDetails.RevealCurrentDifference();
        };
        foreach (var box in new[] { _ignoreWhitespace, _ignoreCase, _binary, _collapse, _align }) box.IsCheckedChanged += (_, _) => Recompute();
        ToolTip.SetTip(_align, "Finds content that moved because bytes were inserted or removed, instead of comparing at the same offsets. A heuristic view: whether the files are identical is the exact comparison's answer.");
        _differenceBox.SelectionChanged += (_, _) =>
        {
            if (!_settingDifference && _differenceBox.SelectedIndex >= 0) GoTo(_differenceBox.SelectedIndex);
        };
        _rows.SelectionChanged += (_, _) => FollowRow();
        _rows.DoubleTapped += (_, _) => FocusLineDetails();
        _hex.DifferenceClicked += index => ShowDifference(index);
        _hex.StatusChanged += () =>
        {
            _status.Text = _hex.Status.Length > 0 ? _hex.Status : BytesHint;
            _ = UpdateSelectedBytesAsync();
        };
        _status.Text = BytesHint;
        // Navigation keys work wherever the focus is (the list and the difference box have their own uses for arrows).
        AddHandler(KeyDownEvent, OnNavigationKey, RoutingStrategies.Tunnel);
        KeyDown += OnKey;
        Activated += (_, _) => CheckInputs();
        ThemeManager.ThemeChanged += RefreshIcons;
        Closed += (_, _) =>
        {
            if (_closed) return;
            _findStop?.Cancel();
            _findStop?.Dispose();
            _findStop = null;
            _closed = true;
            RetireRangeReview();
            _previewStop?.Cancel();
            ThemeManager.ThemeChanged -= RefreshIcons;
            _work?.Cancel();
            ReleaseWhenIdle(_left, _right, _leftView, _rightView);
            DisposePages(_pages);
            // ReleaseWhenIdle captured the active readers and their sources. A retained closed window no longer
            // owns their graphs, completed tasks, decoded lines, or the controls' materialized result lists.
            _view++;
            _shown = Shown.Nothing;
            _hex.SetContent(null, null, null, []);
            _textView.Dispose();
            ControlRetirement.ClearItems(_rows);
            _lineDetails.Dispose();
            ControlRetirement.ClearItems(_differenceBox);
            _pages = null;
            _bytes = null;
            _leftText = _rightText = null;
            _textProblem = null;
            _differenceRows = [];
            _differences = [];
            _descriptions = [];
            _aligning = null;
            _loading = _runs = Task.CompletedTask;
            _work = _aligningStop = null;
            _reopen = null;
            _reopenAsync = null;
            _revisions = default;
            _current = -1;
            _pastListed = null;
            _moreDifferences = false;
            IsComparing = false;
            var empty = new MemoryContentSource(string.Empty, []);
            _left = _right = empty;
            _leftView = _rightView = new ViewSource(empty);
        };
        _summary.Text = "Comparing…";
        Opened += (_, _) => _loading = LoadAsync();
    }

    private static Button NavigationButton(string icon, string title, string keys, Action run)
    {
        var button = new Button
        {
            Content = new Image { Source = CommandIcons.Get(icon), Width = 16, Height = 16 },
            Tag = icon,
            Padding = new Thickness(6, 4),
            VerticalAlignment = VerticalAlignment.Center,
        };
        ToolTip.SetTip(button, $"{title} ({keys})");
        Avalonia.Automation.AutomationProperties.SetName(button, title);
        button.Click += (_, _) => run();
        return button;
    }

    private void RefreshIcons()
    {
        foreach (var button in new[] { _first, _previous, _next, _last })
            if (button is { Tag: string icon, Content: Image image }) image.Source = CommandIcons.Get(icon);
    }

    public string Summary => _summary.Text ?? "";

    /// <summary>Whether the window says that a file changed after it was compared (tests).</summary>
    public string? ChangedNotice => _changedBanner.IsVisible ? _changed.Text : null;

    /// <summary>Whether the files are still being read or their lines aligned (the rows and summary are not final yet).</summary>
    public bool IsComparing { get; private set; } = true;

    /// <summary>Whether a difference past the listed ones is being searched for.</summary>
    public bool IsSearching => _searching;

    /// <summary>The text view's rows.</summary>
    public IReadOnlyList<object> Rows => _rows.ItemsSource as IReadOnlyList<object> ?? [];

    /// <summary>The row the text comparison shows as current (the first difference when it opens).</summary>
    public int CurrentRow => _rows.SelectedIndex;

    /// <summary>The differences listed to choose from, as the difference box says them.</summary>
    public IReadOnlyList<string> DifferenceTexts => _descriptions;

    /// <summary>The current difference's index among those listed; -1 when there is none or it was found past them.</summary>
    public int CurrentDifference => _current;

    /// <summary>What the difference box says about the current difference.</summary>
    public string CurrentDifferenceText =>
        _current >= 0 && _current < _descriptions.Count ? _descriptions[_current] : _differenceBox.PlaceholderText ?? "";

    private void OnKey(object? sender, KeyEventArgs e)
    {
        if (_dialogs.IsOpen) return;
        if (e.Key != Key.Escape || e.KeyModifiers != KeyModifiers.None) return;
        if (_findOpen && FocusManager?.GetFocusedElement() is Visual findControl &&
            _findBar.IsVisualAncestorOf(findControl))
        {
            SetFindOpen(false);
            _rows.Focus();
            e.Handled = true;
            return;
        }
        Close();
        e.Handled = true;
    }

    private void SetContentSize(double requested)
    {
        double size = ReadabilityPolicy.ContentSize(requested);
        _rows.FontSize = size;
        _hex.FontSize = size;
        _contentSize.Text = $"{size:0} size";
        _smallerText.IsEnabled = size > ReadabilityPolicy.MinimumContentSize;
        _largerText.IsEnabled = size < ReadabilityPolicy.MaximumContentSize;
        // A newly shaped long line has different glyph positions; keep the chosen change visible.
        if (_shown == Shown.Text && _rows.SelectedIndex >= 0) _textView.RevealSelected();
    }

    private void OnNavigationKey(object? sender, KeyEventArgs e)
    {
        if (_dialogs.IsOpen) return;
        if (e.KeyModifiers == KeyModifiers.Control && e.Key is Key.OemPlus or Key.Add or Key.OemMinus or Key.Subtract)
        {
            SetContentSize(_hex.FontSize + (e.Key is Key.OemPlus or Key.Add ? 1 : -1));
            e.Handled = true;
            return;
        }
        if (_shown == Shown.Text && e.Key == Key.F && e.KeyModifiers == KeyModifiers.Control)
        {
            SetFindOpen(true);
            _findText.Focus();
            _findText.SelectAll();
            e.Handled = true;
            return;
        }
        if (_shown == Shown.Text && e.Key == Key.F3 && e.KeyModifiers is KeyModifiers.None or KeyModifiers.Shift)
        {
            MoveMatch(e.KeyModifiers == KeyModifiers.Shift ? -1 : 1);
            e.Handled = true;
            return;
        }
        if (e.Key == Key.C && e.KeyModifiers == KeyModifiers.Control && _shown == Shown.Text &&
            e.Source is not TextBox)
        {
            _ = CopyTextAsync(TextCopyKind.Selection);
            e.Handled = true;
            return;
        }
        switch (e.Key)
        {
            case Key.Home when e.KeyModifiers == KeyModifiers.Alt:
                GoFirst();
                break;
            case Key.End when e.KeyModifiers == KeyModifiers.Alt:
                GoLast();
                break;
            case Key.Down when e.KeyModifiers == KeyModifiers.Alt:
            case Key.F8 when e.KeyModifiers == KeyModifiers.None:
                Go(+1);
                break;
            case Key.Up when e.KeyModifiers == KeyModifiers.Alt:
            case Key.F8 when e.KeyModifiers == KeyModifiers.Shift:
                Go(-1);
                break;
            case Key.D when e.KeyModifiers == KeyModifiers.Alt:
                _differenceBox.Focus();
                _differenceBox.IsDropDownOpen = _differenceBox.ItemCount > 0;
                break;
            case Key.L when e.KeyModifiers == KeyModifiers.Alt && _shown == Shown.Text:
                FocusLineDetails();
                break;
            case Key.B when e.KeyModifiers == KeyModifiers.Alt && _shown is Shown.Bytes or Shown.Aligned:
                _ = SelectByteRangeAsync();
                break;
            case Key.F5 when e.KeyModifiers == KeyModifiers.None && CanReopen:
            case Key.R when e.KeyModifiers == KeyModifiers.Control && CanReopen:
                CompareAgain();
                break;
            default:
                return;
        }
        e.Handled = true;
    }

    private void RetireRangeReview()
    {
        var closer = _rangeReview;
        _rangeReview = null;
        closer?.Close(null);
    }

    private async Task SelectByteRangeAsync()
    {
        if (_closed || _dialogs.IsOpen || IsComparing || _shown is not (Shown.Bytes or Shown.Aligned) || _pages is null) return;
        int view = _view;
        var pages = _pages;
        var previous = _hex.Selection;
        var side = new ComboBox { ItemsSource = new[] { "Left file", "Right file" }, SelectedIndex = previous?.Side ?? 0 };
        var sourcePath = new TextBox { IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MaxHeight = 64 };
        var offset = new TextBox { Text = previous is { } p ? $"0x{p.Start:X}" : "0x0", MinWidth = 170 };
        var count = new TextBox { Text = (previous?.Length ?? 4).ToString(CultureInfo.InvariantCulture), MinWidth = 120 };
        Avalonia.Automation.AutomationProperties.SetName(side, "Source side for byte selection");
        Avalonia.Automation.AutomationProperties.SetName(sourcePath, "Full path of selected source file");
        Avalonia.Automation.AutomationProperties.SetName(offset, "Start offset in decimal or 0x hexadecimal");
        Avalonia.Automation.AutomationProperties.SetName(count, "Number of source bytes in decimal");
        var error = new TextBlock { Classes = { "error" }, TextWrapping = TextWrapping.Wrap, IsVisible = false };
        var body = new StackPanel { Spacing = 8, Children =
        {
            new TextBlock { Text = "Choose an exact range in one source file. Alignment gaps contain no source bytes.", TextWrapping = TextWrapping.Wrap },
            new DialogForm(("Source side:", side), ("Source file:", sourcePath), ("Start offset:", offset), ("Byte count:", count)),
            error,
            new TextBlock { Text = "Ctrl+C copies the selection as spaced hex pairs. Copy is limited to the first 4 MiB and reports unread bytes.", TextWrapping = TextWrapping.Wrap },
        } };
        bool Current() => !_closed && !IsComparing && view == _view &&
            ReferenceEquals(pages.Value.Left, _pages?.Left) && ReferenceEquals(pages.Value.Right, _pages?.Right) &&
            _shown is Shown.Bytes or Shown.Aligned;
        bool ParseStart(string text, out long value)
        {
            text = text.Trim();
            if (text.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
            {
                if (ulong.TryParse(text.AsSpan(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out ulong hex) && hex <= long.MaxValue)
                { value = (long)hex; return true; }
            }
            else if (long.TryParse(text, NumberStyles.None, CultureInfo.InvariantCulture, out value)) return true;
            value = 0;
            return false;
        }
        bool Validate()
        {
            string? message = null;
            if (!Current()) message = "The comparison changed. Close this review and select a range in the current view.";
            else if (side.SelectedIndex is not (0 or 1)) message = "Choose the left or right source file.";
            else if (!ParseStart(offset.Text ?? "", out long start)) message = "Enter a nonnegative start offset in decimal or 0x hexadecimal without overflow.";
            else if (!long.TryParse((count.Text ?? "").Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out long length) || length <= 0)
                message = "Enter a positive decimal byte count without overflow.";
            else if (start >= _hex.SideLength(side.SelectedIndex) || length > _hex.SideLength(side.SelectedIndex) - start)
                message = "The requested range extends beyond that source file. No bytes were selected.";
            else if (!_hex.TrySelectRange(side.SelectedIndex, start, length))
                message = "That offset has no source byte in the current aligned view. Choose an offset within the selected side.";
            if (message is null) return true;
            error.Text = message;
            error.IsVisible = true;
            (message.StartsWith("Enter a positive", StringComparison.Ordinal) ? count : offset).Focus();
            return false;
        }
        void ShowSource()
        {
            sourcePath.Text = side.SelectedIndex == 1 ? _rightName : _leftName;
            error.IsVisible = false;
        }
        side.SelectionChanged += (_, _) => ShowSource();
        ShowSource();
        offset.TextChanged += (_, _) => error.IsVisible = false;
        count.TextChanged += (_, _) => error.IsVisible = false;
        var closer = new DialogCloser();
        _rangeReview = closer;
        object? result = null;
        try
        {
            result = await _dialogs.ShowCustomAsync("Select byte range", body,
                [new DialogButton("Cancel", false, IsCancel: true), new DialogButton("Select", true, IsDefault: true) { Validate = Validate }],
                side, closer: closer);
        }
        finally
        {
            if (ReferenceEquals(_rangeReview, closer)) _rangeReview = null;
            if (result is not true && Current())
                Dispatcher.UIThread.Post(() =>
                {
                    if (!Current() || _dialogs.IsOpen || !IsActive) return;
                    var focused = FocusManager?.GetFocusedElement();
                    if (focused is null || ReferenceEquals(focused, _selectBytes)) _hex.Focus();
                }, DispatcherPriority.Background);
        }
    }

    private async Task UpdateSelectedBytesAsync()
    {
        var selection = _hex.Selection;
        if (selection == _previewSelection && _previewView == _view) return;
        _previewStop?.Cancel();
        _previewSelection = selection;
        _previewView = _view;
        if (selection is not { } chosen || _pages is not { } pages || _closed)
        {
            _selectedBytes.IsVisible = false;
            _selectedBytes.Text = string.Empty;
            return;
        }
        using var stop = new CancellationTokenSource();
        _previewStop = stop;
        int view = _view;
        var reader = chosen.Side == 0 ? pages.Left : pages.Right;
        int length = (int)Math.Min(64, chosen.Length);
        string side = chosen.Side == 0 ? "Left" : "Right";
        string source = chosen.Side == 0 ? _leftName : _rightName;
        string relation = _shown == Shown.Aligned ? "Aligned view; an empty counterpart is a gap, not a zero byte." : "Same-offset view.";
        _selectedBytes.Text = $"{side}: {source}; reading the first {length:N0} selected bytes at 0x{chosen.Start:X}… {relation}";
        _selectedBytes.IsVisible = true;
        bool Current() => !stop.IsCancellationRequested && !_closed && view == _view &&
            ReferenceEquals(pages.Left, _pages?.Left) && ReferenceEquals(pages.Right, _pages?.Right) && _hex.Selection == chosen;
        try
        {
            var bytes = await Task.Run(() =>
            {
                stop.Token.ThrowIfCancellationRequested();
                ContentRevision? before = null, after = null;
                long beforeLength = 0, afterLength = 0;
                reader.WithSource(content => { before = content.GetRevision(); beforeLength = content.Length; });
                if (beforeLength != reader.Length || reader.Revision is { } expected && before != expected)
                    throw new InvalidDataException("The source changed. Compare the files again before inspecting this selection.");
                var buffer = new byte[length];
                int read = reader.Read(chosen.Start, buffer, stop.Token);
                stop.Token.ThrowIfCancellationRequested();
                reader.WithSource(content => { after = content.GetRevision(); afterLength = content.Length; });
                if (before != after || beforeLength != afterLength)
                    throw new InvalidDataException("The source changed during inspection. Compare the files again.");
                return buffer[..read];
            });
            if (!Current()) return;
            _selectedBytes.Text = $"{side}: {source}; offset 0x{chosen.Start:X}, {chosen.Length:N0} selected bytes. " +
                $"{(chosen.Length > length ? $"First {length:N0} bytes" : "Selected bytes")}: {HexCompareView.HexText(bytes)}" +
                (bytes.Length < length ? $" (only {bytes.Length:N0} of {length:N0} preview bytes could be read)" : "") +
                $". {relation}" + (reader.Revision is null ? " The source has no revision evidence; compare again if it may have changed." : "");
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ObjectDisposedException or InvalidDataException)
        {
            if (Current()) _selectedBytes.Text = $"{side}: {source}; selected bytes could not be inspected: {ex.Message}";
        }
        finally
        {
            if (ReferenceEquals(_previewStop, stop)) _previewStop = null;
        }
    }

    /// <summary>A comparison opens on its first difference: the equal lines or bytes before it are what the user did not come for.</summary>
    private void ShowFirstDifference()
    {
        int view = _view;
        // After layout, so the view can scroll there.
        Dispatcher.UIThread.Post(() =>
        {
            if (view != _view || _closed) return;
            // Unless a difference was chosen meanwhile: the user's choice stands.
            if (_current < 0 && _pastListed is null && (_shown == Shown.Text ? _differenceRows.Count > 0 : _differences.Count > 0)) GoTo(0);
            if (!_contentFocused && IsActive)
            {
                // The first view takes the keys (arrows and Page Down scroll); later ones leave the focus where it is.
                _contentFocused = true;
                (_shown == Shown.Text ? (Control)_rows : _hex).Focus();
            }
        }, DispatcherPriority.Loaded);
    }

    /// <summary>Goes to the listed difference <paramref name="index"/> (the difference box's choice).</summary>
    public void GoTo(int index)
    {
        if (_shown == Shown.Text)
        {
            if (index < 0 || index >= _differenceRows.Count) return;
            int row = _differenceRows[index];
            _rows.SelectedIndex = row;
            _rows.ScrollIntoView(row);
            SetCurrent(index, null);
            // The current row may already be selected. Navigation still re-reveals its decisive text.
            _textView.RevealSelected();
            _lineDetails.RevealCurrentDifference();
            var description = _descriptions[index];
            int separator = description.IndexOf(": ", StringComparison.Ordinal);
            _textActionStatus.Text = $"Difference {index + 1:N0} of {_differenceRows.Count:N0}: " +
                (separator < 0 ? description : description[(separator + 2)..]) + ".";
        }
        else ShowDifference(index);
    }

    public void GoFirst()
    {
        if (_shown == Shown.Text || _differences.Count > 0) GoTo(0);
    }

    /// <summary>
    /// The last difference. When more differences exist than were listed, the last one is found by reading backwards
    /// from the end of the files (it is not numbered then: the ones between were not counted).
    /// </summary>
    public void GoLast()
    {
        if (_shown == Shown.Text) GoTo(_differenceRows.Count - 1);
        else if (_moreDifferences && _bytes is { } bytes) Search(forward: false, Math.Max(bytes.LeftLength, bytes.RightLength));
        else GoTo(_differences.Count - 1);
    }

    /// <summary>Moves to the next or previous difference (wrapping around at either end).</summary>
    public void Go(int direction)
    {
        if (_shown == Shown.Text)
        {
            if (_differenceRows.Count == 0) return;
            int current = _rows.SelectedIndex;
            int target = direction > 0
                ? _differenceRows.FindIndex(r => r > current)
                : _differenceRows.FindLastIndex(r => r < current);
            GoTo(target >= 0 ? target : direction > 0 ? 0 : _differenceRows.Count - 1);
            return;
        }
        if (_shown is not (Shown.Bytes or Shown.Aligned) || _differences.Count == 0 && !_moreDifferences) return;
        if (direction > 0)
        {
            if (_current >= 0 && _current + 1 < _differences.Count) ShowDifference(_current + 1);
            else if (_current < 0 && _pastListed is null) GoFirst();
            else if (_moreDifferences && _bytes is not null)
            {
                var from = _pastListed ?? _differences[^1];
                Search(forward: true, from.LeftOffset + Math.Max(from.LeftLength, from.RightLength));
            }
            else GoFirst();
        }
        else
        {
            if (_current > 0) ShowDifference(_current - 1);
            else if (_pastListed is { } past) Search(forward: false, past.LeftOffset);
            else GoLast();
        }
    }

    /// <summary>Shows the listed binary difference <paramref name="index"/> as the current one.</summary>
    private void ShowDifference(int index)
    {
        if (index < 0 || index >= _differences.Count) return;
        SetCurrent(index, null);
        _hex.ShowDifference(_differences[index]);
    }

    /// <summary>The difference box shows the current difference: a listed one, or one found past them.</summary>
    private void SetCurrent(int index, string? pastListed)
    {
        _current = index;
        _settingDifference = true;
        try
        {
            bool listed = index >= 0 && index < _differenceBox.ItemCount;
            _differenceBox.SelectedIndex = listed ? index : -1;
            _differenceBox.PlaceholderText = listed ? null : index >= 0 ? _descriptions[index] : pastListed;
        }
        finally
        {
            _settingDifference = false;
        }
        if (index >= 0) _pastListed = null;
    }

    /// <summary>A row chosen in the text view makes the difference it is in (or the last one before it) current.</summary>
    private void FollowRow()
    {
        if (_shown != Shown.Text || _settingDifference) return;
        var selected = _rows.SelectedItem as CompareRow;
        _lineDetails.SetComparisonRow(selected);
        if (!_textView.SelectionGestureActive) _textView.RevealSelected();
        UpdateCopyLineAvailability();
        _copyDifference.IsEnabled = selected is { Kind: not DiffKind.Equal } or { EndingDiffers: true };
        int row = _rows.SelectedIndex;
        int index = _differenceRows.FindLastIndex(r => r <= row);
        if (index != _current && index >= 0) SetCurrent(index, null);
    }

    private void UpdateCopyLineAvailability()
    {
        if (_shown != Shown.Text || _rows.SelectedItem is not CompareRow row)
        {
            _copyLine.IsEnabled = false;
            return;
        }
        _copyLine.IsEnabled = (_copySide.SelectedIndex == 1 ? row.RightLine : row.LeftLine) is not null;
    }

    private void ScheduleFind()
    {
        _findStop?.Cancel();
        _findStop?.Dispose();
        _findStop = null;
        int request = ++_findRequest;
        _matches = [];
        _matchesTruncated = false;
        _matchIndex = -1;
        _findPrevious.IsEnabled = _findNext.IsEnabled = false;
        ViewerSearchFeedback.Set(_findText, null);
        if (_closed || _shown != Shown.Text || _rows.ItemsSource is not IReadOnlyList<object> rows) return;
        string term = _findText.Text ?? "";
        if (term.Length == 0)
        {
            _findStatus.Text = "Find searches the shown comparison rows.";
            return;
        }
        int scope = _findSide.SelectedIndex;
        bool changedOnly = _findChanged.IsChecked == true;
        int view = _view;
        var stop = new CancellationTokenSource();
        _findStop = stop;
        _findStatus.Text = $"Searching {FindScope(scope, changedOnly)}…";
        _ = RunFindAsync(rows, term, scope, changedOnly, view, request, stop.Token);
    }

    private void SetFindOpen(bool open)
    {
        _findOpen = open;
        _findBar.IsVisible = open && _shown == Shown.Text;
        _findToggle.Content = open ? "Hide Find" : "Find…";
        if (open) _findText.Focus();
    }

    private async Task RunFindAsync(IReadOnlyList<object> rows, string term, int scope, bool changedOnly,
        int view, int request, CancellationToken token)
    {
        try
        {
            await Task.Delay(120, token);
            var result = await Task.Run(() => CompareTextSearch.Search(rows, term, scope, changedOnly, token), token);
            if (_closed || token.IsCancellationRequested || request != _findRequest || view != _view ||
                !ReferenceEquals(rows, _rows.ItemsSource) || _shown != Shown.Text) return;
            _matches = result.Matches;
            _matchesTruncated = result.Truncated;
            _findPrevious.IsEnabled = _findNext.IsEnabled = _matches.Count > 0;
            ViewerSearchFeedback.Set(_findText, _matches.Count > 0);
            _findStatus.Text = _matches.Count == 0
                ? $"No matches in {FindScope(scope, changedOnly)}."
                : $"{_matches.Count:N0}{(_matchesTruncated ? "+" : "")} matches in {FindScope(scope, changedOnly)}. F3/Shift+F3 moves between matches.";
        }
        catch (OperationCanceledException) { }
        catch (Exception ex)
        {
            if (!_closed && request == _findRequest)
            {
                ViewerSearchFeedback.Set(_findText, null);
                _findStatus.Text = "Search failed: " + ex.Message;
            }
        }
    }

    private static string FindScope(int side, bool changedOnly) =>
        (side switch { 1 => "the left shown source", 2 => "the right shown source", _ => "both shown sources" }) +
        (changedOnly ? ", changed rows only" : ", all rows");

    private void MoveMatch(int direction)
    {
        if (_closed || _shown != Shown.Text || _matches.Count == 0) return;
        bool wrapped = _matchIndex >= 0 && (direction > 0 && _matchIndex == _matches.Count - 1 ||
            direction < 0 && _matchIndex == 0);
        _matchIndex = _matchIndex < 0 ? (direction > 0 ? 0 : _matches.Count - 1) :
            (_matchIndex + direction + _matches.Count) % _matches.Count;
        var match = _matches[_matchIndex];
        if (_rows.ItemsSource is not IReadOnlyList<object> rows || match.Row >= rows.Count ||
            rows[match.Row] is not CompareRow) return;
        int length = _findText.Text?.Length ?? 0;
        _textView.SetSelection(match.Side, match.Row, match.Offset, match.Row, match.Offset + length);
        if (_rows.SelectedIndex != match.Row) _rows.SelectedIndex = match.Row;
        else _textView.RevealSelected();
        _rows.ScrollIntoView(match.Row);
        _findStatus.Text = (wrapped ? $"Wrapped to {(direction > 0 ? "the beginning" : "the end")}. " : "") +
            $"Match {_matchIndex + 1:N0} of {_matches.Count:N0}{(_matchesTruncated ? "+" : "")} in " +
            FindScope(_findSide.SelectedIndex, _findChanged.IsChecked == true) + ".";
    }

    private async Task CopyTextAsync(TextCopyKind kind)
    {
        if (_shown != Shown.Text || _closed) return;
        string? value = null;
        if (kind == TextCopyKind.Selection)
        {
            var selected = _textView.SelectedSourceText(MaximumTextCopyCharacters);
            if (selected.TooLarge)
            {
                _textActionStatus.Text = "The selection exceeds the 4,194,304-character copy limit. Select a smaller source range.";
                return;
            }
            value = selected.Text;
            if (value is null) { _textActionStatus.Text = "Select source characters first, or use Copy line."; return; }
        }
        else if (_rows.SelectedItem is not CompareRow row)
        {
            _textActionStatus.Text = "Choose a source row first.";
            return;
        }
        else if (kind == TextCopyKind.Line)
        {
            int side = _copySide.SelectedIndex == 1 ? 1 : 0;
            if ((side == 0 ? row.LeftLine : row.RightLine) is null)
            {
                _textActionStatus.Text = "This aligned row has a gap on the chosen side; there is no source line to copy.";
                return;
            }
            value = side == 0 ? row.LeftText : row.RightText;
            if (value.Length > MaximumTextCopyCharacters)
            {
                _textActionStatus.Text = "This source line exceeds the 4,194,304-character copy limit. Use full-line details to select a smaller part.";
                return;
            }
        }
        else
        {
            if (row.Kind == DiffKind.Equal && !row.EndingDiffers)
            {
                _textActionStatus.Text = "This row has no difference; choose a differing row.";
                return;
            }
            long size = (long)row.LeftText.Length + row.RightText.Length + 100;
            if (size > MaximumTextCopyCharacters)
            {
                _textActionStatus.Text = "This difference exceeds the 4,194,304-character copy limit. Copy one source line or part instead.";
                return;
            }
            value = "Left: " + (row.LeftLine is null ? "[gap]" : row.LeftText) + "\nRight: " +
                (row.RightLine is null ? "[gap]" : row.RightText) +
                (row.EndingDiffers ? "\n[line endings differ; use Binary view for exact bytes]" : "");
        }
        if (TopLevel.GetTopLevel(this)?.Clipboard is not { } clipboard)
        {
            _textActionStatus.Text = "The system clipboard is unavailable.";
            return;
        }
        int view = _view;
        try
        {
            await Avalonia.Input.Platform.ClipboardExtensions.SetTextAsync(clipboard, value);
            if (!_closed && _shown == Shown.Text && _view == view)
                _textActionStatus.Text = kind switch
                {
                    TextCopyKind.Selection => "Copied selected source text. Aligned lines use LF; no line numbers or final newline were added.",
                    TextCopyKind.Line => "Copied the complete source line without its number or terminator.",
                    _ => "Copied the aligned difference with Left and Right labels; gaps are explicit.",
                };
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidOperationException)
        {
            if (!_closed && _view == view) _textActionStatus.Text = "Copy failed: " + ex.Message;
        }
    }

    private void FocusLineDetails()
    {
        if (_shown != Shown.Text) return;
        if (_rows.SelectedItem is not CompareRow)
        {
            int from = Math.Max(0, _rows.SelectedIndex);
            for (int i = from; i < _rows.ItemCount; i++)
            {
                if (_rows.Items[i] is not CompareRow) continue;
                _rows.SelectedIndex = i;
                _rows.ScrollIntoView(i);
                break;
            }
        }
        _lineDetails.FocusText();
    }

    /// <summary>
    /// Past the listed differences (a comparison with more than <see cref="BinaryDiff.MaxRanges"/>), the next or previous
    /// one is found by reading on from <paramref name="from"/>, off the UI thread. One found right after the last listed
    /// one is listed too; others are shown without a number.
    /// </summary>
    private async void Search(bool forward, long from)
    {
        if (_searching || _bytes is not { } bytes || _closed) return;
        _searching = true;
        int view = _view;
        var (left, right) = (_left, _right);
        var ct = _work?.Token ?? CancellationToken.None;
        bool afterListed = forward && (_current == _differences.Count - 1 && _current >= 0);
        _status.Text = forward ? "Looking for the next difference…" : "Looking for the previous difference…";
        var run = Task.Run(() => forward
            ? BinaryDiff.NextDifference(left, right, bytes.LeftLength, bytes.RightLength, from, ct)
            : BinaryDiff.PreviousDifference(left, right, bytes.LeftLength, bytes.RightLength, from, ct), ct);
        _runs = Task.WhenAll(_runs, run);
        (long Offset, long Length)? found;
        try
        {
            found = await run;
        }
        catch (Exception ex) when (ex is OperationCanceledException or IOException or UnauthorizedAccessException or ObjectDisposedException)
        {
            if (!_closed && view == _view) _status.Text = ex is OperationCanceledException ? BytesHint : "The files could not be read: " + ex.Message;
            return;
        }
        finally
        {
            _searching = false;
        }
        if (_closed || view != _view) return;
        _status.Text = _hex.Status.Length > 0 ? _hex.Status : BytesHint;
        if (found is not { } f)
        {
            // Nothing further that way: the listed ones were all when nothing follows the last of them.
            if (afterListed)
            {
                _moreDifferences = false;
                SetSummary(bytes);
            }
            if (forward) GoFirst();
            else if (_differences.Count > 0) ShowDifference(_differences.Count - 1);
            return;
        }
        var difference = SameOffsetDifference(f, bytes);
        int index = _differences.FindIndex(d => d.LeftOffset == difference.LeftOffset);
        if (index < 0 && afterListed)
        {
            // Right after the last listed one: it is the next in order, so it is listed (and numbered) too.
            _differences.Add(difference);
            _descriptions.Add(Describe(difference, _differences.Count - 1));
            SetDifferences(keepCurrent: true);
            index = _differences.Count - 1;
        }
        if (index >= 0)
        {
            ShowDifference(index);
            return;
        }
        SetCurrent(-1, Describe(difference, -1));
        _pastListed = difference;
        _hex.ShowDifference(difference);
    }

    /// <summary>A differing run of the exact comparison: changed in place, or past the shorter file's end, only in the longer one.</summary>
    private static AlignedRange SameOffsetDifference((long Offset, long Length) run, BinaryDiffResult bytes)
    {
        long common = Math.Min(bytes.LeftLength, bytes.RightLength);
        if (run.Offset >= common && bytes.LeftLength != bytes.RightLength)
            return bytes.LeftLength > bytes.RightLength
                ? new AlignedRange(DiffKind.LeftOnly, run.Offset, run.Length, run.Offset, 0)
                : new AlignedRange(DiffKind.RightOnly, run.Offset, 0, run.Offset, run.Length);
        return new AlignedRange(DiffKind.Changed, run.Offset, run.Length, run.Offset, run.Length);
    }

    /// <summary>How the difference box says a binary difference ("2: 1 byte changed at offset 0x2AAC4").</summary>
    private string Describe(AlignedRange d, int index)
    {
        string number = index >= 0 ? $"{index + 1:N0}: " : "Past the listed ones: ";
        string text = d.Kind switch
        {
            DiffKind.Changed when d.LeftOffset == d.RightOffset && d.LeftLength == d.RightLength => $"{Bytes(d.LeftLength)} changed at offset 0x{d.LeftOffset:X}",
            DiffKind.Changed => $"{Bytes(d.LeftLength, d.RightLength)} changed at 0x{d.LeftOffset:X} ↔ 0x{d.RightOffset:X}",
            DiffKind.LeftOnly when _shown == Shown.Bytes => $"{Bytes(d.LeftLength)} only in the left file, from offset 0x{d.LeftOffset:X}",
            DiffKind.RightOnly when _shown == Shown.Bytes => $"{Bytes(d.RightLength)} only in the right file, from offset 0x{d.RightOffset:X}",
            DiffKind.LeftOnly => $"{Bytes(d.LeftLength)} removed (only left) at 0x{d.LeftOffset:X}",
            DiffKind.RightOnly => $"{Bytes(d.RightLength)} inserted (only right) at 0x{d.RightOffset:X}",
            _ => $"{d.LeftLength:N0} ↔ {d.RightLength:N0} bytes not aligned at 0x{d.LeftOffset:X} ↔ 0x{d.RightOffset:X}",
        };
        return number + text;
    }

    /// <summary>The difference box lists the view's differences (the first <see cref="MaxListed"/>).</summary>
    private void SetDifferences(bool keepCurrent = false)
    {
        int current = _current;
        _settingDifference = true;
        try
        {
            ControlRetirement.ClearItems(_differenceBox);
            _differenceBox.ItemsSource = _descriptions.Count > MaxListed ? _descriptions.GetRange(0, MaxListed) : _descriptions.ToList();
            _differenceBox.IsEnabled = _descriptions.Count > 0 || _moreDifferences;
            _differenceBox.PlaceholderText = _descriptions.Count == 0 ? "No differences" : null;
        }
        finally
        {
            _settingDifference = false;
        }
        foreach (var button in new[] { _first, _previous, _next, _last }) button.IsEnabled = _descriptions.Count > 0;
        if (keepCurrent && current >= 0) SetCurrent(current, null);
        else _current = -1;
        _pastListed = null;
    }

    /// <summary>
    /// Compares the contents the window holds now. Everything that reads them runs off the UI thread: servers and
    /// phones answer slowly, and a large file takes a while (the summary shows how far it got).
    /// </summary>
    private async Task LoadAsync()
    {
        _work?.Cancel();
        var work = new CancellationTokenSource();
        _work = work;
        var ct = work.Token;
        var (left, right, leftView, rightView) = (_left, _right, _leftView, _rightView);
        IsComparing = true;
        _summary.Text = "Comparing…";
        var clock = System.Diagnostics.Stopwatch.StartNew();
        long shown = 0;
        void Progress(long done, long total)
        {
            // Every megabyte reports; the window shows it a few times a second.
            if (clock.ElapsedMilliseconds - shown < 250) return;
            shown = clock.ElapsedMilliseconds;
            string text = total > 0
                ? $"Comparing… {Formatters.SizeWithUnit(done)} of {Formatters.SizeWithUnit(total)} ({Math.Min(100, done * 100 / total)}%)"
                : $"Comparing… {Formatters.SizeWithUnit(done)}";
            Dispatcher.UIThread.Post(() =>
            {
                if (!ct.IsCancellationRequested) _summary.Text = text;
            });
        }
        try
        {
            // Every byte decides equality; text decoding and alignment are separate, labelled views. The reading counts
            // among the runs the contents wait for, so closing releases them once it stopped, whatever this thread does.
            var reading = Task.Run(() =>
            {
                var revisions = (Revision(left), Revision(right));
                long total = Math.Max(left.Length, right.Length);
                var bytes = BinaryDiff.Compare(left, right, ct, done => Progress(done, total));
                // The byte view reads through pages of its own, a page at a time as it is scrolled.
                var pages = (new PagedReader(leftView, 64), new PagedReader(rightView, 64));
                TextSide? l = null, r = null;
                string? problem = null;
                try
                {
                    l = TextSide.Load(left, ct);
                    r = TextSide.Load(right, ct);
                    if (l.Encoding.LooksBinary || r.Encoding.LooksBinary)
                    {
                        problem = "At least one file looks binary, so it is compared byte by byte.";
                        l = r = null;
                    }
                }
                catch (InvalidDataException ex)
                {
                    problem = ex.Message;
                    l = r = null;
                }
                return (bytes, pages, l, r, problem, revisions);
            }, ct);
            _runs = Task.WhenAll(_runs, reading);
            var loaded = await reading;
            if (_closed || ct.IsCancellationRequested)
            {
                DisposePages(loaded.pages);
                return;
            }
            var replaced = _pages;
            (_bytes, _pages, _leftText, _rightText, _textProblem, _revisions) = loaded;
            DisposePages(replaced);
            _aligning = null;
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ObjectDisposedException)
        {
            if (_closed || ct.IsCancellationRequested) return;
            _summary.Text = "The files could not be read: " + ex.Message;
            IsComparing = false;
            return;
        }
        // Without text on both sides only the bytes can be shown; a later comparison with text shows text again.
        bool text = _leftText is not null && _rightText is not null;
        _binary.IsEnabled = text;
        _settingOptions = true;
        if (!text)
        {
            _binaryForced |= _binary.IsChecked != true;
            _binary.IsChecked = true;
        }
        else if (_binaryForced)
        {
            _binaryForced = false;
            _binary.IsChecked = false;
        }
        _settingOptions = false;
        Recompute();
    }

    private static ContentRevision? Revision(IContentSource source)
    {
        try { return source.GetRevision(); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ObjectDisposedException or NotSupportedException) { return null; }
    }

    /// <summary>
    /// Contents are disposed once nothing reads them any more: a comparison, aligning or search stops at its next
    /// megabyte, and the byte view's page reads are let finish (and later ones refused). Only the readers count, not
    /// what this window's thread still has to do with their results: until the contents are disposed, Windows refuses
    /// to replace the files (release issue I22: a Synchronize right after closing a comparison failed).
    /// </summary>
    private void ReleaseWhenIdle(IContentSource left, IContentSource right, ViewSource leftView, ViewSource rightView)
    {
        void Release()
        {
            left.Dispose();
            right.Dispose();
        }
        var readers = Task.WhenAll(_runs, leftView.CloseAsync(), rightView.CloseAsync());
        if (readers.IsCompleted) Release();
        else readers.ContinueWith(_ => Release(), CancellationToken.None, TaskContinuationOptions.None, TaskScheduler.Default);
    }

    /// <summary>
    /// The byte view's page readers count against the shared content budget until disposed. Disposing them leaves the
    /// contents to <see cref="ReleaseWhenIdle"/>: their sources here are views whose Dispose does nothing.
    /// </summary>
    private static void DisposePages((PagedReader Left, PagedReader Right)? pages)
    {
        pages?.Left.Dispose();
        pages?.Right.Dispose();
    }

    /// <summary>F5: both files are opened and compared again (after they were edited, say).</summary>
    public async void CompareAgain()
    {
        if (!CanReopen || _closed || _reopening) return;
        RetireRangeReview();
        _reopening = true;
        _again.IsEnabled = false;
        _work?.Cancel();
        _summary.Text = "Reading the files again…";
        try
        {
            var (left, right) = await (_reopenAsync is not null ? _reopenAsync() : Task.Run(_reopen!));
            if (_closed)
            {
                left.Dispose();
                right.Dispose();
                return;
            }
            ReleaseWhenIdle(_left, _right, _leftView, _rightView);
            (_left, _right) = (left, right);
            (_leftView, _rightView) = (new ViewSource(left), new ViewSource(right));
            _changedBanner.IsVisible = false;
            _loading = LoadAsync();
            await _loading;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or NotSupportedException or OperationCanceledException)
        {
            if (!_closed) _summary.Text = "The files could not be read again: " + (ex is OperationCanceledException ? "canceled." : ex.Message);
        }
        finally
        {
            _reopening = false;
            _again.IsEnabled = true;
        }
    }

    /// <summary>
    /// Plan §16.2: a comparison never passes off files that changed since as compared. Coming back to the window
    /// (from the editor, say) checks both, and a change is said above the rows until the files are compared again.
    /// </summary>
    private async void CheckInputs()
    {
        if (_closed || _reopening || _checkingInputs || _bytes is null || _changedBanner.IsVisible || _revisions is (null, null)) return;
        _checkingInputs = true;
        try
        {
            var (left, right) = (_leftView, _rightView);
            var before = _revisions;
            var now = await Task.Run(() => (Revision(left), Revision(right)));
            if (_closed || !ReferenceEquals(left, _leftView) || !ReferenceEquals(right, _rightView)) return;
            if (before.Left is not null && now.Item1 is null || before.Right is not null && now.Item2 is null)
            {
                _changed.Text = "The files' current state could not be checked: what is shown is the earlier comparison. " +
                                (!CanReopen ? "Close this window and compare the files again." : "F5 compares them again.");
                _changedBanner.IsVisible = true;
                return;
            }
            var changed = new List<string>();
            if (before.Left is { } l && now.Item1 != l) changed.Add(Path.GetFileName(_leftName.TrimEnd('/', '\\')));
            if (before.Right is { } r && now.Item2 != r) changed.Add(Path.GetFileName(_rightName.TrimEnd('/', '\\')));
            if (changed.Count == 0) return;
            _changed.Text = (changed.Count == 2 ? "Both files changed" : $"\"{changed[0]}\" changed") + " after they were compared: what is shown is the earlier content. " +
                            (!CanReopen ? "Close this window and compare the files again." : "F5 compares them again.");
            _changedBanner.IsVisible = true;
        }
        finally
        {
            _checkingInputs = false;
        }
    }

    /// <summary>Shows the comparison with the current options; lines are aligned off the UI thread (a million take a second).</summary>
    private async void Recompute()
    {
        if (_bytes is not { } bytes || _settingOptions) return;
        RetireRangeReview();
        int view = ++_view;
        bool binary = _binary.IsChecked == true || _leftText is null || _rightText is null;
        // Options show where they apply: aligning to bytes, the rest to lines.
        _align.IsVisible = binary;
        _ignoreWhitespace.IsVisible = _ignoreCase.IsVisible = _collapse.IsVisible = !binary;
        // Identical files need no aligning: the exact comparison says so.
        bool aligned = binary && _align.IsChecked == true && !bytes.Equal;
        if (!aligned && _aligning is { IsCompleted: false })
        {
            _aligningStop?.Cancel();
            _aligning = null;
        }
        if (aligned)
        {
            await ShowAlignedAsync(view);
            return;
        }
        if (binary || _leftText is not { } left || _rightText is not { } right)
        {
            ShowBinary(bytes);
            return;
        }
        var options = new TextDiffOptions(_ignoreWhitespace.IsChecked == true, _ignoreCase.IsChecked == true);
        bool collapse = _collapse.IsChecked == true;
        IsComparing = true;
        if (_summary.Text?.StartsWith("Comparing", StringComparison.Ordinal) == true) _summary.Text = "Comparing lines…";
        var shown = await Task.Run(() => BuildText(left, right, bytes, options, collapse));
        // Options changed meanwhile, or the files were compared again: a newer view is on its way.
        if (view != _view || _closed) return;
        Show(Shown.Text);
        _textView.Reset();
        ControlRetirement.ClearItems(_rows);
        _rows.ItemsSource = shown.Rows;
        _differenceRows = shown.Differences;
        _descriptions = shown.Descriptions;
        _moreDifferences = false;
        SetDifferences();
        ShowFirstDifference();
        _summary.Text = shown.Summary;
        IsComparing = false;
        ScheduleFind();
    }

    /// <summary>The text rows, or the bytes (with the status line under them).</summary>
    private void Show(Shown shown)
    {
        RetireRangeReview();
        _shown = shown;
        bool text = shown == Shown.Text;
        _textTools.IsVisible = text;
        _findBar.IsVisible = text && _findOpen;
        if (!text) ScheduleFind();
        _selectBytes.IsVisible = !text && shown is Shown.Bytes or Shown.Aligned;
        _textBody.IsVisible = _fullLine.IsVisible = _wrapLines.IsVisible = text;
        _rows.IsVisible = text;
        _hex.IsVisible = !text;
        _statusBar.IsVisible = !text;
        if (text) _hex.SetContent(null, null, null, []);
        else
        {
            _textView.Reset();
            ControlRetirement.ClearItems(_rows);
            _lineDetails.SetComparisonRow(null);
        }
    }

    private void ShowBinary(BinaryDiffResult bytes)
    {
        _view++;
        Show(Shown.Bytes);
        _differences = [.. bytes.Ranges.Select(r => SameOffsetDifference(r, bytes))];
        _descriptions = [.. _differences.Select(Describe)];
        _moreDifferences = bytes.RangesTruncated;
        SetDifferences();
        _hex.SetContent(_pages?.Left, _pages?.Right, null, _differences);
        ShowFirstDifference();
        SetSummary(bytes);
        IsComparing = false;
    }

    private void SetSummary(BinaryDiffResult bytes)
    {
        string note = _textProblem is { } p && _leftText is null ? " " + p : "";
        _summary.Text = bytes.Equal
            ? $"Identical: every byte was compared ({bytes.LeftLength:N0} bytes).{note}"
            : $"{_differences.Count:N0}{(_moreDifferences ? "+" : "")} differing byte ranges at the same offsets" +
              (bytes.LeftLength != bytes.RightLength ? $"; lengths {bytes.LeftLength:N0} and {bytes.RightLength:N0} bytes" : "") +
              (_moreDifferences ? $"; the first {_differences.Count:N0} are listed, and Next difference finds the rest" : "") +
              ". Shifted content shows as differences from the shift on (Align shifted bytes finds it again)." + note;
    }

    /// <summary>
    /// Binary content aligned where bytes were inserted or removed (plan §16.2): the stretches side by side, every
    /// stretch that is not equal is a difference to go to, and the summary says what was found and that the pairing is
    /// heuristic.
    /// </summary>
    private async Task ShowAlignedAsync(int view)
    {
        IsComparing = true;
        var task = _aligning ??= StartAligning();
        if (!task.IsCompleted) _summary.Text = "Aligning shifted bytes…";
        (AlignedBinaryResult Result, List<AlignedRange> Differences) shown;
        try
        {
            shown = await task;
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ObjectDisposedException)
        {
            // Asking again tries again.
            if (ReferenceEquals(task, _aligning)) _aligning = null;
            if (view != _view || _closed) return;
            _summary.Text = "The files could not be read for aligning: " + ex.Message;
            IsComparing = false;
            return;
        }
        if (view != _view || _closed) return;
        var (aligned, differences) = shown;
        Show(Shown.Aligned);
        _differences = differences;
        _descriptions = [.. differences.Select(Describe)];
        _moreDifferences = false;
        SetDifferences();
        _hex.SetContent(_pages?.Left, _pages?.Right, aligned.Ranges, differences);
        ShowFirstDifference();
        _summary.Text = AlignedSummary(aligned, differences.Count);
        IsComparing = false;
    }

    private Task<(AlignedBinaryResult Result, List<AlignedRange> Differences)> StartAligning()
    {
        var stop = CancellationTokenSource.CreateLinkedTokenSource(_work?.Token ?? CancellationToken.None);
        _aligningStop = stop;
        var ct = stop.Token;
        var (left, right) = (_left, _right);
        long total = Math.Max(1, left.Length + right.Length);
        var clock = System.Diagnostics.Stopwatch.StartNew();
        long shown = 0;
        var run = Task.Run(() =>
        {
            var result = AlignedBinaryDiff.Compare(left, right, ct, done =>
            {
                // Reported every megabyte; shown a few times a second.
                if (clock.ElapsedMilliseconds - shown < 250) return;
                shown = clock.ElapsedMilliseconds;
                string text = $"Aligning shifted bytes… {Math.Min(100, done * 100 / total)}%";
                Dispatcher.UIThread.Post(() =>
                {
                    if (!ct.IsCancellationRequested && !_closed) _summary.Text = text;
                });
            });
            return (result, result.Ranges.Where(r => r.Kind != DiffKind.Equal).ToList());
        }, ct);
        _runs = Task.WhenAll(_runs, run);
        return run;
    }

    /// <summary>"1 byte", "40,000 bytes"; two different counts as "3 → 5 bytes".</summary>
    private static string Bytes(long left, long? right = null) =>
        right is { } r && r != left ? $"{left:N0} → {r:N0} bytes" : left == 1 ? "1 byte" : $"{left:N0} bytes";

    private static string AlignedSummary(AlignedBinaryResult aligned, int differences)
    {
        static string Stretches(IReadOnlyList<AlignedRange> ranges, DiffKind kind, string what)
        {
            var these = ranges.Where(r => r.Kind == kind).ToList();
            if (these.Count == 0) return "none " + what;
            long left = these.Sum(r => r.LeftLength), right = these.Sum(r => r.RightLength);
            string bytes = kind switch
            {
                DiffKind.LeftOnly => Bytes(left),
                DiffKind.RightOnly => Bytes(right),
                _ => Bytes(left, right),
            };
            return $"{these.Count:N0} {(these.Count == 1 ? "stretch" : "stretches")} {what} ({bytes})";
        }
        var summary = new StringBuilder("Aligned: ")
            .Append(Stretches(aligned.Ranges, DiffKind.RightOnly, "inserted")).Append(", ")
            .Append(Stretches(aligned.Ranges, DiffKind.LeftOnly, "removed")).Append(", ")
            .Append(Stretches(aligned.Ranges, DiffKind.Changed, "changed"));
        if (aligned.LeftLength > 0)
        {
            // Never rounded up to "all" when a byte is missing.
            double found = aligned.EqualBytes == aligned.LeftLength ? 100 : Math.Min(99.99, Math.Floor(aligned.EqualBytes * 10_000.0 / aligned.LeftLength) / 100);
            summary.Append($"; {found:0.##}% of the left file was found again in order");
        }
        summary.Append('.');
        if (!aligned.Complete) summary.Append(" The work limit was reached: the rest is not aligned.");
        if (differences > MaxListed) summary.Append($" The first {MaxListed:N0} differences are listed; the arrows go through all of them.");
        summary.Append($" Heuristic: matched in blocks of {aligned.BlockSize:N0} bytes, so shorter equal stretches and moved or repeated content can be paired differently.");
        return summary.ToString();
    }

    private static (List<object> Rows, List<int> Differences, List<string> Descriptions, string Summary) BuildText(TextSide left, TextSide right, BinaryDiffResult bytes,
        TextDiffOptions options, bool collapse)
    {
        var result = TextDiff.Compare(left.Lines, right.Lines, options);
        var rows = new List<object>();
        var diff = new List<int>();
        var descriptions = new List<string>();
        int endings = 0, changed = 0, leftOnly = 0, rightOnly = 0;
        static string Lines(int n) => n == 1 ? "1 line" : $"{n:N0} lines";
        foreach (var block in result.Blocks)
        {
            if (block.Kind != DiffKind.Equal)
            {
                diff.Add(rows.Count);
                int l = block.LeftStart + 1, r = block.RightStart + 1;
                descriptions.Add($"{diff.Count:N0}: " + block.Kind switch
                {
                    DiffKind.Changed => $"{Lines(block.LeftCount)} changed at line {l:N0}" + (r != l ? $" (right {r:N0})" : ""),
                    DiffKind.LeftOnly => $"{Lines(block.LeftCount)} only left, at line {l:N0}",
                    DiffKind.RightOnly => $"{Lines(block.RightCount)} only right, at line {r:N0}",
                    _ => $"{block.LeftCount:N0} left and {block.RightCount:N0} right lines not aligned, at line {l:N0}",
                });
            }
            switch (block.Kind)
            {
                case DiffKind.Equal:
                    for (int i = 0; i < block.LeftCount; i++)
                    {
                        bool ending = TextDiff.TerminatorDiffers(left, block.LeftStart + i, right, block.RightStart + i);
                        if (ending) endings++;
                        if (collapse && !ending && block.LeftCount > 7 && i >= 3 && i < block.LeftCount - 3)
                        {
                            if (i == 3) rows.Add($"   ⋯ {block.LeftCount - 6:N0} equal lines");
                            continue;
                        }
                        rows.Add(new CompareRow(DiffKind.Equal, block.LeftStart + i + 1, left.Lines[block.LeftStart + i], block.RightStart + i + 1,
                            right.Lines[block.RightStart + i], ending));
                    }
                    break;
                case DiffKind.Changed:
                    changed += block.LeftCount;
                    for (int i = 0; i < block.LeftCount; i++)
                        rows.Add(new CompareRow(DiffKind.Changed, block.LeftStart + i + 1, left.Lines[block.LeftStart + i], block.RightStart + i + 1, right.Lines[block.RightStart + i]));
                    break;
                case DiffKind.LeftOnly:
                    leftOnly += block.LeftCount;
                    for (int i = 0; i < block.LeftCount; i++) rows.Add(new CompareRow(DiffKind.LeftOnly, block.LeftStart + i + 1, left.Lines[block.LeftStart + i], null, ""));
                    break;
                case DiffKind.RightOnly:
                    rightOnly += block.RightCount;
                    for (int i = 0; i < block.RightCount; i++) rows.Add(new CompareRow(DiffKind.RightOnly, null, "", block.RightStart + i + 1, right.Lines[block.RightStart + i]));
                    break;
                case DiffKind.Unaligned:
                    rows.Add($"   Not aligned line by line (too large to align within limits): {block.LeftCount:N0} left lines, then {block.RightCount:N0} right lines");
                    for (int i = 0; i < block.LeftCount; i++) rows.Add(new CompareRow(DiffKind.Unaligned, block.LeftStart + i + 1, left.Lines[block.LeftStart + i], null, ""));
                    for (int i = 0; i < block.RightCount; i++) rows.Add(new CompareRow(DiffKind.Unaligned, null, "", block.RightStart + i + 1, right.Lines[block.RightStart + i]));
                    break;
            }
        }
        var summary = new StringBuilder();
        if (bytes.Equal) summary.Append($"Identical: every byte was compared ({bytes.LeftLength:N0} bytes).");
        else if (result.Identical)
        {
            // Same text, different bytes: say what differs rather than calling the files identical.
            summary.Append("The text is the same, but the files differ in bytes");
            var reasons = new List<string>();
            if (endings > 0) reasons.Add($"line endings on {endings:N0} lines");
            if (left.Encoding.Encoding.WebName != right.Encoding.Encoding.WebName) reasons.Add($"encoding ({left.Encoding.Encoding.WebName} and {right.Encoding.Encoding.WebName})");
            if (left.Encoding.PreambleLength != right.Encoding.PreambleLength) reasons.Add("a byte-order mark");
            if (options.IgnoreWhitespace || options.IgnoreCase) reasons.Add("ignored whitespace or case");
            summary.Append(reasons.Count > 0 ? ": " + string.Join(", ", reasons) + "." : ". Switch to Binary to see where.");
        }
        else
        {
            summary.Append($"{result.Differences:N0} {(result.Differences == 1 ? "difference" : "differences")}: {changed:N0} changed, {leftOnly:N0} only left, {rightOnly:N0} only right");
            if (endings > 0) summary.Append($"; line endings differ on {endings:N0} other lines");
            summary.Append('.');
            if (result.Approximate) summary.Append(" Some regions were too large to align line by line; they are shown unaligned, not paired.");
            if (result.Heuristic) summary.Append(" Large stretches were matched on lines that occur once on each side, which can show more differences than the fewest possible.");
        }
        return (rows, diff, descriptions, summary.ToString());
    }

    /// <summary>
    /// The byte view and revision checks borrow the content, so it is disposed after active calls finish and further
    /// calls are refused once the window lets go of it (the view's page loads run on pool threads).
    /// </summary>
    private sealed class ViewSource(IContentSource inner) : IContentSource
    {
        private readonly object _lock = new();
        private readonly TaskCompletionSource _idle = new(TaskCreationOptions.RunContinuationsAsynchronously);
        private int _activeCalls;
        private bool _closed;

        public string DisplayName => inner.DisplayName;
        public long Length
        {
            get
            {
                BeginCall();
                try { return inner.Length; }
                finally { EndCall(); }
            }
        }
        public bool CanSeek => inner.CanSeek;
        public string? LocalPath => inner.LocalPath;

        public int Read(long offset, Span<byte> buffer)
        {
            BeginCall();
            try
            {
                return inner.Read(offset, buffer);
            }
            finally
            {
                EndCall();
            }
        }

        public ContentRevision? GetRevision()
        {
            BeginCall();
            try { return inner.GetRevision(); }
            finally { EndCall(); }
        }

        private void BeginCall()
        {
            lock (_lock)
            {
                ObjectDisposedException.ThrowIf(_closed, this);
                _activeCalls++;
            }
        }

        private void EndCall()
        {
            lock (_lock)
            {
                if (--_activeCalls == 0 && _closed) _idle.TrySetResult();
            }
        }

        /// <summary>Refuses further content calls; completes when the ones under way finished.</summary>
        public Task CloseAsync()
        {
            lock (_lock)
            {
                _closed = true;
                if (_activeCalls == 0) _idle.TrySetResult();
            }
            return _idle.Task;
        }

        /// <summary>The window disposes the content itself.</summary>
        public void Dispose() { }
    }
}
