using System.IO.Pipes;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using FileCat.Core.FileSystem;
using Microsoft.Win32.SafeHandles;

namespace FileCat.App;

/// <summary>
/// One instance per profile and data folder (A-07): a second launch forwards its arguments over a per-user named pipe
/// and exits. The pipe is local, bound to the current user name, and accepts only a small JSON array.
/// </summary>
public static partial class SingleInstance
{
    private static Mutex? _mutex;
    private static string? _windowsName;
    private static CancellationTokenSource? _cts;
    private static FileStream? _unixLock;
    private static string? _unixEndpointFile;
    private static string? _unixPipeName;
    private static Task? _serverTask;
    private static FileStream? _independentLock;
    private static string? _independentFile;

    private const string UnixLockFile = "instance.lock";
    private const string UnixEndpointFile = "instance.pipe";

    public static event Action<string[]>? ArgumentsReceived;

    /// <summary>
    /// A read-only process census for device recovery. State-root probes cannot inventory a different portable copy
    /// or arbitrary --data root. Require other FileCat processes to finish; null means the census was unavailable.
    /// </summary>
    public static bool? OtherFileCatRunning() => OtherFileCatRunning(null);

    internal static bool? OtherFileCatRunning(Func<Process[]>? enumerate, Func<Process, bool?>? identify = null,
        int? additionallyExcludedProcessId = null, Action<int, string, string>? diagnostic = null)
    {
        var snapshot = new List<Process>();
        var inspectedImages = new Dictionary<string, bool?>(StringComparer.OrdinalIgnoreCase);
        try
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "FileCat", "dotnet" };
            if (System.Reflection.Assembly.GetEntryAssembly() == typeof(SingleInstance).Assembly)
            {
                using var current = Process.GetCurrentProcess();
                names.Add(current.ProcessName);
            }
            snapshot.AddRange((enumerate ?? Process.GetProcesses)());
            bool unknown = false;
            foreach (var process in snapshot)
            {
                if (process.Id == Environment.ProcessId || process.Id == additionallyExcludedProcessId) continue;
                try
                {
                    // PID 0 is Windows' idle accounting entry, not an executable. Even HasExited can
                    // raise access denied for it, before an image-path query is possible.
                    if (OperatingSystem.IsWindows() && process.Id == 0 && process.ProcessName == "Idle") continue;
                    if (process.HasExited) continue;
                    if (OperatingSystem.IsMacOS())
                    {
                        bool? running = MacProcessCanExecute(process.Id);
                        if (running == false) continue;
                        unknown |= running is null;
                    }
                    if (enumerate is null && OperatingSystem.IsLinux())
                    {
                        bool? kernel = KernelThreadFromStat(File.ReadAllText($"/proc/{process.Id}/stat"));
                        if (kernel == true) continue; // A kernel thread cannot host the managed application.
                        unknown |= kernel is null;
                    }
                    // The existing test seam supplies an already selected candidate inventory. Production also
                    // inspects other executable names: a renamed apphost still binds the FileCat entry assembly.
                    bool? match;
                    string? unknownReason = null;
                    if (identify is not null) match = identify(process);
                    else if (enumerate is not null) match = true;
                    else if (OperatingSystem.IsWindows() && process.ProcessName.Equals("dotnet", StringComparison.OrdinalIgnoreCase))
                    {
                        // A renamed FileCat apphost can itself be called dotnet.exe. Inspect both the
                        // image and the managed host command before declaring this process unrelated.
                        var image = Platform.Windows.ProcessIdentity.QueryImagePath(process.Id);
                        bool? apphost = image.Path is { } path && inspectedImages.TryGetValue(path, out var inspected)
                            ? inspected : IsFileCatAppHost(image.Path);
                        if (image.Path is { } inspectedPath) inspectedImages[inspectedPath] = apphost;
                        bool? managed = Platform.Windows.ProcessIdentity.IsFileCatManagedHostCommand(
                            Platform.Windows.ProcessIdentity.CommandLine(process.Id));
                        match = Platform.Windows.ProcessIdentity.CombineAppHostAndManagedCommand(apphost, managed);
                    }
                    else if (names.Contains(process.ProcessName)) match = true;
                    else if (OperatingSystem.IsWindows())
                    {
                        var image = Platform.Windows.ProcessIdentity.QueryImagePath(process.Id);
                        if (Platform.Windows.ProcessIdentity.IsKernelOnlyProcess(
                                process.Id, process.ProcessName, process.SessionId, image)) continue;
                        if (image.Path is { } path && inspectedImages.TryGetValue(path, out var inspected))
                            match = inspected;
                        else
                        {
                            match = IsFileCatAppHost(image.Path);
                            if (image.Path is { } inspectedPath) inspectedImages[inspectedPath] = match;
                        }
                        if (match is null)
                            unknownReason = image.Path is null ? $"image error {image.Error}" : $"incomplete image scan: {image.Path}";
                    }
                    else match = IsFileCatAppHost(process.MainModule?.FileName);
                    if (match == true)
                    {
                        diagnostic?.Invoke(process.Id, process.ProcessName, "match");
                        return true;
                    }
                    if (match is null) diagnostic?.Invoke(process.Id, process.ProcessName, unknownReason ?? "unknown identity");
                    unknown |= match is null;
                }
                catch (Exception ex) when (ex is Win32Exception or InvalidOperationException or NotSupportedException
                                           or IOException or UnauthorizedAccessException)
                {
                    // An inaccessible or disappearing executable is not evidence that no FileCat is running.
                    diagnostic?.Invoke(process.Id, process.ProcessName, $"{ex.GetType().Name}: {ex.Message}");
                    unknown = true;
                }
            }
            return unknown ? null : false;
        }
        catch (Exception ex) when (ex is Win32Exception or InvalidOperationException or NotSupportedException)
        {
            return null;
        }
        finally { foreach (var process in snapshot) process.Dispose(); }
    }

    private static bool? IsFileCatAppHost(string? path)
    {
        if (string.IsNullOrEmpty(path)) return null;
        using var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        return IsFileCatAppHost(input);
    }

    // Electron and native tooling apphosts commonly exceed 64 MiB. Keep a finite
    // limit, but inspect mainstream executable sizes before declaring identity unknown.
    internal const int RecoveryProcessImageReadLimit = 512 * 1024 * 1024;

    internal static bool? KernelThreadFromStat(string stat)
    {
        // proc(5) field 9 is the kernel's task flags; PF_KTHREAD is 0x00200000. The command may contain ')'.
        int end = stat.LastIndexOf(')');
        if (stat.Length > 4096 || end < 0) return null;
        var fields = stat[(end + 1)..].Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return fields.Length > 6 && uint.TryParse(fields[6], System.Globalization.NumberStyles.None,
            System.Globalization.CultureInfo.InvariantCulture, out uint flags) ? (flags & 0x00200000) != 0 : null;
    }

    internal static bool? IsFileCatAppHost(Stream input)
    {
        // Published apphosts bind this NUL-terminated relative assembly path even when the executable is renamed.
        // Bound reads of other executables; an incomplete inspection remains unknown, never an absent process.
        ReadOnlySpan<byte> binding = "FileCat.dll\0"u8;
        const int limit = RecoveryProcessImageReadLimit;
        if (input.CanSeek && input.Length > limit) return null;
        byte[] buffer = new byte[8192 + binding.Length];
        int carry = 0, total = 0;
        while (total < limit)
        {
            int count = input.Read(buffer, carry, Math.Min(8192, limit - total));
            if (count == 0) return false;
            total += count;
            var data = buffer.AsSpan(0, carry + count);
            int start = 0, offset;
            while ((offset = data[start..].IndexOf(binding)) >= 0)
            {
                offset += start;
                if (offset == 0 && total == count || offset > 0 && data[offset - 1] is 0 or (byte)'/' or (byte)'\\') return true;
                start = offset + 1;
            }
            carry = Math.Min(binding.Length, data.Length);
            data[^carry..].CopyTo(buffer);
        }
        return input.ReadByte() < 0 ? false : null;
    }

    private static string BaseName(string? profile, string? dataRoot)
    {
        // A FileCat keeping its files in a folder of their own (--data) is another instance than the usual one. The
        // profile is named as its folders name it: "Work!" and "Work" share one profile's files, so they are one instance.
        var id = $"{Environment.UserDomainName}\\{Environment.UserName}|{Core.State.AppPaths.ProfileFolderName(profile)}" +
                 (dataRoot is null ? "" : "|" + (OperatingSystem.IsWindows() ? dataRoot.ToUpperInvariant() : dataRoot));
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(id)))[..16];
        return "FileCat-" + hash;
    }

    // Windows profile names can differ in case while their folders are the same. Use the actual selected state
    // directory, which also distinguishes portable state from usual state and default from profiles/DEFAULT.
    private static string WindowsName(string localDirectory) => BaseName(null, Path.GetFullPath(localDirectory));

    private static int UnixSocketPathLimit => OperatingSystem.IsMacOS() ? 104 : 108;

    private static string UnixPipeDirectory
    {
        get
        {
            string temp = Path.GetTempPath();
            // sun_path includes a terminating NUL; count UTF-8 bytes, not characters. An absolute pipe name avoids
            // .NET's additional CoreFxPipe_ prefix. If even that cannot fit, use a short, private per-user directory.
            return Encoding.UTF8.GetByteCount(Path.Combine(temp, "FileCat-0000000000000000")) < UnixSocketPathLimit
                ? temp
                : "/tmp/filecat-" + Core.FileSystem.UnixPermissions.CurrentUserId.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
    }

    /// <summary>An IPC folder outside the configured temporary directory, included in the recovery write guard.</summary>
    internal static string? ExtraWriteFolder => OperatingSystem.IsWindows() || UnixPipeDirectory == Path.GetTempPath()
        ? null : UnixPipeDirectory;

    private static string PipeName(string name)
    {
        if (OperatingSystem.IsWindows()) return name;
        // Use .NET's relative endpoint wherever its prefix fits; otherwise choose the shorter absolute path.
        return Encoding.UTF8.GetByteCount(Path.Combine(Path.GetTempPath(), "CoreFxPipe_" + name)) < UnixSocketPathLimit
            ? name : Path.Combine(UnixPipeDirectory, name);
    }

    private static string AbsolutePipeName(string name) => PipeName(name) is { } pipe && Path.IsPathRooted(pipe)
        ? pipe : Path.Combine(Path.GetTempPath(), "CoreFxPipe_" + name);

    private sealed record UnixEndpoint(string Pipe, string TemporaryFolder);
    private sealed record InstanceRuntime(string TemporaryFolder);

    private static T? ReadInstanceMetadata<T>(string file) where T : class
    {
        // A stale or replaced per-user metadata pathname can be a FIFO. Open without blocking and
        // require a regular opened descriptor before the forwarding or recovery-safety path reads it.
        using var input = OperatingSystem.IsWindows()
            ? new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete)
            : new FileStream(UnixFiles.OpenRegularFileForRead(file), FileAccess.Read);
        // Bound the read as well as the initial length, including a file changed while it is being read.
        var bytes = new byte[32769];
        int length = 0, count;
        while (length < bytes.Length && (count = input.Read(bytes, length, bytes.Length - length)) > 0) length += count;
        if (length == bytes.Length) return null;
        try { return JsonSerializer.Deserialize<T>(bytes.AsSpan(0, length)); }
        catch (JsonException) { return default; }
    }

    private static UnixEndpoint? ReadUnixEndpoint(string file)
    {
        var endpoint = ReadInstanceMetadata<UnixEndpoint>(file);
        if (endpoint is not { Pipe: { } pipe, TemporaryFolder: { } temporary }) return null;
        string name = Path.GetFileName(pipe);
        if (name.StartsWith("CoreFxPipe_", StringComparison.Ordinal)) name = name[11..];
        return Path.IsPathFullyQualified(temporary) && !temporary.Contains('\0') &&
               Path.IsPathFullyQualified(pipe) && Encoding.UTF8.GetByteCount(pipe) < UnixSocketPathLimit &&
               !pipe.Contains('\0') && name.Length == 24 && name.StartsWith("FileCat-", StringComparison.Ordinal) &&
               name.AsSpan(8).IndexOfAnyExcept("0123456789ABCDEF") < 0 ? endpoint : null;
    }

    private static FileStream? OpenUnixLock(string path, bool create)
    {
        // Unix Local mutexes are shell-session scoped, and .NET writes their files under /tmp even with another TMPDIR.
        // A persistent profile-local file instead elects one owner across sessions, inside the tracked write folders.
        // Do not unlink it on release: another opener must never lock a replacement inode while the old one is held.
        if (new FileInfo(path).LinkTarget is not null)
            throw new UnauthorizedAccessException("The FileCat instance lock is a symbolic link.");
        FileStream? stream = null;
        try
        {
            var options = new FileStreamOptions
            {
                Mode = create ? FileMode.OpenOrCreate : FileMode.Open,
                Access = create ? FileAccess.ReadWrite : FileAccess.Read,
                Share = FileShare.None,
                BufferSize = 1,
                UnixCreateMode = create ? UnixFileMode.UserRead | UnixFileMode.UserWrite : null,
            };
            stream = OperatingSystem.IsWindows() ? new FileStream(path, options)
                : OpenUnixRegularLock(path, create, exclusive: false);
            // The native lock elects the owner, including on removable filesystems.
            int error;
            do
            {
                if (Flock(stream.SafeFileHandle.DangerousGetHandle().ToInt32(), 2 | 4) == 0) return stream; // EX | NB
                error = Marshal.GetLastPInvokeError();
            } while (error == 4); // EINTR
            throw new IOException("Cannot lock the FileCat instance file: " + new Win32Exception(error).Message,
                unchecked((int)0x80070000) | error);
        }
        catch (IOException ex) when ((ex.HResult & 0xFFFF) is 11 or 35) // EWOULDBLOCK on Linux / macOS
        {
            stream?.Dispose();
            return null;
        }
        catch
        {
            stream?.Dispose();
            throw;
        }
    }

    private static NamedPipeClientStream ConnectUnixEndpoint(string file)
    {
        var until = Environment.TickCount64 + 2000;
        do
        {
            string? pipe = null;
            // An owner can still be publishing its endpoint, and a stale/unreadable pathname is
            // treated like an absent endpoint for this finite retry rather than launching early.
            try { pipe = ReadUnixEndpoint(file)?.Pipe; } catch (IOException) { }
            if (pipe is not null)
            {
                var client = new NamedPipeClientStream(".", pipe, PipeDirection.Out, PipeOptions.CurrentUserOnly);
                try
                {
                    client.Connect(100);
                    return client;
                }
                catch (Exception ex) when (ex is TimeoutException or IOException)
                {
                    client.Dispose();
                }
                catch
                {
                    client.Dispose();
                    throw;
                }
            }
            // Re-read metadata: a new owner may have replaced the preceding instance's stale endpoint meanwhile.
            Thread.Sleep(20);
        } while (Environment.TickCount64 < until);
        throw new TimeoutException("The running FileCat did not answer its instance connection.");
    }

    [LibraryImport("libc", EntryPoint = "flock", SetLastError = true)]
    private static partial int Flock(int fd, int operation);

    [LibraryImport("libc", EntryPoint = "open", StringMarshalling = StringMarshalling.Utf8, SetLastError = true)]
    private static partial int OpenLockNative(string path, int flags);

    private static FileStream OpenUnixRegularLock(string path, bool create, bool exclusive)
    {
        // An existing instance file can be replaced by a FIFO between enumeration and open. A nonblocking
        // descriptor check closes that race; O_NOFOLLOW also rejects a link swapped in after the path check.
        // On Apple Silicon libc open's creation mode is variadic and uses a different calling convention.
        // Let FileStream create a new regular inode with the requested 0600 mode, then use the two-argument
        // native open only for an existing path. CreateNew rejects an existing FIFO without opening it.
        if (create)
        {
            try
            {
                var created = new FileStream(path, new FileStreamOptions
                {
                    Mode = FileMode.CreateNew,
                    Access = FileAccess.ReadWrite,
                    Share = FileShare.None,
                    BufferSize = 1,
                    UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite,
                });
                try
                {
                    if (UnixFiles.Stat(created.SafeFileHandle) is { IsRegular: true }) return created;
                    throw new IOException("The FileCat instance file is not a regular file.");
                }
                catch { created.Dispose(); throw; }
            }
            catch (IOException) when (!exclusive && UnixFiles.Stat(path) is not null) { }
        }
        int flags = OperatingSystem.IsMacOS()
            ? 4 | 16777216 | 256   // O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW
            : 2048 | 524288 | 131072;
        if (create) flags |= 2; // O_RDWR; creation above is exclusive and owner-only
        int fd = OpenLockNative(path, flags);
        if (fd < 0)
        {
            int error = Marshal.GetLastPInvokeError();
            if (error == 2) throw new FileNotFoundException("The FileCat instance file is absent.", path);
            throw new IOException("Cannot open the FileCat instance file: " + new Win32Exception(error).Message,
                unchecked((int)0x80070000) | error);
        }
        var handle = new SafeFileHandle((IntPtr)fd, ownsHandle: true);
        try
        {
            if (UnixFiles.Stat(handle) is not { IsRegular: true })
                throw new IOException("The FileCat instance file is not a regular file.");
            return new FileStream(handle, create ? FileAccess.ReadWrite : FileAccess.Read, 1);
        }
        catch { handle.Dispose(); throw; }
    }

    private static FileStream? OpenIndependentLock(string file, bool create)
    {
        if (new FileInfo(file).LinkTarget is not null)
            throw new UnauthorizedAccessException("The FileCat instance lifetime file is a symbolic link.");
        FileStream? stream = null;
        try
        {
            var options = new FileStreamOptions
            {
                Mode = create ? FileMode.CreateNew : FileMode.Open,
                Access = create ? FileAccess.ReadWrite : FileAccess.Read,
                Share = FileShare.None,
            };
            if (create && !OperatingSystem.IsWindows()) options.UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite;
            stream = OperatingSystem.IsWindows() ? new FileStream(file, options)
                : OpenUnixRegularLock(file, create, exclusive: create);
            if (!OperatingSystem.IsWindows())
            {
                int error;
                do
                {
                    if (Flock(stream.SafeFileHandle.DangerousGetHandle().ToInt32(), 2 | 4) == 0) return stream;
                    error = Marshal.GetLastPInvokeError();
                } while (error == 4);
                throw new IOException("Cannot lock the FileCat instance lifetime: " + new Win32Exception(error).Message,
                    unchecked((int)0x80070000) | error);
            }
            return stream;
        }
        catch (IOException ex) when (!create && (ex.HResult & 0xFFFF) is 11 or 35 or 32 or 33)
        {
            stream?.Dispose();
            return null;
        }
        catch { stream?.Dispose(); throw; }
    }

    private static void RegisterIndependent(StartupOptions options)
    {
        var paths = Core.State.AppPaths.Resolve(options.Profile, dataRoot: options.DataRoot);
        if (OperatingSystem.IsWindows()) Directory.CreateDirectory(paths.InstancesDirectory);
        else Directory.CreateDirectory(paths.InstancesDirectory, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        _independentFile = Path.Combine(paths.InstancesDirectory, "running-" + Guid.NewGuid().ToString("N") + ".lock");
        _independentLock = OpenIndependentLock(_independentFile, create: true)!;
        var metadataOptions = new FileStreamOptions { Mode = FileMode.CreateNew, Access = FileAccess.Write, Share = FileShare.None };
        if (!OperatingSystem.IsWindows()) metadataOptions.UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite;
        // Metadata has its own inode: Unix FileStream readers also take an advisory lock, conflicting with the live
        // lifetime lock. An incomplete metadata file conservatively refuses a scan until registration finishes.
        using var metadata = new FileStream(Path.ChangeExtension(_independentFile, ".json"), metadataOptions);
        metadata.Write(JsonSerializer.SerializeToUtf8Bytes(new InstanceRuntime(Path.GetTempPath())));
        metadata.Flush();
    }

    private static IEnumerable<string> IndependentFiles(Core.State.AppPaths paths)
    {
        string directory = paths.InstancesDirectory;
        // Do not treat access errors as absence. A missing directory is the only empty-directory shortcut.
        try { return Directory.GetFiles(directory, "running-*.lock"); }
        catch (DirectoryNotFoundException) { return []; }
    }

    /// <summary>All usual profiles, read without creating folders, including profiles other than the recovering one.</summary>
    internal static IReadOnlyList<string>? UsualProfiles(string? profile, string? baseDirectory = null)
    {
        // "default" is a special root; "DEFAULT" names profiles/DEFAULT even on a case-insensitive filesystem.
        var profiles = new HashSet<string>(StringComparer.Ordinal)
        {
            "default", Core.State.AppPaths.ProfileFolderName(profile),
        };
        try
        {
            var roots = Core.State.AppPaths.UsualCandidates(baseDirectory: baseDirectory)
                .SelectMany(paths => new[] { paths.SettingsDirectory, paths.LocalDirectory })
                .Distinct(OperatingSystem.IsWindows() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal);
            foreach (string root in roots)
            {
                string[] folders;
                try { folders = Directory.GetDirectories(Path.Combine(root, "profiles")); }
                catch (DirectoryNotFoundException) { continue; }
                foreach (string folder in folders)
                {
                    string name = Path.GetFileName(folder);
                    if (Core.State.AppPaths.ProfileFolderName(name) == name) profiles.Add(name);
                }
            }
        }
        catch (DirectoryNotFoundException) { }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return null; }
        return profiles.ToArray();
    }

    /// <summary>Known live-instance write locations. Null means an active instance's locations cannot be known.</summary>
    internal static IReadOnlyList<(string What, string Folder)>? UsualWriteFolders(string? profile, string? baseDirectory = null)
    {
        var folders = new List<(string What, string Folder)>();
        try
        {
            foreach (var paths in Core.State.AppPaths.UsualCandidates(profile, baseDirectory))
            {
                bool active = UsualOwnerRunning(paths);
                if (!OperatingSystem.IsWindows() && active)
                {
                    string file = Path.Combine(paths.LocalDirectory, UnixEndpointFile);
                    if (ReadUnixEndpoint(file) is not { } endpoint || Path.GetDirectoryName(endpoint.Pipe) is not { } socket)
                        return null;
                    folders.Add(("the running FileCat's instance connection", socket));
                    folders.Add(("the running FileCat's runtime temporary files", endpoint.TemporaryFolder));
                }
                foreach (string file in IndependentFiles(paths))
                {
                    FileStream? inactive;
                    try { inactive = OpenIndependentLock(file, create: false); }
                    catch (FileNotFoundException) { continue; } // The process closed and removed its own file.
                    // Missing active metadata is unknown, including while registration is still in progress.
                    using (inactive) { if (inactive is not null) continue; }
                    active = true;
                    var runtime = ReadInstanceMetadata<InstanceRuntime>(Path.ChangeExtension(file, ".json"));
                    if (runtime?.TemporaryFolder is not { } temp || !Path.IsPathFullyQualified(temp) || temp.Contains('\0'))
                        return null;
                    if (!OperatingSystem.IsWindows()) folders.Add(("the running FileCat's runtime temporary files", temp));
                }
                if (active) folders.AddRange(paths.WriteFolders);
            }
            return folders;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return null; }
    }

    private static void EnsurePipeDirectory()
    {
        if (ExtraWriteFolder is not { } folder) return;
        Directory.CreateDirectory(folder, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        // /tmp is sticky: another user cannot replace our directory. Reject an existing link, foreign owner or a
        // directory open to other users, without chmod/chown or removing anything that we do not own.
        if (new DirectoryInfo(folder).LinkTarget is not null ||
            Core.FileSystem.UnixPermissions.Stat(folder) is not { } stat ||
            stat.Uid != Core.FileSystem.UnixPermissions.CurrentUserId ||
            (File.GetUnixFileMode(folder) & (UnixFileMode.GroupRead | UnixFileMode.GroupWrite | UnixFileMode.GroupExecute |
                                           UnixFileMode.OtherRead | UnixFileMode.OtherWrite | UnixFileMode.OtherExecute)) != 0)
            throw new UnauthorizedAccessException("The FileCat instance connection folder is not private to this account.");
    }

    /// <summary>
    /// Whether a FileCat of this user is running with <paramref name="profile"/> and its usual files (started without
    /// --data). Asked by a FileCat started with --data, never of itself; true when that cannot be told.
    /// </summary>
    public static bool UsualInstanceRunning(string? profile) => UsualInstanceRunning(profile, null);

    internal static bool UsualInstanceRunning(string? profile, string? baseDirectory)
    {
        try
        {
            foreach (var paths in Core.State.AppPaths.UsualCandidates(profile, baseDirectory))
            {
                foreach (string file in IndependentFiles(paths))
                {
                    try
                    {
                        using var inactive = OpenIndependentLock(file, create: false);
                        if (inactive is null) return true;
                    }
                    catch (FileNotFoundException) { }
                }
                if (UsualOwnerRunning(paths)) return true;
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return true; }
        return false;
    }

    private static bool UsualOwnerRunning(Core.State.AppPaths paths)
    {
        string name = BaseName(paths.ProfileName, null);
        if (!OperatingSystem.IsWindows())
        {
            // Opening an existing profile lock read-only does not create directories, write metadata or probe a mutex.
            // A busy lock counts as running even before its listener is ready, or when that listener cannot be reached.
            try
            {
                using var owner = OpenUnixLock(Path.Combine(paths.LocalDirectory, UnixLockFile), create: false);
                return owner is null;
            }
            catch (Exception ex) when (ex is FileNotFoundException or DirectoryNotFoundException)
            {
                // Compatibility with an already-running build that predates the profile lock.
                if (!File.Exists(AbsolutePipeName(name))) return false;
                try
                {
                    using var client = new NamedPipeClientStream(".", PipeName(name), PipeDirection.Out, PipeOptions.CurrentUserOnly);
                    client.Connect(500);
                    return true;
                }
                catch (Exception probe) when (probe is TimeoutException or IOException) { return false; }
                catch (UnauthorizedAccessException) { return true; }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                return true;
            }
        }
        try
        {
            string current = WindowsName(paths.LocalDirectory);
            if (Mutex.TryOpenExisting("Local\\" + current, out var usual))
            {
                usual.Dispose();
                return true;
            }
            // Read-only compatibility probe for a running build using the older profile-only name.
            if (!Mutex.TryOpenExisting("Local\\" + name, out var legacy)) return false;
            legacy.Dispose();
            return true;
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or IOException or WaitHandleCannotBeOpenedException)
        {
            return true;
        }
    }

    /// <summary>Returns true when another instance accepted the arguments.</summary>
    public static bool TryForward(StartupOptions options)
    {
        if (options.NewInstance)
        {
            RegisterIndependent(options);
            return false;
        }
        var name = BaseName(options.Profile, options.DataRoot);
        if (OperatingSystem.IsWindows())
        {
            var paths = Core.State.AppPaths.Resolve(options.Profile, dataRoot: options.DataRoot);
            name = _windowsName = WindowsName(paths.LocalDirectory);
            _mutex = new Mutex(initiallyOwned: true, "Local\\" + name, out bool created);
            if (created) return false;
        }
        else
        {
            var paths = Core.State.AppPaths.Resolve(options.Profile, dataRoot: options.DataRoot);
            _unixEndpointFile = Path.Combine(paths.LocalDirectory, UnixEndpointFile);
            _unixLock = OpenUnixLock(Path.Combine(paths.LocalDirectory, UnixLockFile), create: true);
            if (_unixLock is not null)
            {
                // Distinct portable/data folders must not bind one socket merely because their profile names match.
                _unixPipeName = BaseName(options.Profile, paths.LocalDirectory);
                return false;
            }
        }
        try
        {
            using var client = OperatingSystem.IsWindows()
                ? new NamedPipeClientStream(".", name, PipeDirection.Out, PipeOptions.CurrentUserOnly)
                : ConnectUnixEndpoint(_unixEndpointFile!);
            if (OperatingSystem.IsWindows()) client.Connect(2000);
            var payload = JsonSerializer.SerializeToUtf8Bytes(options.ToForwardArgs());
            client.Write(payload);
            client.Flush();
            _mutex?.Dispose();
            _mutex = null;
            return true;
        }
        catch (Exception ex) when (ex is TimeoutException or IOException or UnauthorizedAccessException)
        {
            // The owner is not responding (e.g. still starting); run independently rather than lose the request.
            // Without the profile lock, this process never starts a listener or replaces the owner's socket.
            _mutex?.Dispose();
            _mutex = null;
            RegisterIndependent(options);
            return false;
        }
    }

    private static void PublishUnixEndpoint(string file, string pipe)
    {
        string temporary = file + ".tmp-" + Guid.NewGuid().ToString("N");
        try
        {
            using (var output = new FileStream(temporary, new FileStreamOptions
            {
                Mode = FileMode.CreateNew, Access = FileAccess.Write, Share = FileShare.None,
                UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite,
            }))
            {
                output.Write(JsonSerializer.SerializeToUtf8Bytes(new UnixEndpoint(pipe, Path.GetTempPath())));
                output.Flush();
            }
            // Replace the entry, never follow an existing endpoint-file link.
            File.Move(temporary, file, overwrite: true);
        }
        finally
        {
            if (File.Exists(temporary)) File.Delete(temporary);
        }
    }

    public static void StartServer(string? profile, string? dataRoot)
    {
        if (_mutex is null && _unixLock is null) return;
        _cts = new CancellationTokenSource();
        var name = OperatingSystem.IsWindows() ? _windowsName! : _unixPipeName!;
        string? endpointFile = _unixEndpointFile;
        var ct = _cts.Token;
        _serverTask = Task.Run(async () =>
        {
            bool published = false;
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    EnsurePipeDirectory();
                    await using var server = new NamedPipeServerStream(PipeName(name), PipeDirection.In, 1,
                        PipeTransmissionMode.Byte, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
                    if (!OperatingSystem.IsWindows() && !published)
                    {
                        PublishUnixEndpoint(endpointFile!, AbsolutePipeName(name));
                        published = true;
                    }
                    await server.WaitForConnectionAsync(ct);
                    using var ms = new MemoryStream();
                    var buffer = new byte[4096];
                    int n;
                    while ((n = await server.ReadAsync(buffer, ct)) > 0)
                    {
                        ms.Write(buffer, 0, n);
                        if (ms.Length > 256 * 1024) break;
                    }
                    var args = JsonSerializer.Deserialize<string[]>(ms.ToArray()) ?? [];
                    ArgumentsReceived?.Invoke(args);
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
                {
                    await Task.Delay(200, CancellationToken.None);
                }
            }
        }, ct);
    }

    public static void Release()
    {
        _cts?.Cancel();
        // Dispose the old listener before releasing the profile lock, so its unlink cannot remove a new owner's socket.
        try { _serverTask?.GetAwaiter().GetResult(); } catch (OperationCanceledException) { }
        _serverTask = null;
        _cts?.Dispose();
        _cts = null;
        try { _mutex?.ReleaseMutex(); } catch (ApplicationException) { }
        _mutex?.Dispose();
        _mutex = null;
        _windowsName = null;
        _unixLock?.Dispose();
        _unixLock = null;
        _unixEndpointFile = null;
        _unixPipeName = null;
        _independentLock?.Dispose();
        _independentLock = null;
        if (_independentFile is { } file)
        {
            try { File.Delete(file); } catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
            try { File.Delete(Path.ChangeExtension(file, ".json")); } catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
            _independentFile = null;
        }
    }
}
