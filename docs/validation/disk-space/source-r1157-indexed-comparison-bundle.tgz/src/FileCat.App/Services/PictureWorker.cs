using System.Buffers.Binary;
using System.Globalization;
using System.Text;
using PDFtoImage;
using PDFtoImage.Exceptions;
using SkiaSharp;

namespace FileCat.App.Services;

/// <summary>
/// The decoding side of the picture viewer (plan §16.1: "decoder worker; pixel/dimension/memory limits; bounded transfer
/// of decoded output"). FileCat started with <see cref="Argument"/> reads one picture's bytes from standard input and
/// writes it back decoded, turned the way its EXIF orientation says and scaled to fit a given size, or a reason. It never
/// intentionally opens a content file or a window. Native codec loading and process authority follow the platform's
/// worker launch rules in <see cref="PictureDecoder"/>. On Linux and macOS those launch rules establish the filesystem
/// and network boundary before this stream-only entry point consumes input.
/// </summary>
internal static class PictureWorker
{
    public const string Argument = "--picture-worker";
    internal const string PdfArgument = "pdf";
    internal const long MaxPdfInputBytes = 64L * 1024 * 1024;

    /// <summary>Pictures larger than this are not read at all.</summary>
    public const long MaxInputBytes = 256L * 1024 * 1024;

    /// <summary>Nor decoded beyond this many pixels (a 50-megapixel camera stays well inside).</summary>
    public const long MaxSourcePixels = 100_000_000;

    /// <summary>The longest side the decoded output may have.</summary>
    public const int MaxSide = 8192;

    /// <summary>The smallest requested output side accepted by the worker.</summary>
    public const int MinSide = 16;

    internal static ReadOnlySpan<byte> SuccessMagic => "FCPX"u8;
    internal static ReadOnlySpan<byte> FailureMagic => "FCPE"u8;

    /// <summary>The worker's entry point: arguments <see cref="Argument"/> and the longest side wanted.</summary>
    public static int Run(string[] args)
    {
        using var output = Console.OpenStandardOutput();
        try
        {
            using var lifetime = PictureWorkerLifetime.Start();
            // Give up root before a hostile picture is read. Linux already entered its filesystem/network domain in
            // the pre-exec launcher; the process-creation filter below composes with that inherited boundary.
            var identity = FileCat.Core.FileSystem.UnixWorkerIdentity.Drop();
            if (identity.Refusal is { } refusal) return Fail(output, refusal);
            if ((OperatingSystem.IsLinux() || OperatingSystem.IsMacOS()) && !identity.Unprivileged)
                return Fail(output, "The picture worker could not verify that it gave up elevated user and group rights.");
            LinuxPictureProcessPolicy.Apply();
            int maxSide = args.Length > 1 && int.TryParse(args[1], NumberStyles.None, CultureInfo.InvariantCulture, out int wanted) ? Math.Clamp(wanted, MinSide, MaxSide) : 2048;
            bool pdf = args.Length > 2 && args[2] == PdfArgument;
            int page = pdf && args.Length > 3 && int.TryParse(args[3], NumberStyles.None, CultureInfo.InvariantCulture, out int requestedPage)
                ? requestedPage : 0;
            using var input = Console.OpenStandardInput();
            var bytes = ReadAll(input, pdf ? MaxPdfInputBytes : MaxInputBytes);
            if (bytes is null) return Fail(output, $"it is larger than {(pdf ? MaxPdfInputBytes : MaxInputBytes) / (1024 * 1024)} MiB, which is more than FileCat shows");
            if (pdf) DecodePdf(bytes.Value, maxSide, page, output);
            else Decode(bytes.Value, maxSide, output);
            return 0;
        }
        catch (Exception ex) when (ex is InvalidDataException or IOException or ArgumentException or OutOfMemoryException or PdfException)
        {
            return Fail(output, ex.Message);
        }
    }

    private static ArraySegment<byte>? ReadAll(Stream input, long maxInputBytes)
    {
        using var buffer = new MemoryStream();
        var chunk = new byte[1024 * 1024];
        int n;
        while ((n = input.Read(chunk, 0, chunk.Length)) > 0)
        {
            if (buffer.Length + n > maxInputBytes) return null;
            buffer.Write(chunk, 0, n);
        }
        // Keep the bounded buffer itself. ToArray would briefly retain a second full picture copy,
        // just before the native codec allocates its own decoded pixels.
        return new ArraySegment<byte>(buffer.GetBuffer(), 0, checked((int)buffer.Length));
    }

    private static void DecodePdf(ArraySegment<byte> bytes, int maxSide, int page, Stream output)
    {
        if (!bytes.AsSpan().StartsWith("%PDF-"u8)) throw new InvalidDataException("it has no PDF header");
        // Native PDFium parses only in the already restricted worker; no annotation actions, forms or links run.
        using var pdf = new MemoryStream(bytes.Array!, bytes.Offset, bytes.Count, writable: false);
        int count = Conversion.GetPageCount(pdf);
        if (count is < 1 or > 100_000 || page < 0 || page >= count)
            throw new InvalidDataException("the requested PDF page is unavailable");
        using var pageSource = new MemoryStream(bytes.Array!, bytes.Offset, bytes.Count, writable: false);
        var size = Conversion.GetPageSize(pageSource, page: page);
        if (!float.IsFinite(size.Width) || !float.IsFinite(size.Height) || size.Width <= 0 || size.Height <= 0)
            throw new InvalidDataException("the PDF page declares an invalid size");
        double scale = Math.Min(2, maxSide / Math.Max((double)size.Width, size.Height));
        int width = Math.Clamp((int)Math.Round(size.Width * scale), 1, maxSide);
        int height = Math.Clamp((int)Math.Round(size.Height * scale), 1, maxSide);
        using var pageStream = new MemoryStream(bytes.Array!, bytes.Offset, bytes.Count, writable: false);
        using var rendered = Conversion.ToImage(pageStream, page: page,
            options: new RenderOptions(Dpi: 72, Width: width, Height: height,
                WithAnnotations: false, WithFormFill: false));
        using var shown = new SKBitmap(new SKImageInfo(width, height, SKColorType.Bgra8888, SKAlphaType.Premul));
        using (var canvas = new SKCanvas(shown))
        {
            canvas.Clear(SKColors.White);
            canvas.DrawBitmap(rendered, 0, 0);
        }
        string version = bytes.Count >= 8 && bytes.Array![bytes.Offset + 5] is >= (byte)'1' and <= (byte)'2' &&
            bytes.Array[bytes.Offset + 6] == '.' && bytes.Array[bytes.Offset + 7] is >= (byte)'0' and <= (byte)'9'
            ? $"PDF {bytes.Array[bytes.Offset + 5] - '0'}.{bytes.Array[bytes.Offset + 7] - '0'}" : "PDF";
        var format = Encoding.ASCII.GetBytes(version);
        Span<byte> header = stackalloc byte[32];
        SuccessMagic.CopyTo(header);
        BinaryPrimitives.WriteInt32LittleEndian(header[4..], width);
        BinaryPrimitives.WriteInt32LittleEndian(header[8..], height);
        BinaryPrimitives.WriteInt32LittleEndian(header[12..], Math.Max(1, (int)Math.Round(size.Width)));
        BinaryPrimitives.WriteInt32LittleEndian(header[16..], Math.Max(1, (int)Math.Round(size.Height)));
        BinaryPrimitives.WriteInt32LittleEndian(header[20..], count);
        BinaryPrimitives.WriteInt32LittleEndian(header[24..], 0);
        BinaryPrimitives.WriteInt32LittleEndian(header[28..], format.Length);
        output.Write(header);
        output.Write(format);
        var pixels = shown.GetPixelSpan();
        for (int y = 0; y < height; y++) output.Write(pixels.Slice(y * shown.RowBytes, width * 4));
        output.Flush();
    }

    internal static int Fail(Stream output, string reason)
    {
        var text = Encoding.UTF8.GetBytes(reason.Length > 400 ? reason[..400] : reason);
        Span<byte> header = stackalloc byte[8];
        FailureMagic.CopyTo(header);
        BinaryPrimitives.WriteInt32LittleEndian(header[4..], text.Length);
        output.Write(header);
        output.Write(text);
        output.Flush();
        return 2;
    }

    /// <summary>
    /// Decodes <paramref name="bytes"/> and writes: the magic, the output's width and height, the picture's own width and
    /// height (as shown), its frame count, flags (1: the data ended early), its format's name, then premultiplied BGRA
    /// rows without padding.
    /// </summary>
    internal static void Decode(byte[] bytes, int maxSide, Stream output) => Decode(new ArraySegment<byte>(bytes), maxSide, output);

    private static void Decode(ArraySegment<byte> bytes, int maxSide, Stream output)
    {
        using var codec = SKCodec.Create(new MemoryStream(bytes.Array!, bytes.Offset, bytes.Count, writable: false), out var opened)
                          ?? throw new InvalidDataException(opened == SKCodecResult.Unimplemented ? "FileCat does not show this kind of picture" : "it is damaged or not a picture");
        var info = codec.Info;
        if (info.Width <= 0 || info.Height <= 0) throw new InvalidDataException("it declares no size");
        if ((long)info.Width * info.Height > MaxSourcePixels)
            throw new InvalidDataException($"at {info.Width:N0} × {info.Height:N0} pixels it is larger than FileCat shows ({MaxSourcePixels / 1_000_000} megapixels)");
        var origin = codec.EncodedOrigin;
        bool turned = origin is SKEncodedOrigin.LeftTop or SKEncodedOrigin.RightTop or SKEncodedOrigin.RightBottom or SKEncodedOrigin.LeftBottom;
        int shownW = turned ? info.Height : info.Width, shownH = turned ? info.Width : info.Height;
        float scale = Math.Min(1f, (float)maxSide / Math.Max(shownW, shownH));
        // JPEG decodes at 1/2, 1/4, 1/8 directly; the rest is scaled when drawn.
        var decodedSize = codec.GetScaledDimensions(scale);
        // Decoded into sRGB: a picture with its own color profile (Adobe RGB, Display P3) keeps its colors on screen.
        using var srgb = SKColorSpace.CreateSrgb();
        var decodeInfo = new SKImageInfo(decodedSize.Width, decodedSize.Height, SKColorType.Bgra8888, SKAlphaType.Premul, srgb);
        using var decoded = new SKBitmap(decodeInfo);
        var result = codec.GetPixels(decodeInfo, decoded.GetPixels());
        bool incomplete = result is SKCodecResult.IncompleteInput or SKCodecResult.ErrorInInput;
        if (result != SKCodecResult.Success && !incomplete) throw new InvalidDataException($"it could not be decoded ({result})");

        int outW = Math.Clamp((int)Math.Round(shownW * scale), 1, maxSide), outH = Math.Clamp((int)Math.Round(shownH * scale), 1, maxSide);
        using var shown = new SKBitmap(new SKImageInfo(outW, outH, SKColorType.Bgra8888, SKAlphaType.Premul, srgb));
        using (var canvas = new SKCanvas(shown))
        {
            canvas.Clear(SKColors.Transparent);
            canvas.SetMatrix(Orientation(origin, outW, outH));
            using var image = SKImage.FromBitmap(decoded);
            int targetW = turned ? outH : outW, targetH = turned ? outW : outH;
            // Integer rotation/mirroring at the decoded size must keep each pixel, including alpha. Cubic sampling
            // blends neighbors even at 1:1; reserve it for an actual resize after any codec-native downsampling.
            var sampling = decodedSize.Width == targetW && decodedSize.Height == targetH
                ? new SKSamplingOptions(SKFilterMode.Nearest)
                : new SKSamplingOptions(SKCubicResampler.Mitchell);
            canvas.DrawImage(image, new SKRect(0, 0, targetW, targetH), sampling);
        }

        var format = Encoding.ASCII.GetBytes(codec.EncodedFormat.ToString().ToUpperInvariant());
        Span<byte> header = stackalloc byte[32];
        SuccessMagic.CopyTo(header);
        BinaryPrimitives.WriteInt32LittleEndian(header[4..], outW);
        BinaryPrimitives.WriteInt32LittleEndian(header[8..], outH);
        BinaryPrimitives.WriteInt32LittleEndian(header[12..], shownW);
        BinaryPrimitives.WriteInt32LittleEndian(header[16..], shownH);
        BinaryPrimitives.WriteInt32LittleEndian(header[20..], Math.Max(1, codec.FrameCount));
        BinaryPrimitives.WriteInt32LittleEndian(header[24..], incomplete ? 1 : 0);
        BinaryPrimitives.WriteInt32LittleEndian(header[28..], format.Length);
        output.Write(header);
        output.Write(format);
        var pixels = shown.GetPixelSpan();
        int rowBytes = shown.RowBytes, width = outW * 4;
        for (int y = 0; y < outH; y++) output.Write(pixels.Slice(y * rowBytes, width));
        output.Flush();
    }

    /// <summary>The drawing transform that shows a picture stored in <paramref name="origin"/>'s orientation upright.</summary>
    internal static SKMatrix Orientation(SKEncodedOrigin origin, int w, int h) => origin switch
    {
        SKEncodedOrigin.TopRight => new SKMatrix(-1, 0, w, 0, 1, 0, 0, 0, 1),
        SKEncodedOrigin.BottomRight => new SKMatrix(-1, 0, w, 0, -1, h, 0, 0, 1),
        SKEncodedOrigin.BottomLeft => new SKMatrix(1, 0, 0, 0, -1, h, 0, 0, 1),
        SKEncodedOrigin.LeftTop => new SKMatrix(0, 1, 0, 1, 0, 0, 0, 0, 1),
        SKEncodedOrigin.RightTop => new SKMatrix(0, -1, w, 1, 0, 0, 0, 0, 1),
        SKEncodedOrigin.RightBottom => new SKMatrix(0, -1, w, -1, 0, h, 0, 0, 1),
        SKEncodedOrigin.LeftBottom => new SKMatrix(0, 1, 0, -1, 0, h, 0, 0, 1),
        _ => SKMatrix.Identity,
    };
}
