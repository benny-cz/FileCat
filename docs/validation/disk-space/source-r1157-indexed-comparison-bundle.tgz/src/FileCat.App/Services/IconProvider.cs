using System.Collections.Concurrent;
using Avalonia.Media;
using FileCat.Core.Resources;

namespace FileCat.App.Services;

/// <summary>Icon categories used by the vector fallback and by semantic text colors.</summary>
public enum IconKind
{
    Parent,
    Folder,
    File,
    Archive,
    Executable,
    Image,
    Code,
    Document,
    Audio,
    Video,
    Drive,
    NetworkDrive,
    RemovableDrive,
    Server,
    Share,
    RegistryKey,
    RegistryValue,
    /// <summary>This PC.</summary>
    Computer,
    /// <summary>Phones and cameras.</summary>
    Phone,
    /// <summary>Working sets: items collected from many folders.</summary>
    Collection,
    /// <summary>The Network: computers and file servers nearby.</summary>
    Network,
    /// <summary>A stream or attribute beside a file (D-55): not a file of any type, so no type's icon.</summary>
    Stream,
    /// <summary>The Recycle Bin, empty.</summary>
    RecycleBin,
    /// <summary>The Recycle Bin with something in it.</summary>
    RecycleBinFull,
}

/// <summary>
/// Supplies row icons. v1 uses file type and extension only (plan §8.2): native per-extension icons on
/// Windows through <see cref="NativeIconSource"/>, and original vector icons elsewhere.
/// </summary>
public sealed class IconProvider
{
    private static readonly HashSet<string> ArchiveExt = new(StringComparer.OrdinalIgnoreCase) { "zip", "7z", "rar", "tar", "gz", "tgz", "bz2", "xz", "zst", "cab", "iso", "jar", "nupkg", "apk", "aab", "whl" };
    private static readonly HashSet<string> ExecExt = new(StringComparer.OrdinalIgnoreCase) { "exe", "com", "bat", "cmd", "ps1", "msi", "msix", "appx", "sh", "app", "scr", "lnk" };
    private static readonly HashSet<string> ImageExt = new(StringComparer.OrdinalIgnoreCase) { "png", "jpg", "jpeg", "gif", "bmp", "webp", "tif", "tiff", "ico", "svg", "heic", "avif", "raw", "psd" };
    private static readonly HashSet<string> CodeExt = new(StringComparer.OrdinalIgnoreCase) { "cs", "axaml", "xaml", "csproj", "props", "targets", "sln", "slnx", "c", "h", "cpp", "hpp", "rs", "go", "py", "js", "ts", "tsx", "jsx", "java", "kt", "swift", "json", "xml", "yml", "yaml", "toml", "ini", "sql", "css", "scss", "html", "htm", "md", "ps1", "psm1", "lua", "rb", "php", "gradle", "cmake", "mk", "dockerfile" };
    private static readonly HashSet<string> DocExt = new(StringComparer.OrdinalIgnoreCase) { "txt", "log", "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "rtf", "csv", "tsv", "epub" };
    private static readonly HashSet<string> AudioExt = new(StringComparer.OrdinalIgnoreCase) { "mp3", "wav", "flac", "ogg", "m4a", "aac", "wma", "opus" };
    private static readonly HashSet<string> VideoExt = new(StringComparer.OrdinalIgnoreCase) { "mp4", "mkv", "avi", "mov", "wmv", "webm", "m4v", "mpg", "mpeg" };

    private readonly ConcurrentDictionary<(IconKind, string), IImage> _vector = new();
    private readonly ConcurrentDictionary<(GitStatusKind, string), IImage> _gitOverlays = new();
    private readonly ConcurrentDictionary<(Core.Verification.VerificationState, string), IImage?> _verificationOverlays = new();
    private readonly ConcurrentDictionary<(Core.Verification.VerificationState, string), IImage?> _verificationMarks = new();
    private readonly ConcurrentDictionary<(Core.FileSystem.CloudState, string), IImage?> _cloudOverlays = new();

    private INativeIconSource? _native;
    private Action? _loaded;

    /// <summary>Optional native provider (Windows extension icons); returns null to fall back to vectors.</summary>
    public INativeIconSource? Native
    {
        get => _native;
        set
        {
            if (ReferenceEquals(_native, value)) return;
            if (_native is not null && _loaded is not null) _native.IconsLoaded -= OnNativeIconsLoaded;
            _native = value;
            if (_native is not null && _loaded is not null) _native.IconsLoaded += OnNativeIconsLoaded;
        }
    }

    /// <summary>
    /// Raised when the platform's icons asked for meanwhile have arrived (on whichever thread they came on): whatever
    /// shows them draws them again. The platform's source is listened to only while something listens here, so the
    /// provider leaves no listener of its own behind on it.
    /// </summary>
    public event Action? Loaded
    {
        add
        {
            bool first = _loaded is null;
            _loaded += value;
            if (first && _loaded is not null && _native is not null) _native.IconsLoaded += OnNativeIconsLoaded;
        }
        remove
        {
            if (_loaded is null) return;
            _loaded -= value;
            if (_loaded is null && _native is not null) _native.IconsLoaded -= OnNativeIconsLoaded;
        }
    }

    private void OnNativeIconsLoaded() => _loaded?.Invoke();

    public bool UseNativeIcons { get; set; } = true;

    public static IconKind Classify(in EntryData e)
    {
        switch (e.Kind)
        {
            case EntryKind.Parent: return IconKind.Parent;
            case EntryKind.Directory: return IconKind.Folder;
            case EntryKind.Drive:
                return e.Tag is Core.FileSystem.DriveTag t
                    ? t.DriveType switch { "Network" => IconKind.NetworkDrive, "Removable" or "CDRom" => IconKind.RemovableDrive, _ => IconKind.Drive }
                    : IconKind.Drive;
            case EntryKind.Server: return IconKind.Server;
            case EntryKind.Share: return IconKind.Share;
            case EntryKind.RegistryKey: return IconKind.RegistryKey;
            case EntryKind.RegistryValue: return IconKind.RegistryValue;
        }
        if (e.Has(EntryFlags.Container)) return IconKind.Archive;
        var ext = NameParts.GetExtension(e.Name);
        if (ext.Length == 0) return IconKind.File;
        if (ArchiveExt.Contains(ext)) return IconKind.Archive;
        if (ExecExt.Contains(ext)) return IconKind.Executable;
        if (ImageExt.Contains(ext)) return IconKind.Image;
        if (CodeExt.Contains(ext)) return IconKind.Code;
        if (DocExt.Contains(ext)) return IconKind.Document;
        if (AudioExt.Contains(ext)) return IconKind.Audio;
        if (VideoExt.Contains(ext)) return IconKind.Video;
        return IconKind.File;
    }

    /// <param name="folder">Where the entry is listed; lets programs show their own icons through the Shell helper.</param>
    public IImage GetIcon(in EntryData e, Location? folder = null)
    {
        // A stream named like a file ("payload", "x.jpg") is not that kind of file: one icon for them all.
        if (folder?.Scheme == Schemes.HiddenData && e.Kind != EntryKind.Parent) return _vector.GetOrAdd((IconKind.Stream, ThemeManager.Current.Name), k => VectorIcons.Create(k.Item1));
        if (UseNativeIcons && Native is not null && e.Kind is EntryKind.File or EntryKind.Directory or EntryKind.Drive)
        {
            var img = Native.GetIcon(e, folder);
            if (img is not null) return ThemeManager.Current.IconTint is { } tint ? Tinted(img, tint) : img;
        }
        var kind = Classify(e);
        return _vector.GetOrAdd((kind, ThemeManager.Current.Name), k => VectorIcons.Create(k.Item1));
    }

    /// <summary>
    /// A place's icon (This PC, phones, working sets, servers, the Registry, drives): the platform's own where it has
    /// one, as its file manager shows it, otherwise FileCat's.
    /// </summary>
    public IImage GetPlaceIcon(IconKind kind)
    {
        if (UseNativeIcons && Native?.GetPlaceIcon(kind) is { } img) return ThemeManager.Current.IconTint is { } tint ? Tinted(img, tint) : img;
        return _vector.GetOrAdd((kind, ThemeManager.Current.Name), k => VectorIcons.Create(k.Item1));
    }

    /// <summary>
    /// Raised after <see cref="ClearCache"/>: icons may look different now (settings applied, another theme), so whatever
    /// shows them draws them again.
    /// </summary>
    public event Action? Cleared;

    public void ClearCache()
    {
        _vector.Clear();
        _gitOverlays.Clear();
        _verificationOverlays.Clear();
        _verificationMarks.Clear();
        _cloudOverlays.Clear();
        _vectorOverlay = null;
        _tinted = new();
        Cleared?.Invoke();
    }

    private System.Runtime.CompilerServices.ConditionalWeakTable<IImage, IImage> _tinted = new();

    /// <summary>
    /// A theme's one-color version of a native icon (a phosphor screen): each pixel's brightness in the tint's color,
    /// its transparency kept. Made once per icon and theme.
    /// </summary>
    private IImage Tinted(IImage image, string tint)
    {
        var scaled = image as ScaledBitmap;
        if ((scaled?.Pixels ?? image) is not Avalonia.Media.Imaging.WriteableBitmap source) return image;
        return _tinted.GetValue(image, _ =>
        {
            var color = Color.Parse(tint);
            var size = source.PixelSize;
            var result = new Avalonia.Media.Imaging.WriteableBitmap(size, source.Dpi, Avalonia.Platform.PixelFormat.Bgra8888, Avalonia.Platform.AlphaFormat.Premul);
            using var from = source.Lock();
            using var to = result.Lock();
            bool premultiplied = source.AlphaFormat == Avalonia.Platform.AlphaFormat.Premul;
            var row = new byte[size.Width * 4];
            for (int y = 0; y < size.Height; y++)
            {
                System.Runtime.InteropServices.Marshal.Copy(from.Address + y * from.RowBytes, row, 0, row.Length);
                for (int x = 0; x < row.Length; x += 4)
                {
                    int a = row[x + 3];
                    if (a == 0) continue;
                    double b = row[x], g = row[x + 1], r = row[x + 2];
                    if (premultiplied) (b, g, r) = (b * 255 / a, g * 255 / a, r * 255 / a);
                    double light = 0.35 + 0.65 * (0.3 * r + 0.59 * g + 0.11 * b) / 255;
                    row[x] = (byte)(color.B * light * a / 255);
                    row[x + 1] = (byte)(color.G * light * a / 255);
                    row[x + 2] = (byte)(color.R * light * a / 255);
                }
                System.Runtime.InteropServices.Marshal.Copy(row, 0, to.Address + y * to.RowBytes, row.Length);
            }
            return scaled is null ? result : ScaledBitmap.Wrap(result, scaled.PixelsPerUnit);
        });
    }

    /// <summary>The display's scaling where rows are drawn: native icons are made at 16 times this many pixels.</summary>
    public void SetScale(double scaling) => Native?.SetPixelSize((int)Math.Round(16 * Math.Max(1, scaling)));

    /// <summary>Shortcut files, which Explorer marks with its arrow like links.</summary>
    public static bool IsShortcut(in EntryData e) =>
        e.Kind == EntryKind.File && NameParts.GetExtension(e.Name) is var ext &&
        (ext.Equals("lnk", StringComparison.OrdinalIgnoreCase) || ext.Equals("url", StringComparison.OrdinalIgnoreCase));

    private IImage? _vectorOverlay;

    /// <summary>The arrow drawn over links and shortcuts: the platform's where it has one, else FileCat's own.</summary>
    public IImage LinkOverlay => (UseNativeIcons ? Native?.LinkOverlay : null) ?? (_vectorOverlay ??= VectorIcons.LinkOverlay());

    /// <summary>A Git state mark at the lower right of the ordinary icon, large and ringed so it reads over any icon.</summary>
    internal IImage? GitOverlay(GitStatusKind status) => status == GitStatusKind.None ? null
        : _gitOverlays.GetOrAdd((status, ThemeManager.Current.Name), key => VectorIcons.GitOverlay(key.Item1));

    /// <summary>A file's check against the checksums and signatures beside it (D-57), at the upper right of its icon.</summary>
    internal IImage? VerificationOverlay(Core.Verification.VerificationState state) =>
        _verificationOverlays.GetOrAdd((state, ThemeManager.Current.Name), key => VectorIcons.VerificationOverlay(key.Item1));

    /// <summary>The same mark on its own (the results of a check asked for list each file with it).</summary>
    internal IImage? VerificationMark(Core.Verification.VerificationState state) =>
        _verificationMarks.GetOrAdd((state, ThemeManager.Current.Name), key => VectorIcons.VerificationMark(key.Item1));

    /// <summary>A cloud provider's file (online only, on this computer, kept here always), at the upper left of its icon.</summary>
    internal IImage? CloudOverlay(Core.FileSystem.CloudState state) => state == Core.FileSystem.CloudState.None ? null
        : _cloudOverlays.GetOrAdd((state, ThemeManager.Current.Name), key => VectorIcons.CloudOverlay(key.Item1));

    /// <summary>Prefer the installed Windows overlay when available; Git badges remain a portable fallback.</summary>
    internal IImage? ShellOverlayIcon(in EntryData entry, Location? folder, GitStatusKind status)
    {
        if (!UseNativeIcons || Native is not NativeIconSource source ||
            folder is not { IsFileSystem: true } || entry.Kind is not (EntryKind.File or EntryKind.Directory)) return null;
        return source.GetOverlayIcon(Path.Join(folder.Path, entry.Name), entry.Modified, (FileAttributes)entry.Attributes, status);
    }
}

public interface INativeIconSource
{
    /// <summary>Returns a cached icon, or null while it loads or when unavailable. Must not block.</summary>
    IImage? GetIcon(in EntryData entry, Location? folder = null);

    /// <summary>The platform's shortcut arrow drawn over link icons; null to use FileCat's own.</summary>
    IImage? LinkOverlay => null;

    /// <summary>Icons are made for this many device pixels (16 times the display's scaling).</summary>
    void SetPixelSize(int size) { }

    /// <summary>The platform's icon for a place (<see cref="IconProvider.GetPlaceIcon"/>); null while it loads or when there is none.</summary>
    IImage? GetPlaceIcon(IconKind kind) => null;

    event Action? IconsLoaded;
}

/// <summary>Original, simple 16×16 vector icons (plan §18.2: no third-party icon assets needed).</summary>
public static class VectorIcons
{
    private const string FolderPath = "M1,3.5 C1,2.7 1.6,2 2.4,2 L6,2 L7.6,3.6 L13.6,3.6 C14.4,3.6 15,4.3 15,5.1 L15,12.5 C15,13.3 14.4,14 13.6,14 L2.4,14 C1.6,14 1,13.3 1,12.5 Z";
    private const string FilePath = "M3.5,1 L9.5,1 L13,4.5 L13,14.2 C13,14.6 12.6,15 12.2,15 L3.8,15 C3.4,15 3,14.6 3,14.2 L3,1.5 C3,1.2 3.2,1 3.5,1 Z M9.5,1 L9.5,4.5 L13,4.5";
    private const string ParentPath = "M8,2 L13,7.5 L9.8,7.5 L9.8,14 L6.2,14 L6.2,7.5 L3,7.5 Z";
    private const string DrivePath = "M1.5,5 L14.5,5 L14.5,12 L1.5,12 Z M11.5,8.5 m-1,0 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0";
    private const string ServerPath = "M3,1.5 L13,1.5 L13,6.5 L3,6.5 Z M3,8.5 L13,8.5 L13,13.5 L3,13.5 Z";
    private const string KeyPath = "M1,4 L6,4 L7,5 L15,5 L15,13 L1,13 Z";
    private const string ComputerPath = "M1.5,2.5 L14.5,2.5 L14.5,11 L1.5,11 Z";
    private const string PhonePath = "M5,1.5 L11,1.5 C11.6,1.5 12,1.9 12,2.5 L12,13.5 C12,14.1 11.6,14.5 11,14.5 L5,14.5 C4.4,14.5 4,14.1 4,13.5 L4,2.5 C4,1.9 4.4,1.5 5,1.5 Z";
    private const string CollectionPath = "M2.5,4.5 L10,4.5 L10,14.5 L2.5,14.5 Z";
    private const string NetworkPath = "M1.5,1.5 L7.5,1.5 L7.5,6 L1.5,6 Z M8.5,9 L14.5,9 L14.5,13.5 L8.5,13.5 Z";
    private const string BinPath = "M3.5,4.5 L12.5,4.5 L11.5,14.5 L4.5,14.5 Z";

    public static IImage Create(IconKind kind)
    {
        var (path, colorKey, overlay) = kind switch
        {
            IconKind.Parent => (ParentPath, "FcTextMuted", (string?)null),
            IconKind.Folder => (FolderPath, "FcFolderIcon", null),
            IconKind.Archive => (FilePath, "FcArchiveIcon", "M6,5 L7,5 M7,6 L8,6 M6,7 L7,7 M7,8 L8,8 M6,9 L7,9 M6,10.5 L8,10.5 L8,12.5 L6,12.5 Z"),
            IconKind.Executable => (FilePath, "FcExecIcon", "M5.5,8 L7.5,10 L5.5,12 M8.5,12 L10.5,12"),
            IconKind.Image => (FilePath, "FcImageIcon", "M5,12.5 L7,9.5 L8.5,11.2 L9.5,10 L11,12.5 Z"),
            IconKind.Code => (FilePath, "FcCodeIcon", "M6.5,8 L5,10 L6.5,12 M9.5,8 L11,10 L9.5,12"),
            IconKind.Document => (FilePath, "FcFileIcon", "M5,7 L11,7 M5,9 L11,9 M5,11 L9,11"),
            IconKind.Audio => (FilePath, "FcImageIcon", "M7,12 L7,7.5 L10.5,6.8 L10.5,11.2"),
            IconKind.Video => (FilePath, "FcCodeIcon", "M6.5,8 L6.5,12 L10.5,10 Z"),
            IconKind.Drive or IconKind.RemovableDrive => (DrivePath, "FcDriveIcon", null),
            IconKind.NetworkDrive => (DrivePath, "FcDriveIcon", "M8,12 L8,14.5 M5,14.5 L11,14.5"),
            IconKind.Server or IconKind.Share => (ServerPath, "FcDriveIcon", null),
            IconKind.RegistryKey => (KeyPath, "FcFolderIcon", null),
            IconKind.RegistryValue => (FilePath, "FcCodeIcon", "M5.5,7 L10.5,7 M5.5,9.5 L10.5,9.5 M5.5,12 L8.5,12"),
            IconKind.Computer => (ComputerPath, "FcDriveIcon", "M8,11 L8,13.5 M5,13.5 L11,13.5"),
            IconKind.Phone => (PhonePath, "FcDriveIcon", "M7,12.5 L9,12.5"),
            IconKind.Collection => (CollectionPath, "FcFileIcon", "M5,4.5 L5,2 L12.5,2 L12.5,12 L10,12 M4.5,8 L8,8 M4.5,10.5 L8,10.5"),
            IconKind.Network => (NetworkPath, "FcDriveIcon", "M4.5,6 L4.5,11.25 L8.5,11.25 M2.5,14.5 L6.5,14.5"),
            IconKind.Stream => (FilePath, "FcCodeIcon", "M5.5,7 L10.5,7 M5.5,9.5 L10.5,9.5 M5.5,12 L8,12 M1,9.5 L3,9.5"),
            IconKind.RecycleBin => (BinPath, "FcDriveIcon", "M2,3 L14,3 M6.5,3 L6.5,1.5 L9.5,1.5 L9.5,3 M6.5,7 L6.5,12 M9.5,7 L9.5,12"),
            IconKind.RecycleBinFull => (BinPath, "FcDriveIcon", "M2,3 L14,3 M6.5,3 L6.5,1.5 L9.5,1.5 L9.5,3 M5.5,8 L10.5,8 M5.5,10 L10.5,10 M5.5,12 L10.5,12"),
            _ => (FilePath, "FcFileIcon", null),
        };
        var color = Resolve(colorKey);
        var group = new DrawingGroup();
        var fill = new SolidColorBrush(color, kind is IconKind.Folder or IconKind.Parent or IconKind.RegistryKey ? 1.0 : 0.16);
        var stroke = new Pen(new SolidColorBrush(color), 1.1, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round);
        group.Children.Add(new GeometryDrawing
        {
            Geometry = Geometry.Parse(path),
            Brush = fill,
            Pen = kind is IconKind.Folder or IconKind.Parent or IconKind.RegistryKey ? null : stroke,
        });
        if (overlay is not null)
        {
            group.Children.Add(new GeometryDrawing
            {
                Geometry = Geometry.Parse(overlay),
                Pen = new Pen(new SolidColorBrush(color), 1.1, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round),
                Brush = kind == IconKind.Image || kind == IconKind.Video ? new SolidColorBrush(color) : null,
            });
        }
        // Fix the drawing bounds to the 16×16 box so all icons align.
        group.Children.Insert(0, new GeometryDrawing { Geometry = new RectangleGeometry(new Avalonia.Rect(0, 0, 16, 16)), Brush = Brushes.Transparent });
        return new DrawingImage(group);
    }

    public static IImage LinkOverlay()
    {
        var color = Resolve("FcTextLink");
        var g = new DrawingGroup();
        g.Children.Add(new GeometryDrawing { Geometry = new RectangleGeometry(new Avalonia.Rect(0, 0, 16, 16)), Brush = Brushes.Transparent });
        g.Children.Add(new GeometryDrawing
        {
            Geometry = Geometry.Parse("M0.5,9.5 L6.5,9.5 L6.5,15.5 L0.5,15.5 Z"),
            Brush = new SolidColorBrush(Resolve("FcPanel")),
            Pen = new Pen(new SolidColorBrush(color), 1),
        });
        g.Children.Add(new GeometryDrawing
        {
            Geometry = Geometry.Parse("M2,14 L5,11 M3,11 L5,11 L5,13"),
            Pen = new Pen(new SolidColorBrush(color), 1.1, lineCap: PenLineCap.Round),
        });
        return new DrawingImage(g);
    }

    internal static IImage GitOverlay(GitStatusKind status)
    {
        var palette = ThemeManager.Current;
        var fill = Color.Parse(status switch
        {
            GitStatusKind.Clean => palette.Success,
            GitStatusKind.Modified => palette.Warning,
            GitStatusKind.Added => palette.Progress,
            GitStatusKind.Untracked => palette.TextLink,
            GitStatusKind.Conflict => palette.Error,
            _ => palette.TextMuted,
        });
        // Around (10.8, 10.8): a disc of 8.4 pixels in a ring of the window's color, most of the icon's lower right.
        string mark = status switch
        {
            GitStatusKind.Clean => "M8.9,10.9 L10.3,12.4 L12.8,9.4",
            GitStatusKind.Modified => "M10.8,8.5 L10.8,11.2 M10.8,13.0 L10.8,13.1",
            GitStatusKind.Added => "M10.8,8.6 L10.8,13.0 M8.6,10.8 L13.0,10.8",
            GitStatusKind.Untracked => "M9.5,9.6 C9.5,8.1 12.1,8.1 12.1,9.6 C12.1,10.4 10.8,10.6 10.8,11.5 M10.8,13.0 L10.8,13.1",
            _ => "M9.3,9.3 L12.3,12.3 M12.3,9.3 L9.3,12.3",
        };
        // The glyph in white or near black, whichever reads on the fill (a yellow warning takes black).
        double luminance = (0.2126 * fill.R + 0.7152 * fill.G + 0.0722 * fill.B) / 255;
        var ink = luminance > 0.55 ? Color.FromRgb(0x1C, 0x1C, 0x1C) : Colors.White;
        var g = new DrawingGroup();
        g.Children.Add(new GeometryDrawing { Geometry = new RectangleGeometry(new Avalonia.Rect(0, 0, 16, 16)), Brush = Brushes.Transparent });
        g.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(5.6, 5.6, 10.4, 10.4)), Brush = new SolidColorBrush(Color.Parse(palette.Window)) });
        g.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(6.6, 6.6, 8.4, 8.4)), Brush = new SolidColorBrush(fill) });
        g.Children.Add(new GeometryDrawing
        {
            Geometry = Geometry.Parse(mark),
            Pen = new Pen(new SolidColorBrush(ink), 1.5, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round),
        });
        return new DrawingImage(g);
    }

    /// <summary>
    /// A file's check against the checksums and signatures beside it (D-57), ringed like Git's mark but at the upper right
    /// (Git's takes the lower right, a link's arrow the lower left): a shield with a tick when a trusted key signed it
    /// (authentic), a tick when it matches its checksums (intact), a cross when it differs or a signature is bad, a
    /// question mark when a signature could not vouch for it, an exclamation mark when it could not be read, three dots
    /// when it is not checked yet. Sidecars' own rows get none.
    /// </summary>
    /// <summary>
    /// A cloud provider's file as Explorer tells it, ringed like the other marks at the one free corner, the upper left
    /// (Git's takes the lower right, a link's arrow the lower left, a checksum's the upper right): a cloud outline when it
    /// is only in the cloud, a ringed tick when it is on this computer, a filled tick when it is kept here always.
    /// </summary>
    internal static IImage? CloudOverlay(Core.FileSystem.CloudState state)
    {
        if (state == Core.FileSystem.CloudState.None) return null;
        var palette = ThemeManager.Current;
        var window = new SolidColorBrush(Color.Parse(palette.Window));
        var g = new DrawingGroup();
        g.Children.Add(new GeometryDrawing { Geometry = new RectangleGeometry(new Avalonia.Rect(0, 0, 16, 16)), Brush = Brushes.Transparent });
        g.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(0, 0, 10.4, 10.4)), Brush = window });
        const string tick = "M3.3,5.3 L4.7,6.8 L7.2,3.8";
        switch (state)
        {
            case Core.FileSystem.CloudState.OnlineOnly:
            {
                var ink = new SolidColorBrush(Color.Parse(palette.TextLink));
                var cloud = Geometry.Parse("M3.4,7.0 L7.2,7.0 C8.0,7.0 8.5,6.4 8.4,5.7 C8.3,5.1 7.8,4.8 7.3,4.8 C7.2,3.8 6.4,3.2 5.5,3.2 C4.7,3.2 4.0,3.7 3.8,4.4 C3.0,4.4 2.3,5.0 2.3,5.7 C2.3,6.4 2.8,7.0 3.4,7.0 Z");
                g.Children.Add(new GeometryDrawing { Geometry = cloud, Pen = new Pen(ink, 1.1, lineJoin: PenLineJoin.Round) });
                break;
            }
            case Core.FileSystem.CloudState.Available:
            {
                var green = new SolidColorBrush(Color.Parse(palette.Success));
                g.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(1.4, 1.4, 7.6, 7.6)), Pen = new Pen(green, 1.2) });
                g.Children.Add(new GeometryDrawing { Geometry = Geometry.Parse(tick), Pen = new Pen(green, 1.4, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round) });
                break;
            }
            default:
            {
                var fill = Color.Parse(palette.Success);
                double luminance = (0.2126 * fill.R + 0.7152 * fill.G + 0.0722 * fill.B) / 255;
                var ink = luminance > 0.55 ? Color.FromRgb(0x1C, 0x1C, 0x1C) : Colors.White;
                g.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(1.0, 1.0, 8.4, 8.4)), Brush = new SolidColorBrush(fill) });
                g.Children.Add(new GeometryDrawing { Geometry = Geometry.Parse(tick), Pen = new Pen(new SolidColorBrush(ink), 1.5, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round) });
                break;
            }
        }
        return new DrawingImage(g);
    }

    internal static IImage? VerificationOverlay(Core.Verification.VerificationState state) => VerificationDrawing(state, centered: false);

    /// <summary>The same mark on its own, centered: the results of a check asked for show it beside each file's name.</summary>
    internal static IImage? VerificationMark(Core.Verification.VerificationState state) => VerificationDrawing(state, centered: true);

    private static IImage? VerificationDrawing(Core.Verification.VerificationState state, bool centered)
    {
        var palette = ThemeManager.Current;
        (string? color, string mark) = state switch
        {
            Core.Verification.VerificationState.Matches or Core.Verification.VerificationState.SignatureGood => (palette.Success, "M8.9,5.3 L10.3,6.8 L12.8,3.8"),
            Core.Verification.VerificationState.Differs or Core.Verification.VerificationState.SignatureBad => (palette.Error, "M9.3,3.7 L12.3,6.7 M12.3,3.7 L9.3,6.7"),
            Core.Verification.VerificationState.SignatureUnknownKey or Core.Verification.VerificationState.SignatureUnchecked =>
                (palette.Warning, "M9.5,4.0 C9.5,2.5 12.1,2.5 12.1,4.0 C12.1,4.8 10.8,5.0 10.8,5.9 M10.8,7.4 L10.8,7.5"),
            Core.Verification.VerificationState.Unreadable => (palette.Warning, "M10.8,2.9 L10.8,5.6 M10.8,7.4 L10.8,7.5"),
            Core.Verification.VerificationState.NotChecked => (palette.Progress, "M8.5,5.2 L8.6,5.2 M10.8,5.2 L10.9,5.2 M13.0,5.2 L13.1,5.2"),
            _ => (null, ""),
        };
        if (color is null) return null;
        var fill = Color.Parse(color);
        double luminance = (0.2126 * fill.R + 0.7152 * fill.G + 0.0722 * fill.B) / 255;
        var ink = luminance > 0.55 ? Color.FromRgb(0x1C, 0x1C, 0x1C) : Colors.White;
        var g = new DrawingGroup();
        g.Children.Add(new GeometryDrawing { Geometry = new RectangleGeometry(new Avalonia.Rect(0, 0, 16, 16)), Brush = Brushes.Transparent });
        // Drawn at the icon's upper right; on its own, moved to the middle of the same 16 by 16.
        var shapes = new DrawingGroup { Transform = centered ? new TranslateTransform(-2.8, 2.8) : null };
        if (state == Core.Verification.VerificationState.SignatureGood)
        {
            // Authentic: a shield, ringed in the window's color like the discs.
            var shield = Geometry.Parse("M10.8,0.9 L14.6,2.3 L14.6,5.0 C14.6,7.5 13.0,9.1 10.8,9.9 C8.6,9.1 7.0,7.5 7.0,5.0 L7.0,2.3 Z");
            shapes.Children.Add(new GeometryDrawing { Geometry = shield, Pen = new Pen(new SolidColorBrush(Color.Parse(palette.Window)), 2.0, lineJoin: PenLineJoin.Round) });
            shapes.Children.Add(new GeometryDrawing { Geometry = shield, Brush = new SolidColorBrush(fill) });
        }
        else
        {
            shapes.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(5.6, 0, 10.4, 10.4)), Brush = new SolidColorBrush(Color.Parse(palette.Window)) });
            shapes.Children.Add(new GeometryDrawing { Geometry = new EllipseGeometry(new Avalonia.Rect(6.6, 1.0, 8.4, 8.4)), Brush = new SolidColorBrush(fill) });
        }
        shapes.Children.Add(new GeometryDrawing
        {
            Geometry = Geometry.Parse(mark),
            Pen = new Pen(new SolidColorBrush(ink), 1.5, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round),
        });
        g.Children.Add(shapes);
        return new DrawingImage(g);
    }

    private static Color Resolve(string key)
    {
        if (Avalonia.Application.Current?.TryGetResource(key + "Color", null, out var v) == true && v is Color c) return c;
        return Colors.Gray;
    }
}
