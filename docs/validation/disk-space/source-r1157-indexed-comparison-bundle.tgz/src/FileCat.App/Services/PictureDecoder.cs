using System.Buffers.Binary;
using System.Diagnostics;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;
using Avalonia;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using FileCat.Core.Content;
using FileCat.Core.Resources;
using FileCat.Core.Threading;

namespace FileCat.App.Services;

/// <summary>A picture decoded for showing: upright, scaled to fit, with what the file says about itself.</summary>
/// <param name="Width">The picture's own width in pixels, as shown (after its EXIF orientation).</param>
/// <param name="Frames">More than one for an animation (the first frame is shown).</param>
/// <param name="Incomplete">The data ended before the picture did: the rest is blank.</param>
public sealed record DecodedPicture(WriteableBitmap Bitmap, int Width, int Height, string Format, int Frames, bool Incomplete);

/// <summary>
/// Pictures for the viewer, decoded by <see cref="PictureWorker"/> in a process of its own: one per picture, fed the bytes
/// through standard input and read back within bounds, and stopped after <see cref="Timeout"/>. On Windows the worker
/// normally starts with low integrity and a job that caps its memory and child count. A failed low-integrity start
/// can fall back only under a positively queried process token at most medium integrity; other parents refuse.
/// On Unix it verifies an ordinary identity and irreversibly gives up retained root rights before consuming input.
/// Linux x64 and ARM64 enter a Landlock read allowlist and a seccomp network boundary before the worker runtime starts,
/// then restrict direct process creation on every worker thread. macOS applies an OS policy that denies unlisted file
/// reads, file writes, process creation and network access. Unix workers have no whole-process memory limit. The Unix
/// decoder itself also ends when its launching parent dies.
/// A decoder crash is reported to the viewer; process separation alone does not restrict that authority.
/// At most four workers run together; up to 32 other pictures can wait without starting a process or reading content.
/// </summary>
public static class PictureDecoder
{
    public static readonly TimeSpan Timeout = TimeSpan.FromSeconds(30);
    private const long MemoryLimit = 1536L * 1024 * 1024;
    private static readonly PictureDecoderAdmission Admission = new();

    /// <summary>What a picture's first bytes say it is, for formats the worker decodes; null otherwise.</summary>
    public static string? Recognize(ReadOnlySpan<byte> head)
    {
        if (head.StartsWith((ReadOnlySpan<byte>)[0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])) return "PNG";
        if (head.StartsWith((ReadOnlySpan<byte>)[0xFF, 0xD8, 0xFF])) return "JPEG";
        if (head.StartsWith("GIF87a"u8) || head.StartsWith("GIF89a"u8)) return "GIF";
        if (head.Length >= 12 && head.StartsWith("RIFF"u8) && head[8..12].SequenceEqual("WEBP"u8)) return "WEBP";
        if (head.Length >= 18 && head.StartsWith("BM"u8) && BinaryPrimitives.ReadUInt32LittleEndian(head[14..]) is 12 or 40 or 52 or 56 or 64 or 108 or 124) return "BMP";
        if (head.Length >= 6 && head[0] == 0 && head[1] == 0 && head[2] is 1 or 2 && head[3] == 0 && head[4] + head[5] > 0) return "ICO";
        return null;
    }

    /// <summary>Decodes borrowed content; completion includes the feeder's last source call, even after cancellation.</summary>
    public static Task<DecodedPicture> DecodeAsync(IContentSource source, int maxSide, CancellationToken ct) =>
        DecodeAsync(source.Length, (input, token) => Task.Run(() => Feed(source, input, token), CancellationToken.None), maxSide, ct, drainFeed: true);

    /// <summary>
    /// Decodes for a view. Cancellation can finish its UI demand while a synchronous source read is still held;
    /// the reader keeps that source alive until the actual feeder returns. Source calls share the provider's device
    /// workers; canceled queued work never borrows or reads the source.
    /// </summary>
    public static Task<DecodedPicture> DecodeAsync(PagedReader reader, DeviceIoScheduler io, string deviceKey,
        int maxSide, CancellationToken ct) =>
        DecodeAsync(reader.Length, (input, token) => io.Run(deviceKey, IoPriority.Interactive, canceled =>
        {
            canceled.ThrowIfCancellationRequested();
            reader.WithSource(source => Feed(source, input, canceled));
        }, token), maxSide, ct, drainFeed: false);

    /// <summary>Renders one PDF page inside the same restricted worker boundary as pictures.</summary>
    public static Task<DecodedPicture> DecodePdfAsync(PagedReader reader, DeviceIoScheduler io, string deviceKey,
        int page, int maxSide, CancellationToken ct) =>
        DecodeAsync(reader.Length, (input, token) => io.Run(deviceKey, IoPriority.Interactive, canceled =>
        {
            canceled.ThrowIfCancellationRequested();
            reader.WithSource(source => Feed(source, input, canceled));
        }, token), maxSide, ct, drainFeed: false, pdfPage: page);

    private static async Task<DecodedPicture> DecodeAsync(long length, Func<Stream, CancellationToken, Task> feed,
        int maxSide, CancellationToken ct, bool drainFeed, int? pdfPage = null)
    {
        ct.ThrowIfCancellationRequested();
        maxSide = Math.Clamp(maxSide, PictureWorker.MinSide, PictureWorker.MaxSide);
        long maxInput = pdfPage is null ? PictureWorker.MaxInputBytes : PictureWorker.MaxPdfInputBytes;
        if (length > maxInput)
            throw new InvalidDataException($"at {Formatters.SizeWithUnit(length)} it is larger than FileCat shows as a {(pdfPage is null ? "picture" : "PDF")}");
        using var admission = await Admission.EnterAsync(ct).ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(ct);
        limit.CancelAfter(Timeout);
        var token = limit.Token;
        var launch = WorkerLaunchFor(maxSide, pdfPage);
        await using var worker = Worker.StartPicture(launch);
        using var stop = token.Register(worker.Kill);
        // Written and read at once: the worker may stop reading early (a damaged file), and a full pipe must not block.
        var input = worker.Input;
        var feeding = feed(input, token);
        DecodedPicture? picture = null;
        try
        {
            picture = await Task.Run(() => Read(worker.Output, maxSide), CancellationToken.None).ConfigureAwait(false);
            try { await feeding.ConfigureAwait(false); }
            catch (IOException) { } // the worker had what it needed
            token.ThrowIfCancellationRequested();
            var result = picture;
            picture = null; // ownership moves to the caller only on success
            return result;
        }
        catch (Exception) when (limit.IsCancellationRequested && !ct.IsCancellationRequested)
        {
            throw new TimeoutException($"decoding it took longer than {Timeout.TotalSeconds:0} seconds");
        }
        catch (Exception) when (ct.IsCancellationRequested)
        {
            throw new OperationCanceledException(ct);
        }
        finally
        {
            picture?.Bitmap.Dispose();
            limit.Cancel(); // no more source calls after a worker failure, either
            var drained = ObserveFeedAsync(feeding);
            if (drainFeed) await drained.ConfigureAwait(false);
        }
    }

    private static async Task ObserveFeedAsync(Task feeding)
    {
        try { await feeding.ConfigureAwait(false); }
        catch (Exception) { } // already reported by the decode task, or abandoned after cancellation/worker failure
    }

    private static void Feed(IContentSource source, Stream input, CancellationToken ct)
    {
        try
        {
            var buffer = new byte[1024 * 1024];
            for (long offset = 0; offset < source.Length;)
            {
                ct.ThrowIfCancellationRequested();
                int n = source.Read(offset, buffer);
                ct.ThrowIfCancellationRequested();
                if (n <= 0) break;
                input.Write(buffer, 0, n);
                offset += n;
            }
        }
        finally
        {
            input.Dispose(); // the end of the picture
        }
    }

    /// <summary>The worker's answer, checked field by field: a reason, or the pixels of a picture no larger than asked.</summary>
    internal static DecodedPicture Read(Stream output, int maxSide)
    {
        maxSide = Math.Clamp(maxSide, PictureWorker.MinSide, PictureWorker.MaxSide);
        Span<byte> magic = stackalloc byte[4];
        if (!ReadFully(output, magic)) throw new InvalidDataException(Died);
        if (magic.SequenceEqual(PictureWorker.FailureMagic))
        {
            Span<byte> length = stackalloc byte[4];
            if (!ReadFully(output, length)) throw new InvalidDataException(Died);
            int n = BinaryPrimitives.ReadInt32LittleEndian(length);
            if (n is < 0 or > 4096) throw new InvalidDataException(Garbled);
            var text = new byte[n];
            if (!ReadFully(output, text)) throw new InvalidDataException(Died);
            throw new InvalidDataException(Encoding.UTF8.GetString(text));
        }
        if (!magic.SequenceEqual(PictureWorker.SuccessMagic)) throw new InvalidDataException(Garbled);
        Span<byte> header = stackalloc byte[28];
        if (!ReadFully(output, header)) throw new InvalidDataException(Died);
        int width = BinaryPrimitives.ReadInt32LittleEndian(header), height = BinaryPrimitives.ReadInt32LittleEndian(header[4..]);
        int sourceWidth = BinaryPrimitives.ReadInt32LittleEndian(header[8..]), sourceHeight = BinaryPrimitives.ReadInt32LittleEndian(header[12..]);
        int frames = BinaryPrimitives.ReadInt32LittleEndian(header[16..]), flags = BinaryPrimitives.ReadInt32LittleEndian(header[20..]);
        int formatLength = BinaryPrimitives.ReadInt32LittleEndian(header[24..]);
        if (width < 1 || height < 1 || width > maxSide || height > maxSide || sourceWidth < 1 || sourceHeight < 1 || frames < 1 || formatLength is < 0 or > 32)
            throw new InvalidDataException(Garbled);
        var format = new byte[formatLength];
        if (!ReadFully(output, format)) throw new InvalidDataException(Died);
        var bitmap = new WriteableBitmap(new PixelSize(width, height), new Vector(96, 96), PixelFormat.Bgra8888, AlphaFormat.Premul);
        try
        {
            var row = new byte[width * 4];
            using (var target = bitmap.Lock())
            {
                for (int y = 0; y < height; y++)
                {
                    if (!ReadFully(output, row)) throw new InvalidDataException(Died);
                    Marshal.Copy(row, 0, target.Address + y * target.RowBytes, row.Length);
                }
            }
            return new DecodedPicture(bitmap, sourceWidth, sourceHeight, Encoding.ASCII.GetString(format), frames, (flags & 1) != 0);
        }
        catch
        {
            bitmap.Dispose();
            throw;
        }
    }

    private const string Died = "the decoder stopped part way: the picture is damaged, or needs more memory than FileCat allows a picture";
    private const string Garbled = "the decoder answered something FileCat does not accept";

    private static bool ReadFully(Stream stream, Span<byte> buffer)
    {
        try
        {
            stream.ReadExactly(buffer);
            return true;
        }
        catch (EndOfStreamException)
        {
            return false;
        }
    }

    /// <summary>
    /// FileCat itself, in worker mode: the app host next to FileCat.dll, the running file when FileCat is one file, or
    /// the dotnet host with the dll.
    /// </summary>
    private sealed record WorkerLaunch(string Executable, string Arguments, string[] ArgumentList);

    internal static (string Executable, string Arguments) WorkerCommand(int maxSide)
    {
        var launch = WorkerLaunchFor(maxSide);
        return (launch.Executable, launch.Arguments);
    }

    internal static ProcessStartInfo SandboxedWorkerStartInfo(int maxSide)
    {
        var launch = WorkerLaunchFor(maxSide);
        return LinuxPictureSandbox.StartInfo(launch.Executable, launch.ArgumentList,
            launch.Executable, launch.ArgumentList);
    }

    internal static ProcessStartInfo SandboxedProbeStartInfo(string executable, IReadOnlyList<string> arguments)
    {
        var helper = WorkerLaunchFor(PictureWorker.MinSide);
        return LinuxPictureSandbox.StartInfo(helper.Executable, helper.ArgumentList, executable, arguments);
    }

    private static WorkerLaunch WorkerLaunchFor(int maxSide, int? pdfPage = null)
    {
        string arguments = $"{PictureWorker.Argument} {maxSide}" +
            (pdfPage is { } page ? $" {PictureWorker.PdfArgument} {page}" : string.Empty);
        string[] argumentList = pdfPage is { } requested
            ? [PictureWorker.Argument, maxSide.ToString(System.Globalization.CultureInfo.InvariantCulture),
                PictureWorker.PdfArgument, requested.ToString(System.Globalization.CultureInfo.InvariantCulture)]
            : [PictureWorker.Argument, maxSide.ToString(System.Globalization.CultureInfo.InvariantCulture)];
        string dll = typeof(PictureWorker).Assembly.Location;
        string? process = Environment.ProcessPath;
        if (dll.Length == 0 && process is not null) return new(process, arguments, argumentList);
        string host = Path.Combine(Path.GetDirectoryName(dll)!, OperatingSystem.IsWindows() ? "FileCat.exe" : "FileCat");
        if (File.Exists(host)) return new(host, arguments, argumentList);
        // Reuse the runtime already loaded by this process. An absolute PATH entry can still be writable.
        string dotnet = LoadedRuntimeHost.Current() ?? throw new InvalidOperationException("The .NET runtime could not be found for the picture worker.");
        return new(dotnet, $"\"{dll}\" {arguments}", [dll, .. argumentList]);
    }

    /// <summary>The decoder process: Windows token/job restrictions, inherited process authority on Unix.</summary>
    private sealed class Worker : IAsyncDisposable
    {
        private readonly Platform.Windows.Shell.SandboxedWorker? _sandboxed;
        private readonly Process? _process;
        private readonly Task? _stderrDrain;
        private readonly CancellationTokenSource? _stderrCancel;
        private AnonymousPipeServerStream? _lifetime;

        private Worker(Platform.Windows.Shell.SandboxedWorker? sandboxed, Process? process,
            AnonymousPipeServerStream? lifetime = null, Task? stderrDrain = null, CancellationTokenSource? stderrCancel = null)
        {
            _sandboxed = sandboxed;
            _process = process;
            _lifetime = lifetime;
            _stderrDrain = stderrDrain;
            _stderrCancel = stderrCancel;
        }

        public Stream Input => _sandboxed?.Input ?? _process!.StandardInput.BaseStream;
        public Stream Output => _sandboxed?.Output ?? _process!.StandardOutput.BaseStream;

        public static Worker StartPicture(WorkerLaunch launch)
        {
            if (OperatingSystem.IsWindows())
                return new Worker(Platform.Windows.Shell.SandboxedWorker.Start(launch.Executable, launch.Arguments, MemoryLimit), null);
            ProcessStartInfo psi = OperatingSystem.IsMacOS()
                ? MacPictureSandbox.StartInfo(launch.Executable, launch.ArgumentList)
                : OperatingSystem.IsLinux()
                    ? LinuxPictureSandbox.StartInfo(launch.Executable, launch.ArgumentList, launch.Executable, launch.ArgumentList)
                    : StartInfo(launch.Executable, launch.ArgumentList);
            return StartUnix(psi);
        }

        public static Worker Start(string executable, string arguments)
        {
            if (OperatingSystem.IsWindows())
                return new Worker(Platform.Windows.Shell.SandboxedWorker.Start(executable, arguments, MemoryLimit), null);
            var psi = new ProcessStartInfo(executable, arguments)
            {
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            return StartUnix(psi);
        }

        private static ProcessStartInfo StartInfo(string executable, IReadOnlyList<string> arguments)
        {
            var psi = new ProcessStartInfo(executable)
            {
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            foreach (string argument in arguments) psi.ArgumentList.Add(argument);
            return psi;
        }

        private static Worker StartUnix(ProcessStartInfo psi)
        {
            // The decoder parses untrusted bytes and needs no parent environment variables. In particular, do not
            // copy credentials or native-library search overrides into it. Supply only its private lifetime channel
            // and the diagnostic-port refusal; neither changes its inherited Unix UID or filesystem/network rights.
            psi.Environment.Clear();
            psi.Environment["DOTNET_EnableDiagnostics"] = "0";
            // Framework-dependent apphosts need the root of the runtime already loaded by this process.
            // GitHub's setup-dotnet installs outside the OS default; copying the parent's DOTNET_ROOT
            // would reintroduce an attacker-controlled loader override into the decoder.
            if (OperatingSystem.IsLinux()) psi.Environment["DOTNET_ROOT"] = LinuxPictureSandbox.RuntimeRoot();
            else
            {
                var runtimeDirectory = new DirectoryInfo(RuntimeEnvironment.GetRuntimeDirectory());
                var framework = runtimeDirectory.Parent;
                var shared = framework?.Parent;
                var root = shared?.Parent;
                if (framework?.Name == "Microsoft.NETCore.App" && shared?.Name == "shared" && root is not null &&
                    File.Exists(Path.Combine(root.FullName, "dotnet")))
                    psi.Environment["DOTNET_ROOT"] = root.FullName;
            }
            var lifetime = new AnonymousPipeServerStream(PipeDirection.Out, HandleInheritability.Inheritable);
            Process? process = null;
            try
            {
                // A separate channel covers parent death even if another owner still holds encoded stdin open.
                // Overwrite any inherited value so this worker belongs to this exact launch.
                psi.Environment[PictureWorkerLifetime.EnvironmentName] = lifetime.GetClientHandleAsString();
                process = Process.Start(psi) ?? throw new InvalidOperationException("The picture decoder could not be started.");
                lifetime.DisposeLocalCopyOfClientHandle();
                // DataReceived buffers a complete line before invoking its callback. A worker that
                // writes stderr without newlines can therefore grow the parent without a bound.
                var stderrCancel = new CancellationTokenSource();
                Task stderrDrain = DrainStderrAsync(process.StandardError.BaseStream, stderrCancel.Token);
                return new Worker(null, process, lifetime, stderrDrain, stderrCancel);
            }
            catch
            {
                try { if (process is { HasExited: false }) process.Kill(entireProcessTree: true); }
                catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception) { }
                finally { lifetime.Dispose(); }
                if (process is not null)
                {
                    try { process.WaitForExit(5000); }
                    finally { process.Dispose(); }
                }
                throw;
            }
        }

        public void Kill()
        {
            try
            {
                _sandboxed?.Kill();
                if (_process is { HasExited: false }) _process.Kill(entireProcessTree: true);
            }
            catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception) { }
            finally { Interlocked.Exchange(ref _lifetime, null)?.Dispose(); }
        }

        public async ValueTask DisposeAsync()
        {
            Kill();
            // A killed process may still be exiting. Admission belongs to its actual lifetime, so a new worker
            // cannot start until this one has exited. Waiting is asynchronous, including on cancellation.
            if (_sandboxed is not null)
            {
                while (!_sandboxed.HasExited) await Task.Delay(10).ConfigureAwait(false);
                _sandboxed.Dispose();
            }
            if (_process is not null)
            {
                // WaitForExitAsync also waits for redirected stderr EOF. An exited root can leave that
                // pipe in a descendant, so it cannot own decoder admission. Retire our pipe reader after
                // the actual root exits; this does not establish containment of detached descendants.
                while (!_process.HasExited) await Task.Delay(10).ConfigureAwait(false);
                _stderrCancel?.Cancel();
                _process.Dispose();
                if (_stderrDrain is not null)
                {
                    try { await _stderrDrain.WaitAsync(TimeSpan.FromSeconds(1)).ConfigureAwait(false); }
                    catch (TimeoutException) { /* A detached descendant may still hold stderr. */ }
                }
                _stderrCancel?.Dispose();
            }
        }

        private static async Task DrainStderrAsync(Stream stderr, CancellationToken ct)
        {
            try { await stderr.CopyToAsync(Stream.Null, 81920, ct).ConfigureAwait(false); }
            catch (Exception ex) when (ex is OperationCanceledException or IOException or ObjectDisposedException)
            {
                // stderr is diagnostic-only and can close while the worker is being retired.
            }
        }
    }
}
