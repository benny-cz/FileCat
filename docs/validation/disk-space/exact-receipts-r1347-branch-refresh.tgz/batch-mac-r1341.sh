set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1; then printf 'BUSY phase=verify\n' > state.txt; exit 75; fi
if [ "$(uname -s)" = Darwin ]; then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1); else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1); fi
if [ "$actual" != '037dfc16d04ba2b1dae028806b7b767694d3d1acc0c1d7fec80ff8c2af8bd7d6' ]; then printf 'FAILED phase=integrity\n' > state.txt; exit 74; fi
umask 077
mkdir controller
tar -xzf bundle.tgz -C controller run.py
printf 'RUNNING phase=native\n' > state.txt
set +e
python3 controller/run.py "$PWD" '037dfc16d04ba2b1dae028806b7b767694d3d1acc0c1d7fec80ff8c2af8bd7d6'
code=$?
printf 'FINISHED exit=%s\n' "$code" > state.txt
exit "$code"
