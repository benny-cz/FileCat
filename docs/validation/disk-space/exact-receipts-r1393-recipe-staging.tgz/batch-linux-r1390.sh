set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1; then printf 'BUSY phase=verify\n' > state.txt; exit 75; fi
if [ "$(uname -s)" = Darwin ]; then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1); else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1); fi
if [ "$actual" != 'eda182046d9a9be073e80cb3f120dc033759b366f9f3508534c750910eacc030' ]; then printf 'FAILED phase=integrity\n' > state.txt; exit 74; fi
umask 077
mkdir controller
tar -xzf bundle.tgz -C controller run.py
printf 'RUNNING phase=native\n' > state.txt
set +e
python3 controller/run.py "$PWD" 'eda182046d9a9be073e80cb3f120dc033759b366f9f3508534c750910eacc030'
code=$?
printf 'FINISHED exit=%s\n' "$code" > state.txt
exit "$code"
