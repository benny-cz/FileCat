
$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
$state = Join-Path $base 'state.txt'
function Busy { @(Get-Process -Name 'FileCat*',dotnet -ErrorAction SilentlyContinue).Count -ne 0 }
function Run-Native([string]$phase, [string[]]$methods, [int]$expected) {
 if(Busy) { "BUSY phase=$phase" | Set-Content $state; exit 75 }
 "RUNNING phase=$phase" | Set-Content $state
 $arguments = @((Join-Path $payload 'FileCat.Platform.Windows.Tests.dll'))
 foreach($name in $methods) { $arguments += @('-method', $name) }
 $arguments += @('-noLogo','-noColor','-maxThreads','1','-xml',(Join-Path $base ($phase+'.xml')))
 $ErrorActionPreference = 'Continue'
 & 'C:\Program Files\dotnet\dotnet.exe' @arguments *> (Join-Path $base ($phase+'.log'))
 $result = $LASTEXITCODE
 $ErrorActionPreference = 'Stop'
 if($result -ne 0) { "FINISHED exit=$result phase=$phase" | Set-Content $state; exit $result }
 [xml]$results = Get-Content -LiteralPath (Join-Path $base ($phase+'.xml')) -Raw
 $summary = $results.assemblies.assembly
 if([int]$summary.total -ne $expected -or [int]$summary.passed -ne $expected -or [int]$summary.skipped -ne 0 -or [int]$summary.errors -ne 0) {
  throw "Expected $expected passing cases in $phase"
 }
}
if(Busy) { 'BUSY phase=verify' | Set-Content $state; exit 75 }
try {
 $archive = Join-Path $base 'bundle.tgz'
 if((Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant() -ne '66d08058beed6448ec8d0d7a523446e1e0ccb01dba6e2fec879b6fea885898c1') { throw 'Primary-content bundle hash mismatch' }
 $payload = Join-Path $base 'payload'
 New-Item -ItemType Directory -Path $payload | Out-Null
 
 $driver = Join-Path $base 'driver'
 New-Item -ItemType Directory -Path $driver | Out-Null
 & tar.exe -xzf $archive -C $driver
 if($LASTEXITCODE) { throw 'Primary-content overlay extraction failed' }
 $baseline = 'C:\FileCatDsa20261104R2\batch-r1373\payload'
 $plan = Get-Content -LiteralPath (Join-Path $driver 'plan.json') -Raw | ConvertFrom-Json
 foreach($row in $plan) {
  if([IO.Path]::IsPathRooted($row.path) -or $row.path.Contains(':') -or @($row.path -split '/' | Where-Object {$_ -eq '..'}).Count) {
   throw 'Invalid cached input'
  }
  $previous = Join-Path $baseline $row.path
  if((Get-FileHash -LiteralPath $previous).Hash.ToLowerInvariant() -ne $row.old) { throw 'Cached input changed' }
  if($row.patch -and $row.path -notin @('FileCat.Platform.Windows.Tests.dll','FileCat.Platform.Windows.Tests.pdb')) {
   throw 'Only the native test assembly can be overlaid'
  }
  $inputPath = if($row.patch) { Join-Path $driver ('patch/'+$row.path) } else { $previous }
  $target = Join-Path $payload $row.path
  New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
  Copy-Item -LiteralPath $inputPath -Destination $target
  if((Get-FileHash -LiteralPath $target).Hash.ToLowerInvariant() -ne $row.new) { throw 'Staged input changed' }
 }

 Set-Location -LiteralPath $payload
 $observed = [ordered]@{}
 foreach($name in 'FileCat.Core.dll','FileCat.Platform.Windows.dll','FileCat.Platform.Windows.Tests.dll') {
  $observed[$name] = (Get-FileHash -LiteralPath (Join-Path $payload $name)).Hash.ToLowerInvariant()
 }
 $observed | ConvertTo-Json | Set-Content (Join-Path $base 'cache-proof.json')
 Run-Native 'native' @('*NativeWindowsPrimaryContentRefusesAClosedMappedWrite*','*NativeWindowsPrimaryContentRefusesAReplacementDirectoryJunction*','*NativeWindowsPrimaryContentRefusesARevisionWithoutTheJournalWitness*') 3
 'FINISHED exit=0' | Set-Content $state
 exit 0
} catch {
 ($_ | Out-String) | Set-Content (Join-Path $base 'failure.txt')
 'FAILED' | Set-Content $state
 exit 1
}
