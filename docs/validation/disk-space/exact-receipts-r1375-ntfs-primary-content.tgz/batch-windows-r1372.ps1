
$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
$state = Join-Path $base 'state.txt'
function Busy { @(Get-Process -Name 'FileCat*',dotnet -ErrorAction SilentlyContinue).Count -ne 0 }
function Run-Native([string]$phase, [string[]]$methods, [int]$expected) {
 if(Busy) { "BUSY phase=$phase" | Set-Content $state; exit 75 }
 "RUNNING phase=$phase" | Set-Content $state
 $arguments = @((Join-Path $payload 'FileCat.Platform.Windows.Tests.dll'))
 foreach($name in $methods) { $arguments += @('-method', $name) }
 $arguments += @('-noLogo','-noColor','-maxThreads','1','-xml',(Join-Path $base ($phase+'.xml')))
 $ErrorActionPreference = 'Continue'
 & 'C:\Program Files\dotnet\dotnet.exe' @arguments *> (Join-Path $base ($phase+'.log'))
 $result = $LASTEXITCODE
 $ErrorActionPreference = 'Stop'
 if($result -ne 0) { "FINISHED exit=$result phase=$phase" | Set-Content $state; exit $result }
 [xml]$results = Get-Content -LiteralPath (Join-Path $base ($phase+'.xml')) -Raw
 $summary = $results.assemblies.assembly
 if([int]$summary.total -ne $expected -or [int]$summary.passed -ne $expected -or [int]$summary.skipped -ne 0 -or [int]$summary.errors -ne 0) {
  throw "Expected $expected passing cases in $phase"
 }
}
if(Busy) { 'BUSY phase=verify' | Set-Content $state; exit 75 }
try {
 $archive = Join-Path $base 'bundle.tgz'
 if((Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant() -ne 'd3d2cccee36522142e96c85f01e800317fea0088de38d783d83a217956c9e746') { throw 'Primary-content bundle hash mismatch' }
 $payload = Join-Path $base 'payload'
 New-Item -ItemType Directory -Path $payload | Out-Null
 & tar.exe -xzf $archive -C $payload
 if($LASTEXITCODE) { throw 'Primary-content bundle extraction failed' }
 Set-Location -LiteralPath $payload
 $observed = [ordered]@{}
 foreach($name in 'FileCat.Core.dll','FileCat.Platform.Windows.dll','FileCat.Platform.Windows.Tests.dll') {
  $observed[$name] = (Get-FileHash -LiteralPath (Join-Path $payload $name)).Hash.ToLowerInvariant()
 }
 $observed | ConvertTo-Json | Set-Content (Join-Path $base 'cache-proof.json')
 Run-Native 'native' @('*NativeWindowsPrimaryContent*') 11
 Run-Native 'native-epoch' @('*NativeWindowsCreationAndChangeTimes*','*CloudTagsRepresentRegularFilePaths*','*QueuedDirectoryCannotIgnoreRenamedAncestors*') 6
 'FINISHED exit=0' | Set-Content $state
 exit 0
} catch {
 ($_ | Out-String) | Set-Content (Join-Path $base 'failure.txt')
 'FAILED' | Set-Content $state
 exit 1
}
