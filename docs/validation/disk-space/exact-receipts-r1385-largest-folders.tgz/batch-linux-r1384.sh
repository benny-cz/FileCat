set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1; then printf 'BUSY phase=verify\n' > state.txt; exit 75; fi
if [ "$(uname -s)" = Darwin ]; then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1); else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1); fi
if [ "$actual" != 'd3d4843f76c56fafa7c4fba6f98087fdb2a6da95467b192279dddf470ed86696' ]; then printf 'FAILED phase=integrity\n' > state.txt; exit 74; fi
umask 077
mkdir controller
tar -xzf bundle.tgz -C controller run.py
printf 'RUNNING phase=native\n' > state.txt
set +e
python3 controller/run.py "$PWD" 'd3d4843f76c56fafa7c4fba6f98087fdb2a6da95467b192279dddf470ed86696'
code=$?
printf 'FINISHED exit=%s\n' "$code" > state.txt
exit "$code"
