set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1;then printf 'BUSY phase=verify
' > state.txt;exit 75;fi
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '68c9e16f3e4f1d66bc462089da78b015d61dbc95d09a754a3d8edc39f5ff8643' ];umask 077;mkdir driver;tar -xzf bundle.tgz -C driver
python3 driver/run.py
