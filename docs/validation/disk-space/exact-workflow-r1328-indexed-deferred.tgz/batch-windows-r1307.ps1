$ErrorActionPreference='Stop'
$base=$PSScriptRoot;$state=Join-Path $base 'state.txt'
function Busy { @(Get-Process -Name 'FileCat*' -ErrorAction SilentlyContinue).Count -or @(Get-Process -Name dotnet -ErrorAction SilentlyContinue).Count }
if(Busy){'BUSY phase=verify'|Set-Content $state;exit 75}
try{
 if((Get-FileHash -LiteralPath (Join-Path $base 'bundle.tgz') -Algorithm SHA256).Hash.ToLowerInvariant()-ne'2420edd2f1ffe785ceba45b64349cb15cf00293bfe8b060165cf207068e19b7a'){throw 'Focused archive hash mismatch'}
 $driver=Join-Path $base 'driver';if(Test-Path -LiteralPath $driver){throw 'Fresh driver directory required'}
 New-Item -ItemType Directory -Path $driver|Out-Null
 & tar.exe -xzf (Join-Path $base 'bundle.tgz') -C $driver;if($LASTEXITCODE){throw 'Focused driver extraction failed'}
 $plan=Get-Content -Raw -LiteralPath (Join-Path $driver 'plan.json')|ConvertFrom-Json
 if($plan.baseline-ne'C:\FileCatDsa20261104R2\batch-r1305\payload\render'){throw 'Unexpected baseline root'}
 $payload=Join-Path $base 'payload';if(Test-Path -LiteralPath $payload){throw 'Fresh focused payload required'}
 $cloneBytes=[long]0;foreach($item in $plan.files){$cloneBytes+=(Get-Item -LiteralPath (Join-Path $plan.baseline $item.path)).Length}
 $drive=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'";if($drive.FreeSpace-lt($cloneBytes+256MB)){throw 'Insufficient clone space'}
 foreach($item in $plan.files){
  if([IO.Path]::IsPathRooted($item.path)-or$item.path.Contains(':')-or@($item.path-split'/'|Where-Object{$_-eq'..'}).Count){throw 'Invalid cached input path'}
  if((Get-FileHash -LiteralPath (Join-Path $plan.baseline $item.path) -Algorithm SHA256).Hash.ToLowerInvariant()-ne$item.baselineSha256){throw 'Cached input changed'}
 }
 foreach($item in $plan.files){
  if($item.patch-and$item.path-notin $plan.assembly,($plan.assembly-replace'[.]dll$','.pdb')){throw 'Production input patch refused'}
  $source=if($item.patch){Join-Path $driver ('patch/'+$item.path)}else{Join-Path $plan.baseline $item.path}
  $target=Join-Path $payload $item.path;New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force|Out-Null;Copy-Item -LiteralPath $source -Destination $target
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()-ne$item.sha256){throw 'Copied input mismatch'}
 }
 $plan|ConvertTo-Json -Depth 8|Set-Content (Join-Path $base 'cache-proof.json')
 if(Busy){'BUSY phase=render'|Set-Content $state;exit 75}
 $arguments=@((Join-Path $payload $plan.assembly))
 foreach($method in $plan.methods){$arguments+=@('-method',$method)}
 $arguments+=@('-noLogo','-noColor','-maxThreads','2','-xml',(Join-Path $base 'render.xml'))
 'RUNNING phase=render'|Set-Content $state;Set-Location -LiteralPath $payload;$ErrorActionPreference='Continue'
 & 'C:\Program Files\dotnet\dotnet.exe' @arguments *> (Join-Path $base 'render.log')
 $result=$LASTEXITCODE;$ErrorActionPreference='Stop';if($result-eq0){[xml]$xml=Get-Content -Raw -LiteralPath (Join-Path $base 'render.xml');$a=$xml.assemblies.assembly;if([int]$a.total-ne840-or[int]$a.passed-ne839-or[int]$a.failed-ne0-or[int]$a.errors-ne0-or[int]$a.skipped-ne1){throw 'Rendering discovery mismatch'}};('FINISHED exit='+$result)|Set-Content $state;exit $result
}catch{($_|Out-String)|Set-Content (Join-Path $base 'failure.txt');'FAILED'|Set-Content $state;exit 1}
