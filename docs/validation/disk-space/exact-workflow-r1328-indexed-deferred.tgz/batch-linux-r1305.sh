set -eu
cd "$(dirname "$0")";base=$(pwd)
idle() {
 for attempt in 1 2 3; do
  if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1; then
   printf 'BUSY\n' > state.txt;ps -axo pid=,args= > busy.txt;exit 75
  fi
  sleep 1
 done
}
idle
printf 'RUNNING phase=verify\n' > state.txt
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '0ee940d7d741549106c82d9e74490ad63ebf293147f39886702db09e64d5888c' ];umask 077;mkdir payload;tar -xzf bundle.tgz -C payload
bin="$base/payload/render"
for phase in settings app-rescan render;do
 idle;printf 'RUNNING phase=%s\n' "$phase" > "$base/state.txt"
 assembly=FileCat.Rendering.Tests.dll;bin="$base/payload/render"
 case "$phase" in
  app-rescan) set -- -method '*NativeRuntimeRescanFactory*' -method '*NativeRescanView*' -method '*NativeRescanPreparationKeepsPrivateNamesExcludedAcrossBothEpochs' -method '*NativeOwnedRuntimeView*' -method '*NativeIndexedComparisonCanceledMappingAndAcquisitionPublishNoPartialTab' -method '*NonrespondingPreparationFreezesBindingAndNeverStartsAScanAfterReturning' -method '*NativeProgressivePreview*' -method '*NativeDeferredIndexed*';;
  render) set -- -class '*AnalysisRenderingTests';;
  settings) bin="$base/payload/tests/FileCat.App.Tests/bin/Debug/net10.0";assembly=FileCat.App.Tests.dll;set -- -method '*No_control_that_can_be_live_has_a_fixed_accessible_name';;
 esac
 set +e
 (cd "$bin";"$HOME/.dotnet/dotnet" "$assembly" "$@" -noLogo -noColor -maxThreads 2 -xml "$base/$phase.xml") > "$base/$phase.log" 2>&1
 result=$?;set -e
 if [ "$result" != 0 ] || ! python3 "$base/payload/validate.py" "$phase" "$base/$phase.xml";then printf 'FINISHED exit=1 phase=%s\n' "$phase" > "$base/state.txt";tail -n 30 "$base/$phase.log";exit 1;fi
done
printf 'FINISHED exit=0\n' > "$base/state.txt"
