set -eu
cd "$(dirname "$0")"
if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1; then printf 'BUSY phase=verify\n' > state.txt; exit 75; fi
if [ "$(uname -s)" = Darwin ]; then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1); else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1); fi
if [ "$actual" != 'bbeeede70c139fdd9d1065ec6a22d41d6730b4896f4890eec185eaf344e0b957' ]; then printf 'FAILED phase=integrity\n' > state.txt; exit 74; fi
umask 077
mkdir controller
tar -xzf bundle.tgz -C controller run.py
printf 'RUNNING phase=native\n' > state.txt
set +e
python3 controller/run.py "$PWD" 'bbeeede70c139fdd9d1065ec6a22d41d6730b4896f4890eec185eaf344e0b957'
code=$?
printf 'FINISHED exit=%s\n' "$code" > state.txt
exit "$code"
