using Avalonia.Controls;

namespace FileCat.App.ViewModels;

public sealed record PromptOptions(string Title, string Message)
{
    public string Text { get; init; } = string.Empty;
    public Func<string, string?>? Validate { get; init; }
    public IReadOnlyList<string>? History { get; init; }
    /// <summary>Select the name without its extension (rename, create file).</summary>
    public bool SelectStem { get; init; }
    public string ConfirmText { get; init; } = "OK";
    public string? CheckboxText { get; init; }
    public bool CheckboxValue { get; init; }
    public string? Hint { get; init; }
}

public sealed record PromptResult(string Text, bool Checked);

public sealed record ChoiceItem(string Title, string? Detail = null, string? Gesture = null, object? Tag = null)
{
    public bool IsHeader { get; init; }
    public bool Pinned { get; init; }

    /// <summary>The item's icon, asked for again as icons finish loading (see <see cref="ChoiceOptions.Icons"/>).</summary>
    public Func<Avalonia.Media.IImage?>? Icon { get; init; }
}

/// <param name="Index">Chosen item index, or -1 when canceled.</param>
/// <param name="Alternate">Shift+Enter: the alternate action (e.g. open in the target panel).</param>
/// <param name="Deleted">Items the user removed with Delete (history lists).</param>
public sealed record ChoiceResult(int Index, bool Alternate, IReadOnlyList<int> Deleted)
{
    public static ChoiceResult Canceled { get; } = new(-1, false, []);

    /// <summary>Items whose pinned state the user toggled with Insert (history lists).</summary>
    public IReadOnlyList<int> PinToggled { get; init; } = [];
}

public sealed record KeyboardHelpEntry(string Id, string Title, string Category, string? Gestures, string? Description,
    bool Enabled = true, string? UnavailableReason = null, string? ContextLabel = null, string? DefaultGestures = null);

/// <summary>What the keyboard reference was left with: a command to run, or one whose shortcut to change.</summary>
public sealed record KeyboardReferenceChoice(string CommandId, bool ChangeShortcut);

public sealed record ChoiceOptions(string Title, IReadOnlyList<ChoiceItem> Items)
{
    public string? Hint { get; init; }
    public int SelectedIndex { get; init; }
    public bool AllowDelete { get; init; }
    /// <summary>Insert pins or unpins the selected item (history lists keep pinned items first and never trim them).</summary>
    public bool AllowPin { get; init; }
    public string? AlternateHint { get; init; }

    /// <summary>Where the items' icons come from: rows show platform icons as they finish loading.</summary>
    public Services.IconProvider? Icons { get; init; }

    /// <summary>
    /// The chooser's own search: the indexes of the items matching the typed text, best first (the command palette ranks
    /// by synonyms and recent use). Without it, every typed word must appear in an item's title, detail, or shortcut.
    /// </summary>
    public Func<string, IReadOnlyList<int>>? Search { get; init; }

    /// <summary>
    /// Keys that choose an item at once when typed into the empty filter (upper case; the location menu's drive letters).
    /// Typing anything else first filters as usual, and then these keys filter too.
    /// </summary>
    public IReadOnlyDictionary<char, int>? Accelerators { get; init; }
}

/// <summary>A button in a custom dialog; <see cref="Result"/> is returned when chosen.</summary>
public sealed record DialogButton(string Text, object Result, bool IsDefault = false, bool IsCancel = false, bool IsDanger = false)
{
    /// <summary>Optional live text and accessibility, changed together with availability on the UI thread.</summary>
    public DialogButtonPresentation? Presentation { get; init; }

    /// <summary>
    /// When set, the button is enabled only while this is true ("Go to" needs a result): cheap and side-effect free, it
    /// is re-evaluated while the dialog is open.
    /// </summary>
    public Func<bool>? IsAvailable { get; init; }

    /// <summary>Concise consequence announced when this choice receives screen-reader focus.</summary>
    public string? HelpText { get; init; }

    /// <summary>Runs only on an explicit activation. False keeps this dialog open so field validation can retain the draft and focus.</summary>
    public Func<bool>? Validate { get; init; }
}

public sealed record DialogButtonSnapshot(string Text, string? AccessibleName = null, string? HelpText = null);

/// <summary>Presentation only. The dialog's existing result, availability and validation own activation.</summary>
public sealed class DialogButtonPresentation(DialogButtonSnapshot initial)
{
    private DialogButtonSnapshot _snapshot = initial ?? throw new ArgumentNullException(nameof(initial));
    public DialogButtonSnapshot Snapshot => Volatile.Read(ref _snapshot);
    public event Action? Changed;

    public void Update(DialogButtonSnapshot snapshot)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        Volatile.Write(ref _snapshot, snapshot);
        Changed?.Invoke();
    }
}

/// <summary>Lets a custom dialog's content end it as one of its buttons would (Enter on a search result: "Go to").</summary>
public sealed class DialogCloser
{
    private Action<object?>? _close;

    internal void Attach(Action<object?> close) => _close = close;

    /// <summary>Ends the dialog with <paramref name="result"/>; nothing happens once it has ended.</summary>
    public void Close(object? result) => _close?.Invoke(result);
}

/// <summary>Optional presentation and implicit-dismiss behavior for a custom modal.</summary>
public sealed record DialogBehavior
{
    public bool DismissOnBackdrop { get; init; } = true;
    public bool AlignTop { get; init; }
    /// <summary>Initial size for a resizable dialog, clamped to the available client area.</summary>
    public Avalonia.Size? PreferredSize { get; init; }
    /// <summary>Esc and the title-bar close button use this action; explicit buttons keep their own behavior.</summary>
    public Action? OnImplicitDismiss { get; init; }
    /// <summary>
    /// Plan §11.5: while this dialog is on top the operation center stays above its backdrop and usable (pointer, focus and
    /// its shortcut), for example during a format scan. Panel commands remain blocked.
    /// </summary>
    public bool KeepOperationsUsable { get; init; }
}

/// <summary>Overlay dialogs owned by the main window. Enter confirms; Esc follows each dialog's close behavior.</summary>
public interface IDialogService
{
    Task<PromptResult?> PromptAsync(PromptOptions options);
    Task<bool> ConfirmAsync(string title, string message, string confirmText = "OK", bool danger = false, string cancelText = "Cancel");
    /// <summary>Show explicit decision facts ahead of the complete explanation. Nonvisual dialog hosts retain the full message.</summary>
    Task<bool> ConfirmReviewAsync(string title, string message, IReadOnlyList<string> keyPoints,
        string confirmText = "OK", bool danger = false, string cancelText = "Cancel") =>
        ConfirmAsync(title, message, confirmText, danger, cancelText);
    Task AlertAsync(string title, string message);
    Task<ChoiceResult> ChooseAsync(ChoiceOptions options);
    /// <param name="selectedId">The command selected when it opens (after changing its shortcut).</param>
    Task<KeyboardReferenceChoice?> KeyboardReferenceAsync(IReadOnlyList<KeyboardHelpEntry> commands, string? selectedId = null, bool remapOnly = false);
    /// <summary>
    /// Hosts arbitrary content with buttons; returns the chosen button result or the cancel result on implicit close.
    /// The default button is
    /// enabled only while <paramref name="canConfirm"/> (cheap, side-effect free; re-evaluated while open) is true.
    /// <paramref name="closer"/> lets the content end the dialog itself.
    /// </summary>
    Task<object?> ShowCustomAsync(string title, Control content, IReadOnlyList<DialogButton> buttons, Control? initialFocus = null,
        Func<bool>? canConfirm = null, DialogCloser? closer = null, bool resizable = false,
        Control? pinnedReview = null, DialogBehavior? behavior = null);
    bool IsOpen { get; }
}

/// <summary>UI-only actions a view model asks the window to perform.</summary>
public interface IViewActions
{
    void FocusActivePanel();
    Task<string?> RenameInlineAsync(PromptOptions options);
    void FocusPathBox();
    void FocusPanelFilter();
    void FocusCommandLine();
    /// <summary>Puts the keyboard in the command search (Ctrl+Shift+P); false where the window shows none.</summary>
    bool FocusCommandSearch();
    /// <summary>Closes the main window (used when the user chose to exit once operations finish).</summary>
    void CloseWhenIdle();
    void OpenMenuBar();
    void ShowContextMenu();
    void ShowNotification(string message, bool isError = false);
    /// <summary>Rebuilds menus and gesture hints after key bindings change.</summary>
    void ReloadChrome();
    Avalonia.Input.Platform.IClipboard? Clipboard { get; }
    TopLevel? TopLevel { get; }
}

/// <summary>The measured panel host, excluding variable menu, toolbar, operations, command-line and key-bar chrome.</summary>
public interface IWorkspaceViewportProvider
{
    Avalonia.Size? WorkspaceViewport { get; }
}

/// <summary>Focuses the measured splitter next to the active panel for explicit keyboard resizing.</summary>
public interface IPanelResizeActions
{
    bool BeginPanelResize(PanelViewModel panel);
}

/// <summary>Opens the active panel's ancestor menu using its provider-derived breadcrumb segments.</summary>
public interface IBreadcrumbActions
{
    bool OpenAncestorMenu();
}
