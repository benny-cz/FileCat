using Avalonia.Input;
using Avalonia.Input.Platform;
using Avalonia.Platform.Storage;
using FileCat.App.Services;
using FileCat.App.Views;
using FileCat.Core.Commands;
using FileCat.Core.Diagnostics;
using FileCat.Core.FileSystem;
using FileCat.Core.Jobs;
using FileCat.Core.Listing;
using FileCat.Core.Resources;
using FileCat.Core.Selection;
using FileCat.Core.State;
using FileCat.Core.Tools;
using FileCat.Core.Threading;

namespace FileCat.App.ViewModels;

internal readonly record struct TransferDestinationResolution(Location? Destination, string? NewName, string? Error, string Description)
{
    public bool Valid => Destination is not null && Error is null;
}

/// <summary>
/// File operations (plan §4.3–4.4, §9): every mutation goes through the job engine (AI-02). The destination
/// shown in the dialog is captured when the job is confirmed (AI-07); after an operation fully processed
/// items are unmarked and failed or skipped items stay marked for a retry (D-36).
/// </summary>
public sealed partial class MainViewModel
{
    internal Func<string, bool> TransferDestinationDirectoryExists { get; set; } = Directory.Exists;
    private readonly Dictionary<Job, (TabViewModel Tab, Location Location)> _jobOrigins = new();
    private bool _showingDecision;
    private OperationCenterViewModel? _operations;

    public OperationCenterViewModel Operations => _operations ??= CreateOperations();

    private OperationCenterViewModel CreateOperations()
    {
        var oc = new OperationCenterViewModel(Services.Jobs, Services.Providers.Display);
        oc.CanReviewArchiveCleanup = job => Services.ArchiveCleanupLease is not null && ArchiveCleanupReview.CanOffer(job) ||
            Services.ArchiveCreationCleanupLease is not null && ArchiveCreationCleanupReview.CanOffer(job) ||
            Services.ArchiveExchangeRecovery is not null && ArchiveExchangeCleanupReview.CanOffer(job) ||
            Services.ArchiveDiscardLease is not null && ArchiveDiscardReview.CanOffer(job);
        Services.Jobs.DecisionRequested += d => Services.Ui.Post(() => EnqueueDecision(d));
        Services.Jobs.JobFinished += job => Services.Ui.Post(() => OnJobFinished(job));
        Services.Jobs.JobAdded += _ => Services.Ui.Post(UpdateJobActivity);
        Services.Io.HealthChanged += (device, health) => Services.Ui.Post(() => Notify(health == Core.Threading.DeviceHealth.NotResponding
            ? $"{device} is not responding. Other drives keep working; its operations continue when it responds again."
            : $"{device} responds again.", health == Core.Threading.DeviceHealth.NotResponding));
        return oc;
    }

    private partial async Task<bool> ExecuteOperationCommandAsync(string id)
    {
        if (Core.Search.ResultSetProvider.IsWorkingSetList(ActiveTab?.Location) && await WorkingSetListCommandAsync(id)) return true;
        switch (id)
        {
            case CommandIds.StorageAttributes: await ChangeStorageAttributesAsync(); return true;
            case CommandIds.AddToWorkingSet: await AddToWorkingSetAsync(); return true;
            case CommandIds.WorkingSets: OpenWorkingSets(); return true;
            case CommandIds.Copy:
                if (TryGetFocusedRegistryItem(out _)) await CopyRegistryAsync();
                else await TransferAsync(JobKind.Copy);
                return true;
            case CommandIds.Move: await TransferAsync(JobKind.Move); return true;
            case CommandIds.Duplicate: await DuplicateAsync(); return true;
            case CommandIds.Rename:
                if (TryGetFocusedRegistryItem(out _)) await RenameRegistryAsync();
                else await RenameAsync();
                return true;
            case CommandIds.MakeDirectory: await MakeDirectoryAsync(); return true;
            case CommandIds.Delete: await DeleteAsync(permanent: false); return true;
            case CommandIds.DeletePermanent: await DeleteAsync(permanent: true); return true;
            case CommandIds.EditNew: await EditNewAsync(); return true;
            case CommandIds.Edit: await EditFocusedAsync(); return true;
            case CommandIds.View: ViewFocused(hex: false); return true;
            case CommandIds.ChangeJournal: OpenChangeJournal(); return true;
            case CommandIds.ViewAlternate: ViewFocused(hex: true); return true;
            case CommandIds.Undo: await UndoLastAsync(); return true;
            case CommandIds.Operations: Operations.IsOpen = !Operations.IsOpen; return true;
            case CommandIds.CopyToClipboard: await PutFilesOnClipboardAsync(cut: false); return true;
            case CommandIds.CutToClipboard: await PutFilesOnClipboardAsync(cut: true); return true;
            case CommandIds.PasteFromClipboard: await PasteAsync(); return true;
            case CommandIds.Checksum: await ChecksumAsync(); return true;
            case CommandIds.CopyUncPaths: await CopyUncPathsAsync(); return true;
            case CommandIds.ConnectNetworkDrive: ConnectDrive(connect: true); return true;
            case CommandIds.DisconnectNetworkDrive: ConnectDrive(connect: false); return true;
            case CommandIds.SftpConnect: await ConnectSftpAsync(); return true;
            case CommandIds.SftpDisconnect: DisconnectSftp(); return true;
            case CommandIds.RemoveFromSet: RemoveFromResultSet(); return true;
        }
        return false;
    }

    public bool CanCloseImmediately() => !Services.Jobs.HasActiveWork && UnsavedHexEditors().Count == 0;

    /// <summary>Closing presents unsaved edits and active work: finish, cancel safely, or keep the app open (plan §9.3).</summary>
    public async Task<bool> ConfirmExitWithActiveWorkAsync()
    {
        if (!await ConfirmCloseHexEditorsAsync()) return false;
        var active = Services.Jobs.Jobs.Where(j => !j.State.IsFinished()).ToList();
        if (active.Count == 0) return true;
        // A text block per paragraph and per operation: line breaks inside one wrapped text spin Avalonia's headless
        // layout (tests reach this when a test's job still waits for an answer).
        var content = new Avalonia.Controls.StackPanel { Spacing = 4, MaxWidth = 620 };
        content.Children.Add(new Avalonia.Controls.TextBlock
        {
            Text = "Closing FileCat stops these operations at their next safe step. Completed steps stay completed; nothing is rolled back.",
            TextWrapping = Avalonia.Media.TextWrapping.Wrap,
            Margin = new Avalonia.Thickness(0, 0, 0, 6),
        });
        foreach (var line in ExactList(active.Select(j => $"{j.Title} — {j.State.Describe()}")).Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries))
            content.Children.Add(new Avalonia.Controls.TextBlock { Text = line, TextWrapping = Avalonia.Media.TextWrapping.Wrap });
        var r = await Dialogs.ShowCustomAsync("Operations are still running", content,
            [new DialogButton("Keep FileCat open", "keep", IsDefault: true, IsCancel: true), new DialogButton("Exit when they finish", "later"), new DialogButton("Stop them and exit", "stop", IsDanger: true)]);
        if (r as string == "later")
        {
            _exitWhenIdle = true;
            Notify("FileCat closes when the running operations finish. Questions they ask are still shown.");
            return false;
        }
        if (r as string != "stop")
        {
            _exitWhenIdle = false;
            return false;
        }
        foreach (var j in active) j.Cancel();
        var deadline = DateTime.UtcNow.AddSeconds(10);
        while (Services.Jobs.HasActiveWork && DateTime.UtcNow < deadline) await Task.Delay(50);
        // A native call can outlive the bounded wait. Keep the window and its
        // journal owner alive until that call returns and the job retires.
        _exitWhenIdle = true;
        if (!Services.Jobs.HasActiveWork)
        {
            _exitWhenIdle = false;
            return true;
        }
        Notify("Stop requested. FileCat will close after the current safe step finishes; completed changes remain.");
        return false;
    }

    // ---- Selection helpers ----------------------------------------------------------------------------

    private (TabViewModel Tab, IReadOnlyList<ItemRef> Items, int HiddenMarked, string Summary)? SourceSelection()
    {
        var tab = ActiveTab;
        if (tab?.Location is null) return null;
        var stats = tab.Listing.GetMarkStats();
        var items = tab.Listing.GetSelection(includeHiddenMarks: true);
        if (items.Count == 0)
        {
            Notify(NothingChosenReason(tab));
            return null;
        }
        // A captured (huge) selection is exactly the marks: summarize from the cached statistics, not by enumerating.
        var summary = items is SelectionSnapshot
            ? SizeSummary(stats.Files, stats.Directories, stats.Bytes, stats.SizesIncomplete)
            : SizeSummary(items);
        return (tab, items, stats.HiddenByFilter, summary);
    }

    private static string SizeSummary(IReadOnlyList<ItemRef> items)
    {
        long bytes = items.Where(i => !i.IsContainer && i.Size > 0).Sum(i => i.Size);
        int dirs = items.Count(i => i.IsContainer);
        return SizeSummary(items.Count - dirs, dirs, bytes, dirs > 0);
    }

    private static string SizeSummary(int files, int dirs, long bytes, bool folderContentsExcluded)
    {
        var parts = new List<string>();
        if (files > 0) parts.Add(Formatters.Plural(files, "file", "files"));
        if (dirs > 0) parts.Add(Formatters.Plural(dirs, "folder", "folders"));
        return string.Join(" and ", parts) + (bytes > 0 ? $" ({Formatters.SizeWithUnit(bytes)}{(folderContentsExcluded ? " + folder contents" : "")})" : "");
    }

    // ---- Copy / move ---------------------------------------------------------------------------------

    private async Task TransferAsync(JobKind kind, IReadOnlyList<ItemRef>? explicitItems = null,
        Location? explicitDestination = null, TabViewModel? explicitSource = null)
    {
        var sel = explicitItems is null ? SourceSelection() : null;
        if (sel is null && explicitItems is null) return;
        var tab = explicitSource ?? sel?.Tab ?? ActiveTab!;
        var items = explicitItems ?? sel!.Value.Items;
        IReadOnlyList<ItemRef>? finalItems = null, submitted = null;
        try
        {
            var source = tab.Location!;
            var sourceCaps = Services.Providers.For(source).GetCapabilities(source);
            bool requireResultSourceMetadata = source.Scheme == Schemes.ResultSet && items.All(i => i.FileSystemPath is not null);
            if (requireResultSourceMetadata && !await Task.Run(() => items.All(i => SourcePathReview.MatchesSelectionMetadata(i, Services.Jobs.FileOperations))))
            {
                Notify("A selected result changed since it was listed. Search or refresh the results, then review the current item before copying or moving.", true);
                return;
            }
            if (kind == JobKind.Move && (sourceCaps & LocationCapabilities.MoveSource) == 0)
            {
                Notify(Services.Providers.For(source).ExplainUnavailable(source, LocationCapabilities.MoveSource) + " Use F5 to copy instead.", true);
                return;
            }
            var target = Workspace.ActiveTarget;
            var destination = explicitDestination ?? target?.ActiveTab?.Location;
            if (explicitDestination is null && Core.Search.ResultSetProvider.IsPersistent(destination))
            {
                // Toward a working set F5 and F6 collect references (FAR's Temporary Panel); nothing is copied or moved.
                await AddToTargetWorkingSetAsync(kind, items, destination!, sel?.Summary ?? SizeSummary(items));
                return;
            }
            string destText = destination is { IsFileSystem: true } d ? AppendSeparator(d.Path) : destination is null ? string.Empty : Services.Providers.Display(destination);
            if (items.Count == 1 && explicitDestination is null && destination is null) destText = string.Empty;
            var summary = explicitItems is null ? sel!.Value.Summary : SizeSummary(items);
            var request = await OperationDialogs.ShowTransferAsync(this, new TransferDialogInput(
                kind, items, summary, destText, target is null ? null : $"panel {target.Number}",
                sel?.HiddenMarked ?? 0, source.Scheme == Schemes.ResultSet, explicitDestination is null ? PanelDestinations(tab) : null)
            { InitialLocation = destination, BaseLocation = source });
            if (request is null) return;
            Location? destLocation = request.ResolvedDestination;
            string? newName = request.NewName;
            if (destLocation is null) { Notify("The destination changed before this transfer was submitted. Review it again.", true); return; }
            // Hidden marks are excluded only when there are some and the user did not include them.
            finalItems = request.IncludeHidden || explicitItems is not null || (sel?.HiddenMarked ?? 0) == 0 ? items : tab.Listing.GetSelection(includeHiddenMarks: false);
            if (destLocation?.Scheme is Schemes.Zip or Schemes.Archive)
            {
                await AddToArchiveTransferAsync(kind, finalItems, destLocation, request.Options, newName,
                    request.Queue ? QueueMode.Queue : QueueMode.Start, tab, source);
                return;
            }
            if (kind == JobKind.Move && newName is null && destLocation is { } dl && ItemSources.Parents(finalItems)!.Contains(dl))
            {
                Notify("The items are already in that folder.");
                return;
            }
            AppServices.RememberText(Services.History.CopyDestinations, request.Destination);
            // Result-set items carry their relative folders; the executor recreates them unless flattening.
            var job = Services.Jobs.Submit(new JobRequest
            {
                Kind = source.IsFileSystem || kind == JobKind.Move ? kind : JobKind.Copy,
                Sources = finalItems,
                Destination = destLocation,
                NewName = newName,
                Options = request.Options,
                Mode = request.Queue ? QueueMode.Queue : QueueMode.Start,
                RequireResultSourceMetadata = requireResultSourceMetadata,
            });
            submitted = finalItems;
            Track(job, tab);
            tab.Listing.RememberOperation(finalItems);
        }
        finally
        {
            ReleaseUnsubmitted(submitted, sel?.Items, finalItems);
        }
    }

    /// <summary>The other panels' folders on disk that F5 and F6 can go to, in panel order.</summary>
    private List<PanelDestination> PanelDestinations(TabViewModel source)
    {
        var list = new List<PanelDestination>();
        foreach (var panel in Workspace.Panels)
        {
            if (ReferenceEquals(panel, source.Panel) || panel.ActiveTab?.Location is not { IsFileSystem: true } location) continue;
            list.Add(new PanelDestination(panel.Number, panel.ActiveTab.Title, AppendSeparator(location.Path)));
        }
        return list;
    }

    /// <summary>Why a command that acts on items has none: the cursor on "..", or an empty folder.</summary>
    internal static string NothingChosenReason(TabViewModel? tab) =>
        tab is not null && tab.Listing.TryGetFocused(out var focused) && focused.Kind == EntryKind.Parent
            ? "The cursor is on \"..\" (the folder above): move it to an item, or mark items."
            : "Nothing is focused or marked.";

    /// <summary>Releases captured selections that did not become a job's sources (the job's are released when it finishes).</summary>
    private static void ReleaseUnsubmitted(IReadOnlyList<ItemRef>? submitted, params IReadOnlyList<ItemRef>?[] captured)
    {
        foreach (var c in captured)
        {
            if (c is not null && !ReferenceEquals(c, submitted)) ItemSources.Release(c);
        }
    }

    private static string AppendSeparator(string path) =>
        path.EndsWith(Path.DirectorySeparatorChar) ? path : path + Path.DirectorySeparatorChar;

    /// <summary>The transfer form and its submission use this same captured interpretation. Filesystem probes stay on a device worker.</summary>
    internal async Task<TransferDestinationResolution> ResolveTransferDestinationAsync(string text, IReadOnlyList<ItemRef> items,
        Location? context, Location? unchangedLocation = null, string? unchangedText = null, CancellationToken cancellationToken = default)
    {
        string t = text.Trim();
        if (t.Length == 0) return new(null, null, "Enter a destination folder.", string.Empty);
        if (unchangedLocation is { IsFileSystem: false } original && t == unchangedText)
        {
            var originalProvider = Services.Providers.For(original);
            if ((originalProvider.GetCapabilities(original) & LocationCapabilities.TransferTarget) == 0)
                return new(null, null, originalProvider.ExplainUnavailable(original, LocationCapabilities.TransferTarget), string.Empty);
            return new(original, null, null, "→ " + Services.Providers.Display(original) +
                (original.Scheme == Schemes.Archive ? ". The whole archive will be rebuilt and checked." : ""));
        }
        Location? loc;
        try
        {
            bool parsed;
            if (unchangedLocation?.Scheme == Schemes.Archive)
            {
                // Archive path recognition probes the filesystem. Keep it on the container's device worker.
                var result = await Services.Io.Run(Services.Archives.GetDeviceKey(unchangedLocation), IoPriority.Interactive, ct =>
                {
                    ct.ThrowIfCancellationRequested();
                    bool found = Services.Providers.TryParse(t, context, out var value);
                    return (Found: found, Value: value);
                }, cancellationToken);
                parsed = result.Found; loc = result.Value;
            }
            else parsed = Services.Providers.TryParse(t, context, out loc);
            if (!parsed || loc is null)
                return new(null, null, "This is not a recognized destination location.", string.Empty);
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            return new(null, null, "This destination cannot be parsed: " + Formatters.SafeName(ex.Message), string.Empty);
        }
        if (!loc.IsFileSystem)
        {
            if (loc.Scheme == Schemes.Archive)
                return ResolveNativeArchiveDestination(loc, items.Count, t.EndsWith('\\') || t.EndsWith('/'));
            var provider = Services.Providers.For(loc);
            if ((provider.GetCapabilities(loc) & LocationCapabilities.TransferTarget) == 0)
                return new(null, null, provider.ExplainUnavailable(loc, LocationCapabilities.TransferTarget), string.Empty);
            return new(loc, null, null, "→ " + Services.Providers.Display(loc));
        }
        string path = loc.Path;
        string root = Path.GetPathRoot(path) ?? string.Empty;
        foreach (var component in path[root.Length..].Split([Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar], StringSplitOptions.RemoveEmptyEntries))
            if (PathUtil.ValidateNewName(component) is { } bad)
                return new(null, null, $"The destination path component “{Formatters.SafeName(component)}” is invalid: {bad}", string.Empty);
        bool endsWithSep = t.EndsWith('\\') || t.EndsWith('/');
        return await Services.Io.Run(PathUtil.GetDeviceKey(path), IoPriority.Interactive, ct =>
        {
            ct.ThrowIfCancellationRequested();
            if (unchangedLocation?.Scheme == Schemes.Archive && Services.Archives.TryParse(path, null, out var nativeLocation) && nativeLocation is not null)
                return ResolveNativeArchiveDestination(nativeLocation, items.Count, endsWithSep);
            // The filesystem provider also accepts paths below a ZIP file. Rebind those paths on the device worker
            // before treating a non-existent child as a filesystem folder. The accepted mapping stays in the draft.
            if (unchangedLocation?.Scheme == Schemes.Zip && Services.Zip.TryParse(path, null, out var archiveLocation) && archiveLocation is not null)
            {
                ct.ThrowIfCancellationRequested();
                if ((Services.Zip.GetCapabilities(archiveLocation) & LocationCapabilities.TransferTarget) == 0)
                    return new TransferDestinationResolution(null, null,
                        Services.Zip.ExplainUnavailable(archiveLocation, LocationCapabilities.TransferTarget), string.Empty);
                if (archiveLocation.Path.Length > 0 && Core.Archives.ArchivePaths.Problem(archiveLocation.Path) is { } problem)
                    return new TransferDestinationResolution(null, null, problem, string.Empty);
                if (Services.Zip.DirectoryExists(archiveLocation))
                    return new TransferDestinationResolution(archiveLocation, null, null,
                        "→ into the archive folder " + Formatters.SafeName(Services.Providers.Display(archiveLocation)));
                var parent = Services.Zip.GetParent(archiveLocation);
                if (parent?.Scheme == Schemes.Zip && Services.Zip.DirectoryExists(parent))
                {
                    string name = Services.Zip.GetNameInParent(archiveLocation)!;
                    if (!endsWithSep && items.Count == 1)
                        return new TransferDestinationResolution(parent, name, null,
                            $"→ as “{Formatters.SafeName(name)}” in {Formatters.SafeName(Services.Providers.Display(parent))}");
                    if (Services.Zip.CopiesOf(parent, name) > 0)
                        return new TransferDestinationResolution(null, null,
                            "An archive file already uses this folder name. Choose another folder.", string.Empty);
                }
                return new TransferDestinationResolution(archiveLocation, null, null,
                    "→ the archive folder " + Formatters.SafeName(Services.Providers.Display(archiveLocation)) + " will be created");
            }
            if (TransferDestinationDirectoryExists(path))
                return new TransferDestinationResolution(loc, null, null, "→ into the folder " + Formatters.SafeName(path));
            if (!endsWithSep && items.Count == 1)
            {
                string? parent = Path.GetDirectoryName(path);
                ct.ThrowIfCancellationRequested();
                if (parent is not null && TransferDestinationDirectoryExists(parent))
                {
                    string name = Path.GetFileName(path);
                    if (PathUtil.ValidateNewName(name) is { } bad)
                        return new TransferDestinationResolution(null, null, bad, string.Empty);
                    return new TransferDestinationResolution(Location.FileSystem(parent), name, null,
                        $"→ as “{Formatters.SafeName(name)}” in {Formatters.SafeName(parent)}");
                }
            }
            return new TransferDestinationResolution(loc, null, null, "→ the folder " + Formatters.SafeName(path) + " will be created");
        }, cancellationToken);
    }

    // This is a provisional interpretation from the listing cache. Submission resolves it against a fresh strict catalog.
    private TransferDestinationResolution ResolveNativeArchiveDestination(Location location, int count, bool trailingSeparator)
    {
        if ((Services.Archives.GetCapabilities(location) & LocationCapabilities.TransferTarget) == 0)
            return new(null, null, Services.Archives.ExplainUnavailable(location, LocationCapabilities.TransferTarget), "");
        if (location.Path.Length > 0 && Core.Archives.ArchivePaths.Problem(location.Path) is { } problem)
            return new(null, null, problem, "");
        const string cost = ". The whole archive will be rebuilt and checked.";
        if (Services.Archives.CachedDirectoryHint(location) == true || trailingSeparator || count != 1)
            return new(location, null, null, "→ into the archive folder " + Formatters.SafeName(Services.Providers.Display(location)) + cost);
        var parent = Services.Archives.GetParent(location);
        if (parent?.Scheme != Schemes.Archive) return new(location, null, null, "→ " + Services.Providers.Display(location) + cost);
        string name = Services.Archives.GetNameInParent(location)!;
        return new(parent, name, null, $"→ as “{Formatters.SafeName(name)}” in {Formatters.SafeName(Services.Providers.Display(parent))}" + cost);
    }

    private void Track(Job job, TabViewModel tab)
    {
        if (tab.Location is { } l) _jobOrigins[job] = (tab, l);
    }

    private async Task DuplicateAsync()
    {
        var tab = ActiveTab;
        if (tab?.Location is not { IsFileSystem: true } loc || !tab.Listing.TryGetFocused(out var f) || f.Kind == EntryKind.Parent) return;
        var suggestion = PathUtil.MakeUniqueName(f.Name, n => File.Exists(Path.Combine(loc.Path, n)) || Directory.Exists(Path.Combine(loc.Path, n)), f.IsContainer);
        var r = await Dialogs.PromptAsync(new PromptOptions("Duplicate here", $"Copy \"{f.Name}\" in this folder as:")
        {
            Text = suggestion,
            SelectStem = !f.IsContainer,
            Validate = n => ValidateSiblingName(loc.Path, n, f.Name),
            ConfirmText = "Duplicate",
        });
        if (r is null) return;
        var item = tab.Listing.GetItemRef(tab.Listing.FocusedStoreIndex);
        var job = Services.Jobs.Submit(new JobRequest { Kind = JobKind.Copy, Sources = [item], Destination = loc, NewName = r.Text });
        Track(job, tab);
        _focusAfter[job] = r.Text;
    }

    private readonly Dictionary<Job, string> _focusAfter = new();

    private static string? ValidateSiblingName(string dir, string name, string? current = null)
    {
        if (PathUtil.ValidateNewName(name) is { } bad) return bad;
        if (current is not null && string.Equals(name, current, StringComparison.Ordinal)) return "The name is unchanged.";
        bool caseOnly = current is not null && string.Equals(name, current, StringComparison.OrdinalIgnoreCase);
        if (!caseOnly && (File.Exists(Path.Combine(dir, name)) || Directory.Exists(Path.Combine(dir, name)))) return "An item with this name already exists here.";
        return null;
    }

    /// <summary>File-system names being edited in their rows now: the rename a Shell New command offers never takes over one.</summary>
    private int _inlineRenames;

    private async Task RenameAsync()
    {
        var tab = ActiveTab;
        if (tab?.Location is not { } loc || !tab.Listing.TryGetFocused(out var f) || f.Kind == EntryKind.Parent) return;
        if (loc.Scheme == Schemes.Archive || ZipWorker(loc))
        {
            await RenameNativeArchiveMemberAsync(tab, loc);
            return;
        }
        if (loc.Scheme == Schemes.Zip)
        {
            await RenameArchiveMemberAsync(tab, loc);
            return;
        }
        if (loc.Scheme is Schemes.Sftp or Schemes.Mtp)
        {
            await RenameRemoteAsync(tab, f);
            return;
        }
        var caps = Services.Providers.For(loc).GetCapabilities(loc);
        if ((caps & LocationCapabilities.Rename) == 0 || !loc.IsFileSystem && loc.Scheme != Schemes.ResultSet)
        {
            Notify(Services.Providers.For(loc).ExplainUnavailable(loc, LocationCapabilities.Rename), true);
            return;
        }
        var item = tab.Listing.GetItemRef(tab.Listing.FocusedStoreIndex);
        var dir = Path.GetDirectoryName(item.FileSystemPath!)!;
        string? newName;
        _inlineRenames++;
        try
        {
            newName = await View.RenameInlineAsync(new PromptOptions("Rename", $"New name for \"{Formatters.SafeName(f.Name)}\":")
            {
                Text = f.Name,
                SelectStem = !f.IsContainer,
                Validate = n => ValidateSiblingName(dir, n, f.Name),
                ConfirmText = "Rename",
            });
        }
        finally { _inlineRenames--; }
        if (newName is null) return;
        var job = Services.Jobs.Submit(new JobRequest { Kind = JobKind.Rename, Sources = [item], NewName = newName });
        Track(job, tab);
        _focusAfter[job] = newName;
    }

    private async Task MakeDirectoryAsync(TabViewModel? contextTab = null)
    {
        var tab = contextTab ?? ActiveTab;
        if (tab?.Location?.Scheme == Schemes.Registry) { await CreateRegistryAsync(); return; }
        if (tab?.Location is { } nativeArchiveFolder && (nativeArchiveFolder.Scheme == Schemes.Archive || ZipWorker(nativeArchiveFolder)))
        {
            await CreateNativeArchiveFolderAsync(tab, nativeArchiveFolder);
            return;
        }
        if (tab?.Location is { Scheme: Schemes.Zip } archiveFolder)
        {
            await CreateArchiveFolderAsync(tab, archiveFolder);
            return;
        }
        if (tab?.Location is { Scheme: Schemes.Sftp or Schemes.Mtp } remoteFolder && (Services.Providers.For(remoteFolder).GetCapabilities(remoteFolder) & LocationCapabilities.CreateDirectory) != 0)
        {
            await CreateRemoteFolderAsync(tab, remoteFolder);
            return;
        }
        if (tab?.Location is not { IsFileSystem: true } loc) return;
        // The platform's separators nest folders: / everywhere, and \ on Windows. Elsewhere \ is an ordinary name
        // character, which is how the folder is created and what Rename allows.
        char[] separators = [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar];
        var r = await Dialogs.PromptAsync(new PromptOptions("Create folder", $"Folder name (use {Path.DirectorySeparatorChar} for nested folders):")
        {
            Validate = n =>
            {
                var parts = n.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 0) return "The name cannot be empty.";
                foreach (var p in parts) if (PathUtil.ValidateNewName(p) is { } bad) return bad;
                return Directory.Exists(Path.Combine(loc.Path, n)) || File.Exists(Path.Combine(loc.Path, n)) ? "An item with this name already exists here." : null;
            },
            ConfirmText = "Create",
        });
        if (r is null) return;
        var job = Services.Jobs.Submit(new JobRequest { Kind = JobKind.CreateDirectory, Destination = loc, NewName = r.Text.Trim(separators) });
        Track(job, tab);
        _focusAfter[job] = r.Text.Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
    }

    private async Task EditNewAsync()
    {
        var tab = ActiveTab;
        if (tab?.Location is not { IsFileSystem: true } loc) return;
        var r = await Dialogs.PromptAsync(new PromptOptions("Edit new file", "File name (an existing file is opened instead):")
        {
            Validate = n => PathUtil.ValidateNewName(n) ?? (Directory.Exists(Path.Combine(loc.Path, n)) ? "A folder with this name exists." : null),
            ConfirmText = "Create and edit",
        });
        if (r is null) return;
        var full = Path.Combine(loc.Path, r.Text);
        if (File.Exists(full))
        {
            LaunchEditor(full);
            return;
        }
        var job = Services.Jobs.Submit(new JobRequest { Kind = JobKind.CreateFile, Destination = loc, NewName = r.Text });
        Track(job, tab);
        _focusAfter[job] = r.Text;
        _editAfter[job] = full;
    }

    private readonly Dictionary<Job, string> _editAfter = new();

    // ---- Delete -------------------------------------------------------------------------------------

    private async Task DeleteAsync(bool permanent)
    {
        if (TryGetFocusedRegistryItem(out _)) { await DeleteRegistryAsync(); return; }
        var sel = SourceSelection();
        if (sel is null) return;
        var (tab, items, hidden, summary) = sel.Value;
        IReadOnlyList<ItemRef>? finalItems = null, submitted = null;
        try
        {
            var loc = tab.Location!;
            if (loc.Scheme == Schemes.HiddenData)
            {
                await DeleteHiddenDataAsync(tab, items);
                return;
            }
            if (loc.Scheme == Schemes.Archive || ZipWorker(loc))
            {
                await DeleteNativeArchiveMembersAsync(loc, items.ToList());
                return;
            }
            if (loc.Scheme == Schemes.Zip)
            {
                if (items.Count > MaxArchiveBatch) { Notify($"Delete at most {MaxArchiveBatch:N0} members at a time.", true); return; }
                await DeleteArchiveMembersAsync(loc, items.ToList());
                return;
            }
            if (loc.Scheme is Schemes.Sftp or Schemes.Mtp)
            {
                await DeleteRemoteAsync(tab, items, summary);
                return;
            }
            var provider = Services.Providers.For(loc);
            var caps = provider.GetCapabilities(loc);
            if (loc.Scheme != Schemes.ResultSet && (caps & LocationCapabilities.Delete) == 0)
            {
                Notify(provider.ExplainUnavailable(loc, LocationCapabilities.Delete), true);
                return;
            }
            if (ItemSources.Parents(items)!.Any(p => !p.IsFileSystem))
            {
                Notify("Deleting is supported for file-system items here.", true);
                return;
            }
            // Pre-classify items the Recycle Bin cannot take and ask before starting (plan §9.2). Only a bounded
            // set of examples is kept; the count is exact.
            var fs = Services.Platform.FileOperations;
            var examples = new List<(string Name, RecycleClassification Why)>();
            int unrecyclable = 0;
            bool confirmedPermanent = false;
            if (!permanent)
            {
                if (items.Count > 10_000) Notify($"Checking {items.Count:N0} items for {RecycleText.Destination}…");
                unrecyclable = await Task.Run(() =>
                {
                    int count = 0;
                    foreach (var i in items)
                    {
                        var why = fs.ClassifyRecycle(i.FileSystemPath!, i.IsContainer ? -1 : i.Size);
                        if (why is RecycleClassification.Recyclable or RecycleClassification.Unknown) continue;
                        count++;
                        if (examples.Count < 100) examples.Add((i.Name, why));
                    }
                    return count;
                });
                if (unrecyclable == items.Count)
                {
                    // No bin at all here: offer an explicit permanent deletion instead of a silent fallback.
                    var ok = await Dialogs.ConfirmAsync("Delete permanently?",
                        $"{RecycleText.Explain(examples[0].Why)} These items cannot be recycled.\n\nDelete {summary} permanently?\n{ExactList(items.Take(8).Select(i => i.Name), total: items.Count)}",
                        "Delete permanently", danger: true);
                    if (!ok) return;
                    permanent = true;
                    confirmedPermanent = true;
                }
            }
            var input = new DeleteDialogInput(items, summary, permanent, hidden, examples.Select(u => (u.Name, RecycleText.Explain(u.Why))).ToList(),
                loc.Scheme == Schemes.ResultSet, permanent ? 0 : unrecyclable);
            if (permanent) input = input with { Unrecyclable = [] };
            // Already confirmed as a permanent deletion, or no confirmation wanted: ask again only about hidden marks.
            if (hidden == 0 && (confirmedPermanent || !permanent && !Services.Settings.ConfirmRecycle && unrecyclable == 0))
                input = input with { SkipDialog = true };
            var choice = input.SkipDialog ? new DeleteDialogResult(false, false) : await OperationDialogs.ShowDeleteAsync(this, input);
            if (choice is null) return;
            finalItems = choice.IncludeHidden || hidden == 0 ? items : tab.Listing.GetSelection(includeHiddenMarks: false);
            var job = Services.Jobs.Submit(new JobRequest
            {
                Kind = permanent ? JobKind.Delete : JobKind.Recycle,
                Sources = finalItems,
                Options = new TransferOptions { PermanentlyDeleteUnrecyclable = choice.DeleteUnrecyclablePermanently },
            });
            submitted = finalItems;
            Track(job, tab);
            tab.Listing.RememberOperation(finalItems);
        }
        finally
        {
            ReleaseUnsubmitted(submitted, items, finalItems);
        }
    }

    private void RemoveFromResultSet()
    {
        var tab = ActiveTab;
        if (tab?.Location is not { Scheme: Schemes.ResultSet } || Services.Providers.For(tab.Location) is not Core.Search.ResultSetProvider rs) return;
        var sel = tab.Listing.GetSelection();
        var set = rs.Get(tab.Location);
        int n = rs.Remove(tab.Location, sel);
        tab.Refresh();
        if (set is { IsWorkingSet: true }) RefreshWorkingSetViews();
        Notify($"Removed {Formatters.Plural(n, "item", "items")} from {(set is { IsWorkingSet: true } w ? $"the working set \"{w.Title}\"" : "the result set")}. Nothing was deleted."
               + (set is { IsWorkingSet: true } ? WorkingSetsReadOnlyNote : string.Empty));
    }

    // ---- Job completion ---------------------------------------------------------------------------------

    private void OnJobFinished(Job job)
    {
        OnEditCommitFinished(job);
        OnExternalClipboardCopyFinished(job);
        OnJobFinishedCore(job);
        OnClipboardMoveFinished(job);
        OnVirtualClipboardCopyFinished(job);
    }

    private void OnJobFinishedCore(Job job)
    {
        Operations.UpdateSummary();
        if (job.Kind == JobKind.StorageTransform && _storageOrigins.Remove(job, out var storageOrigin)) storageOrigin.UnmarkCompleted(job);
        if (_jobOrigins.Remove(job, out var origin))
        {
            var tab = origin.Tab;
            if (origin.Location.Scheme == Schemes.ResultSet) FollowSetChanges(job, origin.Location);
            if (tab.Location == origin.Location && job.Request.Sources.Count > 0 && job.Kind is not (JobKind.CreateDirectory or JobKind.CreateFile or JobKind.StorageTransform))
            {
                // Unmark what the job finished; failed and skipped roots stay marked for a retry.
                try { tab.Listing.MarkItems(job.Request.Sources, job.CompletedRootIndices, false); }
                catch (ObjectDisposedException) { }
            }
            // The tab may have been closed while the job ran: its listing is gone, and so is anything to focus.
            try
            {
                if (_focusAfter.Remove(job, out var focus) && job.State is JobState.Completed or JobState.CompletedWithIssues && tab.Location == origin.Location)
                {
                    tab.Listing.Refresh();
                    if (focus is not null) FocusWhenPresent(tab, focus);
                }
            }
            catch (ObjectDisposedException) { }
        }
        // Permissions change without a new modification time: shown values are read again.
        if (job.Kind == JobKind.Attributes) Services.Metadata.Invalidate();
        else if (job.Kind is not (JobKind.VerifyChecksums or JobKind.VerifyBeside or JobKind.ArchiveTest))
            foreach (var field in Services.Metadata.Fields.Where(f => f.ObservationLane)) Services.Metadata.ForgetField(field.Id);
        // Verifying only reads: nothing to list again (the rows of the files it read ask for their new results).
        if (job.Kind == JobKind.Undo) RefreshAll();
        else if (job.Kind is not (JobKind.VerifyChecksums or JobKind.VerifyBeside)) RefreshAffected(job);
        // The job captured its sources; nothing reads them after this point.
        ItemSources.Release(job.Request.Sources);
        if (_editAfter.Remove(job, out var edit) && File.Exists(edit)) LaunchEditor(edit);
        if (job.Kind == JobKind.StorageTransform)
        {
            InvalidateStorageAccounting();
            var storage = job.StorageResult;
            Notify($"{Formatters.SafeName(job.Title)}: {(storage is null ? "Storage result unavailable." : StorageOperationText.Details(storage))}" +
                (storage?.ReviewPending == true || storage?.PersistenceFault == true ? " Review storage changes in Operations (Ctrl+J)." : ""),
                StorageOperationText.Severity(storage, job.State) == "error");
        }
        else if (job.Kind == JobKind.Undo)
            Notify($"{Formatters.SafeName(job.Title)}: {job.Summary}. Open Undo report in Operations (Ctrl+J) for every outcome.", job.ItemsFailed > 0);
        else if (job.Kind is JobKind.VerifyChecksums or JobKind.VerifyBeside) _ = OnVerifyFinishedAsync(job);
        else switch (job.State)
        {
            case JobState.Completed:
                if (job.Kind == JobKind.ArchiveTest) Notify($"{job.Title}: {job.Summary}.");
                else if (job.Request.Archive is not null) Notify($"{job.Title}: {job.Summary}");
                else if (job.Kind is JobKind.Copy or JobKind.Move or JobKind.Recycle or JobKind.Delete or JobKind.Extract)
                    Notify($"{job.Title}: done{(job.BytesDone > 0 && job.Kind is not (JobKind.Recycle or JobKind.Delete) ? $" ({Formatters.SizeWithUnit(job.BytesDone)})" : "")}.");
                break;
            case JobState.CompletedWithIssues:
            case JobState.Failed:
                Notify($"{job.Title}: {job.State.Describe().ToLowerInvariant()} — {JobIssue.Summarize(job.Issues) ?? job.Summary}  (Ctrl+J shows details)",
                    job.State == JobState.Failed || job.ItemsFailed > 0);
                break;
            case JobState.Canceled:
                string summary = job.Summary.TrimEnd('.', ' ');
                if (job.Request.Archive is not null && job.Issues.Any(issue => issue.Outcome == StepOutcome.Committed))
                    Notify($"{job.Title}: {summary}. The cancellation arrived after the archive was saved; the saved archive is kept.");
                else Notify($"{job.Title}: canceled.{(summary.Length == 0 ? "" : " " + summary + ".")} Steps already completed were kept.");
                break;
        }
        UpdateJobActivity();
        if (_exitWhenIdle && !Services.Jobs.HasActiveWork)
        {
            // A new unsaved edit may have appeared while the operation ran.
            // A canceled close review must also retire this one-shot exit intent.
            _exitWhenIdle = false;
            View.CloseWhenIdle();
        }
    }

    private void FocusWhenPresent(TabViewModel tab, string name)
    {
        if (tab.Listing.FocusName(name)) return;
        void Handler(object? s, ListingChange c)
        {
            if (tab.Listing.FocusName(name) || tab.Listing.State != ListingState.Loading && !tab.Listing.IsRefreshing) tab.Listing.Changed -= Handler;
        }
        tab.Listing.Changed += Handler;
    }

    /// <summary>Refreshes every tab that shows a folder on disk (after changes made outside a job, such as recovery).</summary>
    public void RefreshAll()
    {
        foreach (var p in Workspace.Panels)
        {
            foreach (var t in p.Tabs)
            {
                if (t.Location is { IsFileSystem: true }) t.Refresh();
            }
        }
    }

    /// <summary>Refreshes tabs showing a source or destination folder of the job (watchers also do this).</summary>
    private void RefreshAffected(Job job)
    {
        var folders = new HashSet<Location>();
        // Watchers usually refresh these already; a job spread over very many folders refreshes every folder tab.
        IReadOnlyCollection<Location>? parents;
        try { parents = ItemSources.Parents(job.Request.Sources, 256); }
        catch (ObjectDisposedException) { parents = null; } // released after the job finished (undo later)
        if (parents is not null) folders.UnionWith(parents);
        if (job.Request.Destination is { } d) folders.Add(d);
        // A rebuilt archive changes every folder shown inside it.
        string? archive = job.Request.Archive?.ArchivePath is { } a ? Path.GetFullPath(a) : null;
        if (archive is not null && Path.GetDirectoryName(archive) is { } archiveParent) folders.Add(Location.FileSystem(archiveParent));
        foreach (var p in Workspace.Panels)
        {
            foreach (var t in p.Tabs)
            {
                if (t.Location is { } l && (folders.Contains(l) || l.Scheme == Schemes.ResultSet || StorageIncludesFolder(job, l) || parents is null && l.IsFileSystem ||
                                            archive is not null && l.Scheme is Schemes.Zip or Schemes.Archive && string.Equals(l.Container?.Path, archive, StringComparison.Ordinal)))
                    t.Refresh();
            }
        }
    }

    private bool _exitWhenIdle;

    /// <summary>
    /// Continues an interrupted copy or move with a new job (plan §9.3: reality is inspected, nothing is replayed
    /// blindly). Partial files of the interruption are removed first, sources that no longer exist (already moved)
    /// are left out, and items that already arrived are skipped. False when nothing was started.
    /// </summary>
    public Task<bool> RunInterruptedAgainAsync(InterruptedJob job) => RunInterruptedOwnedAsync(job);

    /// <summary>At exit or sign-out: running jobs stop at their next safe boundary and journal the rest (plan §9.3).</summary>
    public void StopJobsForExit(TimeSpan wait)
    {
        var active = Services.Jobs.Jobs.Where(j => !j.State.IsFinished()).ToList();
        if (active.Count == 0) return;
        foreach (var j in active) j.Cancel();
        var deadline = DateTime.UtcNow + wait;
        while (Services.Jobs.HasActiveWork && DateTime.UtcNow < deadline) Thread.Sleep(25);
    }

    /// <summary>
    /// While jobs run or hex editors hold unsaved work: the optional keep-awake (jobs only), and a shutdown-block
    /// reason naming them at sign-out.
    /// </summary>
    private void UpdateJobActivity()
    {
        int active = Services.Jobs.Jobs.Count(j => !j.State.IsFinished());
        int editors = UnsavedHexEditors().Count;
        Services.Shell.SetKeepAwake(Services.Settings.KeepAwakeDuringJobs && active > 0);
        var reasons = new List<string>();
        if (active > 0) reasons.Add($"FileCat is running {Formatters.Plural(active, "file operation", "file operations")}; signing out interrupts them and FileCat reviews them at the next start.");
        if (editors > 0) reasons.Add($"{Formatters.Plural(editors, "hex editor has", "hex editors have")} unsaved changes.");
        Services.Shell.SetShutdownBlock(NativeOwner(), reasons.Count > 0 ? string.Join(" ", reasons) : null);
    }

    internal void RefreshSessionActivity() => UpdateJobActivity();

    /// <summary>Windows asks before signing out or shutting down: running operations and unsaved edits hold it so Windows can name them.</summary>
    public bool ShouldBlockSessionEnd => Services.Jobs.HasActiveWork || UnsavedHexEditors().Count > 0;

    // ---- Decisions ------------------------------------------------------------------------------------

    private void EnqueueDecision(PendingDecision decision)
    {
        if (decision.Task.IsCompleted || decision.Job.Token.IsCancellationRequested) return;
        // Background work never replaces the user's input surface. The job's persistent attention state and
        // Review decision action remain available in both the compact strip and Operations (Ctrl+J).
        Operations.Refresh(decision.Job);
        Operations.UpdateSummary();
        Notify($"{decision.Job.Title}: a decision is required. Choose Review decision in Operations (Ctrl+J).");
    }

    public async Task ReviewDecisionAsync(Job job)
    {
        if (_showingDecision || job.Decision is not { } pending || pending.Task.IsCompleted) return;
        if (Dialogs.IsOpen)
        {
            Notify("Finish or cancel the open dialog, then review this operation's decision.");
            return;
        }
        _showingDecision = true;
        try
        {
            var decision = await OperationDialogs.ShowDecisionAsync(this, pending);
            pending.Resolve(decision);
        }
        finally
        {
            _showingDecision = false;
            Operations.Refresh(job);
        }
    }

    // ---- View and edit ----------------------------------------------------------------------------------

    private void ViewFocused(bool hex)
    {
        var tab = ActiveTab;
        if (tab?.Location is null || !tab.Listing.TryGetFocused(out var f) || f.Kind == EntryKind.Parent) return;
        var item = tab.Listing.GetItemRef(tab.Listing.FocusedStoreIndex);
        // A row about something else (a change-journal entry): its report.
        if (f.Tag is IReportedEntry reported)
        {
            new Views.ReportWindow("Change journal entry", reported.ReportTitle, _ => Task.FromResult(reported.Report())).Show();
            return;
        }
        if (item.Parent.Scheme == Schemes.Registry && item.Kind == EntryKind.RegistryKey)
        {
            _ = ViewRegistryKeyAsync(item);
            return;
        }
        if (f.IsContainer)
        {
            Notify("F3 views files. Folder sizes are computed with Space.");
            return;
        }
        if (item.Parent.Scheme == Schemes.Registry && item.Kind == EntryKind.RegistryValue)
        {
            ViewRegistryValue(item, hex);
            return;
        }
        // F3 honors a per-type View association; Alt+F3 always uses the internal viewer.
        if (!hex && item.FileSystemPath is { } viewPath && TryLaunchAssociation(Associations.View, viewPath)) return;
        _ = ViewItemAsync(item, f.Name, hex, tab);
    }

    /// <summary>
    /// Opens content once on a bounded device worker (a remote item may connect and ask for a password), and hands it
    /// to the viewer, which owns it from then on. Shutdown cancels queued opens; active calls finish before transfer.
    /// </summary>
    private async Task ViewItemAsync(ItemRef item, string name, bool hex, TabViewModel sourceTab)
    {
        try
        {
            var provider = Services.Providers.For(item.Parent);
            using var readLease = ProviderReadLease.Capture(Services.Providers, [item.Parent]);
            var source = await Services.Io.RunOwned(provider.GetDeviceKey(item.Parent), Core.Threading.IoPriority.Interactive,
                _ => provider.OpenContent(item), Services.Io.StoppingToken);
            if (Services.Io.IsStopped) { source?.Dispose(); return; }
            if (source is null)
            {
                Notify("This item has no viewable content.", true);
                return;
            }
            await ViewerLauncher.OpenWithBrowsing(Services, item, source, hex, sourceTab);
            if (item.Parent.IsFileSystem) Services.RecordFile(item.Parent, item.Name);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or OperationCanceledException)
        {
            Notify($"Cannot view \"{name}\": {DescribeViewError(item, ex)}", ex is not OperationCanceledException);
        }
    }

    internal static string DescribeViewError(ItemRef item, Exception ex)
    {
        if (ex is OperationCanceledException) return "canceled.";
        if (item.Parent.IsFileSystem && (item.Flags & EntryFlags.Link) != 0 && ErrorText.Classify(ex) == "notfound")
            return "The link, its target, or its folder no longer exists. Check the link target in Properties.";
        return ErrorText.Describe(ex);
    }

    private async Task EditFocusedAsync()
    {
        var tab = ActiveTab;
        if (tab?.Location is null || !tab.Listing.TryGetFocused(out var f) || f.Kind == EntryKind.Parent) return;
        var item = tab.Listing.GetItemRef(tab.Listing.FocusedStoreIndex);
        if (item.Parent.Scheme == Schemes.Registry)
        {
            if (item.Kind == EntryKind.RegistryValue) await EditRegistryValueAsync(item);
            else Notify("F4 edits a selected value. Keys have no editable data property; use F7 to create a key or value.");
            return;
        }
        if (f.IsContainer)
        {
            Notify("F4 edits files. Folders have no content to edit.");
            return;
        }
        if (item.Parent.Scheme == Schemes.Archive || ZipWorker(item.Parent))
        {
            await EditNativeArchiveMemberAsync(item);
            return;
        }
        if (item.Parent.Scheme == Schemes.Zip)
        {
            await EditArchiveMemberAsync(item);
            return;
        }
        if (item.Parent.Scheme == Schemes.Sftp)
        {
            await EditRemoteFileAsync(item);
            return;
        }
        if (item.FileSystemPath is not { } path)
        {
            Notify("This location has no editable files. Copy the item to a folder with F5 to edit it.", true);
            return;
        }
        LaunchEditor(path);
        Services.RecordFile(item.Parent, item.Name);
    }

    private void LaunchEditor(string path)
    {
        var configured = Associations.Find(Services.Settings.Associations, Associations.Edit, Path.GetFileName(path)) ?? Services.Settings.Editor;
        if (configured is null && Services.Shell.IsElevated)
        {
            Notify($"FileCat is running {Elevation}, so it will not choose an external editor automatically. Reopen FileCat without elevation to edit this file.", true);
            return;
        }
        if (configured is not null && !AdmitConfiguredExternalTool(configured)) return;
        var tool = configured ?? ToolLauncher.DetectEditor();
        try
        {
            var result = ToolLauncher.Launch(tool, new ToolContext([path], Path.GetDirectoryName(path)!, ActiveTarget()?.Path), Services.Paths.TempDirectory);
            if (result.Warning is not null) Notify(result.Warning);
        }
        catch (ToolLaunchException ex)
        {
            Notify(ex.Message, true);
        }
    }

    private Location? ActiveTarget() => Workspace.ActiveTarget?.ActiveTab?.Location;

    /// <summary>
    /// User settings are writable by the ordinary account, so a high-token process cannot infer who chose a tool. Root on
    /// Linux or macOS, which may read its user's settings (sudo keeps HOME on many systems), is refused the same (review
    /// finding R-M12).
    /// </summary>
    private bool AdmitConfiguredExternalTool(ToolDefinition tool)
    {
        if (!Services.Shell.IsElevated) return true;
        Notify($"FileCat is running {Elevation} and will not launch the configured external tool \"{Formatters.SafeName(tool.Name)}\" from user settings. Reopen FileCat without elevation to use it.", true);
        return false;
    }

    private static string Elevation => OperatingSystem.IsWindows() ? "as administrator" : "as root";

    /// <summary>Runs the per-type association for an intent when one matches the file name; false otherwise.</summary>
    internal bool TryLaunchAssociation(string intent, string path)
    {
        if (Associations.Find(Services.Settings.Associations, intent, Path.GetFileName(path)) is not { } tool) return false;
        if (!AdmitConfiguredExternalTool(tool)) return true;
        try
        {
            var result = ToolLauncher.Launch(tool, new ToolContext([path], Path.GetDirectoryName(path)!, ActiveTarget()?.Path), Services.Paths.TempDirectory);
            if (result.Warning is not null) Notify(result.Warning);
        }
        catch (ToolLaunchException ex)
        {
            Notify(ex.Message, true);
        }
        return true;
    }

    // ---- Clipboard ---------------------------------------------------------------------------------------

    private async Task CopyUncPathsAsync()
    {
        var sel = ActiveTab?.Listing.GetSelection();
        if (sel is null || sel.Count == 0 || View.Clipboard is null) return;
        var lines = ActualUncPaths(sel.Select(s => s.FileSystemPath), Services.Shell.ToUncPath);
        if (lines.Count == 0)
        {
            Notify("None of the selected items has a UNC path. Use Copy full paths for local files.");
            return;
        }
        await View.Clipboard.SetTextAsync(string.Join(Environment.NewLine, lines));
        Notify($"Copied {Formatters.Plural(lines.Count, "UNC path", "UNC paths")} to the clipboard.");
    }

    internal static List<string> ActualUncPaths(IEnumerable<string?> paths, Func<string, string> convert) =>
        paths.Where(p => p is not null).Select(p => convert(p!)).Where(PathUtil.IsUncPath).ToList();

    /// <summary>Handles files dropped onto a panel: the drop target is the explicit destination.</summary>
    internal async Task DropItemsAsync(PanelViewModel panel, DropTargetAdmission.Offer offered,
        TabViewModel sourceTab, Location sourceLocation, IReadOnlyList<ItemRef> items)
    {
        if (items.Count == 0 || items.Count > DragExport.MaxItems || sourceTab.Listing.IsDisposed ||
            sourceTab.Listing.State != ListingState.Complete || sourceTab.Listing.IsPartial ||
            sourceTab.Listing.LastRefreshError is not null || sourceTab.Location != sourceLocation ||
            sourceLocation.Scheme != Schemes.ResultSet && items.Any(i => !i.Parent.Equals(sourceLocation)))
        {
            Notify("The drag source changed or its selection is too large. Select it again.", true);
            return;
        }
        var move = offered.Effect == Avalonia.Input.DragDropEffects.Move;
        var (current, refusal) = DropTargetAdmission.Check(panel, true, move, ownDrag: true, ownItems: true,
            ownSource: sourceLocation, sourceItems: items);
        if (current is null || !DropTargetAdmission.SameTarget(offered, current))
        {
            Notify(current is null ? refusal! : DropTargetAdmission.ChangedTargetMessage, true);
            return;
        }
        if (offered.Destination.IsFileSystem && !await Task.Run(() => Directory.Exists(offered.Destination.Path)))
        {
            Notify("The drop folder is no longer available. Choose another destination.", true);
            return;
        }
        if (sourceLocation.Scheme == Schemes.Registry)
        {
            if (move) { Notify("Dragging Registry items copies them. Use F6 for a reviewed move.", true); return; }
            await CopyRegistryItemsAsync(items, offered.Destination);
            return;
        }
        if (offered.Destination.Scheme == Schemes.Registry)
        {
            Notify("Use File → Import .reg to review a file before changing the Registry.", true);
            return;
        }
        if (sourceLocation.Scheme == Schemes.Computer)
        {
            await DropDriveContentsAsync(items, offered.Destination, move);
            return;
        }
        if (items.All(i => i.Parent.Equals(offered.Destination)))
        {
            Notify("The dropped items are already in this folder.");
            return;
        }
        await TransferAsync(move ? JobKind.Move : JobKind.Copy, items, offered.Destination, sourceTab);
    }

    private async Task DropDriveContentsAsync(IReadOnlyList<ItemRef> items, Location destination, bool move)
    {
        if (move) { Notify("A whole drive can be copied, not moved. Release Shift and drag again.", true); return; }
        if (!destination.IsFileSystem || items.Count != 1 || items[0].Kind != EntryKind.Drive ||
            !OperatingSystem.IsWindows() || items[0].Name.Length != 2 ||
            !char.IsLetter(items[0].Name[0]) || items[0].Name[1] != ':')
        {
            Notify("Select one available Windows drive and drop it onto a local folder.", true);
            return;
        }
        string root = items[0].Name + Path.DirectorySeparatorChar;
        if (!await Task.Run(() => Directory.Exists(root)))
        {
            Notify("The selected drive is no longer available.", true);
            return;
        }
        if (PathUtil.IsSameOrUnder(destination.Path, root))
        {
            Notify("A drive cannot be copied into itself. Choose a folder on another drive.", true);
            return;
        }
        string folderName = "Drive " + char.ToUpperInvariant(items[0].Name[0]);
        if (!await Dialogs.ConfirmAsync("Copy an entire drive",
            $"Copy the contents of {root} into a new “{folderName}” folder at {destination.Path}? This can be very large and may include protected files. Review the destination and job report before relying on the copy.",
            "Review drive copy")) return;
        // An empty child name denotes the root itself; the reviewed new name is the destination folder.
        var source = new ItemRef(Location.FileSystem(root), string.Empty, EntryKind.Directory);
        var request = await OperationDialogs.ShowTransferAsync(this, new TransferDialogInput(JobKind.Copy,
            [source], $"the contents of {root} (size not fully counted)", Path.Combine(destination.Path, folderName),
            "drop target", 0, false) { InitialLocation = destination, BaseLocation = Location.FileSystem(root) });
        if (request?.ResolvedDestination is not { } resolved) return;
        if (!resolved.IsFileSystem || PathUtil.IsSameOrUnder(resolved.Path, root))
        {
            Notify("The reviewed drive destination must be on another local drive.", true);
            return;
        }
        Services.Jobs.Submit(new JobRequest { Kind = JobKind.Copy, Sources = [source], Destination = resolved,
            NewName = request.NewName ?? folderName, Options = request.Options,
            Mode = request.Queue ? QueueMode.Queue : QueueMode.Start });
    }

    /// <summary>Handles files dropped onto a panel: the drop target is the explicit destination.</summary>
    internal async Task DropFilesAsync(PanelViewModel panel, DropTargetAdmission.Offer offered, IReadOnlyList<string> paths)
    {
        // Only FileCat's own drag is offered as a Move.
        bool move = offered.Effect == Avalonia.Input.DragDropEffects.Move;
        // Dragged out of an archive, a server or a device, FileCat drops the copies it made to drag them: moving those
        // would leave the originals where they are.
        if (move && paths.Any(p => Core.Operations.DragStaging.IsStaged(p, Services.Paths.TempDirectory)))
        {
            Notify(DropTargetAdmission.StagedMoveRefusal, true);
            return;
        }
        var (current, refusal) = DropTargetAdmission.Check(panel, paths.Count > 0, move, ownDrag: move);
        if (current is null || !DropTargetAdmission.SameTarget(offered, current))
        {
            Notify(current is null ? refusal! : "The drop target changed during the drag. Drop again onto the folder you want to use.", true);
            return;
        }
        bool available = !offered.Destination.IsFileSystem ||
            await Task.Run(() => Directory.Exists(offered.Destination.Path));
        (current, refusal) = DropTargetAdmission.Check(panel, paths.Count > 0, move, ownDrag: move);
        if (!available || current is null || !DropTargetAdmission.SameTarget(offered, current))
        {
            Notify(!available ? "The drop folder is no longer available. Reconnect or choose another destination with F5."
                : current is null ? refusal! : "The drop target changed during the drag. Drop again onto the folder you want to use.", true);
            return;
        }
        var dest = offered.Destination;
        var items = await Task.Run(() => paths.Select(p => ItemRef.ForFileSystemPath(p,
            Directory.Exists(p) ? EntryKind.Directory : EntryKind.File)).ToList());
        (current, refusal) = DropTargetAdmission.Check(panel, true, move, ownDrag: move);
        if (current is null || !DropTargetAdmission.SameTarget(offered, current))
        {
            Notify(current is null ? refusal! : "The drop target changed during the drag. Drop again onto the folder you want to use.", true);
            return;
        }
        Workspace.Activate(panel);
        if (items.All(i => i.Parent.Equals(dest)))
        {
            Notify("The dropped items are already in this folder.");
            return;
        }
        var request = await OperationDialogs.ShowTransferAsync(this, new TransferDialogInput(move ? JobKind.Move : JobKind.Copy, items, SizeSummary(items),
            AppendSeparator(dest.Path), $"panel {panel.Number} (drop target)", 0, false)
        { BaseLocation = dest, InitialLocation = dest });
        if (request is null) return;
        var destLocation = request.ResolvedDestination;
        var newName = request.NewName;
        if (destLocation is null) { Notify("The destination changed before this transfer was submitted. Review it again.", true); return; }
        Services.Jobs.Submit(new JobRequest { Kind = move ? JobKind.Move : JobKind.Copy, Sources = items, Destination = destLocation, NewName = newName, Options = request.Options, Mode = request.Queue ? QueueMode.Queue : QueueMode.Start });
    }

    // ---- Checksums ---------------------------------------------------------------------------------------

    private async Task ChecksumAsync()
    {
        var sel = ActiveTab?.Listing.GetSelection();
        if (sel is null || sel.Count == 0) return;
        var files = sel.Where(s => !s.IsContainer && s.FileSystemPath is not null).ToList();
        if (files.Count == 0)
        {
            Notify("Checksums are computed for files; mark files or focus one.");
            return;
        }
        // A manifest is recognized, never verified automatically: ask which of the two is meant.
        if (files.All(f => Core.Operations.ChecksumManifests.IsManifestName(f.Name)))
        {
            var choice = await Dialogs.ShowCustomAsync("Checksum manifest",
                new Avalonia.Controls.TextBlock
                {
                    TextWrapping = Avalonia.Media.TextWrapping.Wrap, MaxWidth = 560,
                    Text = (files.Count == 1 ? $"\"{Formatters.SafeName(files[0].Name)}\" lists" : $"These {files.Count:N0} files list")
                           + " checksums of other files. Verify those files against it, or calculate checksums of the manifest itself?",
                },
                [new DialogButton("Cancel", "cancel", IsCancel: true), new DialogButton("Checksum the manifest", "compute"),
                 new DialogButton("Verify listed files", "verify", IsDefault: true)]);
            if (choice as string is null or "cancel") return;
            if (choice as string == "verify")
            {
                await VerifyChecksumsAsync(files);
                return;
            }
        }
        await OperationDialogs.ShowChecksumsAsync(this, files.Select(f => f.FileSystemPath!).ToList());
    }

    private void ConnectDrive(bool connect)
    {
        var error = connect ? Services.Shell.ConnectNetworkDrive(NativeOwner()) : Services.Shell.DisconnectNetworkDrive(NativeOwner());
        if (error is not null) Notify(error, true);
        foreach (var p in Workspace.Panels)
            foreach (var t in p.Tabs)
                if (t.Location?.Scheme == Schemes.Computer) t.Refresh();
    }

    internal nint NativeOwner() => View.TopLevel?.TryGetPlatformHandle()?.Handle ?? 0;

    internal async Task<bool> SignInToServerAsync(string server)
    {
        var error = await Task.Run(() => Services.Shell.SignIn(server, NativeOwner()));
        if (error is null) return true;
        Notify(error, true);
        return false;
    }

    internal void CopyTextToClipboard(string text) => _ = View.Clipboard?.SetTextAsync(text);
}
