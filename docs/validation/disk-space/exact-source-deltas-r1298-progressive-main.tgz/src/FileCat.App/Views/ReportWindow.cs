using System.Globalization;
using System.Text;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using FileCat.App.Controls;
using FileCat.App.Services;
using FileCat.Core.Content;
using FileCat.Core.Resources;

namespace FileCat.App.Views;

/// <summary>
/// A report FileCat writes about an item, such as its file-system record (D-56): read-only text that opens at once and
/// fills in when ready, with Find (Ctrl+F, F3), Wrap (F2), source/display Copy (Ctrl+C: selection or visible lines), Copy all, Save as, and
/// Refresh (F5) to read it again. None of the viewer's modes, encodings, or checksums: there is no file here.
/// </summary>
public sealed partial class ReportWindow : Window
{
    // Screen readers follow a list's focused row and, on Linux, hear focus after window activation.
    protected override Avalonia.Automation.Peers.AutomationPeer OnCreateAutomationPeer() =>
        new FileCat.App.Controls.DescendantFocusWindowAutomationPeer(this);

    private Func<CancellationToken, Task<string>>? _produce;
    private readonly string _subject;
    private readonly string _kind;
    private readonly TextViewer _view = new() { Wrap = false, ReportStyle = true };
    private readonly TextBox _search = new() { PlaceholderText = "Find (Ctrl+F)", MinWidth = 220,
        Classes = { "searchPending" } };
    private readonly CheckBox _matchCase = new() { Content = "Aa", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _wrap = new() { Content = "Wrap", VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _refresh = new() { Content = "Refresh" };
    private readonly Button _copyAll = new() { Content = "Copy all" };
    private readonly Button _copyDisplayed = new() { Content = "Copy displayed text" };
    private readonly Button _save = new() { Content = "Save as…" };
    private readonly WrapPanel _actions = new() { Margin = new Thickness(8, 2), ItemSpacing = 8, LineSpacing = 4 };
    private CancellationTokenSource? _saving;
    private readonly TextBlock _status = new() { Classes = { "small" }, VerticalAlignment = VerticalAlignment.Center, TextTrimming = Avalonia.Media.TextTrimming.CharacterEllipsis };
    private string? _searchNotice;
    private readonly CancellationTokenSource _closing = new();
    private CancellationTokenSource? _reading;
    private CancellationTokenSource? _searching;
    private readonly DispatcherTimer _findTimer = new(DispatcherPriority.Background)
        { Interval = TimeSpan.FromMilliseconds(250) };
    private CancellationTokenSource? _copying;
    private readonly SemaphoreSlim _copyWrites = new(1, 1);
    private readonly ContentCopyNotice _copyNotice = new();
    private readonly Button _copyVisible = new() { Content = "Copy visible source text" };
    private readonly Button _previousLine = new() { Content = "Previous report line" };
    private readonly Button _nextLine = new() { Content = "Next report line" };
    private readonly TextBlock _spokenLine = new() { TextWrapping = Avalonia.Media.TextWrapping.Wrap };
    private const int SpokenSegmentLength = 4096;
    private readonly List<int> _segmentStarts = [];
    private int _lineCount;
    private int _lineIndex;
    private int _lineStart;
    private int _segmentIndex;
    private PagedReader? _reader;
    private string _text = "";
    private long _lastHit = -1;
    private int _lastHitLength;
    private DateTime _readAt;

    /// <param name="title">What the report is ("File-system record").</param>
    /// <param name="subject">What it is about (a path), shown in the window's title and status line.</param>
    /// <param name="produce">Writes the report; run off the UI thread, again on Refresh.</param>
    public ReportWindow(string title, string subject, Func<CancellationToken, Task<string>> produce)
    {
        _produce = produce;
        _subject = subject;
        string name = Path.GetFileName(subject.TrimEnd('\\', '/'));
        Title = $"{(name.Length > 0 ? name : subject)} · {title} — FileCat";
        _kind = title;
        Width = 1000;
        Height = 760;
        WindowFit.Attach(this);
        MinWidth = 480;
        MinHeight = 300;
        try { Icon = new WindowIcon(Avalonia.Platform.AssetLoader.Open(new Uri("avares://FileCat/Assets/filecat.ico"))); } catch (Exception) { }

        Avalonia.Automation.AutomationProperties.SetName(_view, title);
        Avalonia.Automation.AutomationProperties.SetName(_search, "Find in the report");
        ToolTip.SetTip(_refresh, "Read it again (F5)");
        ToolTip.SetTip(_wrap, "Wrap long lines (F2)");
        ToolTip.SetTip(_matchCase, "Match case");
        var copy = _copyAll;
        ToolTip.SetTip(copy, "Copy the complete original report text. Ctrl+C copies selected source text or the visible lines; Ctrl+Shift+C uses displayed text.");
        var displayed = _copyDisplayed;
        ToolTip.SetTip(displayed, "Copy selected text or visible lines with tabs expanded and controls shown as symbols. Visual wraps add no line endings.");
        _copyVisible.Click += async (_, _) => await CopyTextAsync(displayed: false, explicitVisible: true);
        displayed.Click += async (_, _) => await CopyTextAsync(displayed: true, explicitVisible: true);
        var save = _save;
        ToolTip.SetTip(save, "Save the report as a text file");
        var toolbar = new WrapPanel { Margin = new Thickness(8, 4), ItemSpacing = 8, LineSpacing = 4 };
        foreach (var part in new Control[] { _refresh, _search, _matchCase, _wrap, copy, _copyVisible, displayed, save }) toolbar.Children.Add(part);
        var lineActions = new WrapPanel { ItemSpacing = 8, LineSpacing = 4 };
        lineActions.Children.Add(_previousLine);
        lineActions.Children.Add(_nextLine);
        var lineText = new ScrollViewer
        {
            MaxHeight = 84,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = _spokenLine,
        };
        var lineNavigation = new StackPanel { Margin = new Thickness(8, 2, 8, 4), Spacing = 4 };
        lineNavigation.Children.Add(lineActions);
        lineNavigation.Children.Add(lineText);
        AutomationProperties.SetLiveSetting(_spokenLine, AutomationLiveSetting.Polite);
        var statusBar = new Border { Classes = { "status" }, Child = _status };
        var root = new DockPanel();
        var toolbarSurface = ThemeLayers.OpaqueControls(toolbar);
        var navigationSurface = ThemeLayers.OpaqueControls(lineNavigation);
        DockPanel.SetDock(toolbarSurface, Dock.Top);
        DockPanel.SetDock(navigationSurface, Dock.Top);
        DockPanel.SetDock(statusBar, Dock.Bottom);
        root.Children.Add(toolbarSurface);
        DockPanel.SetDock(_actions, Dock.Top);
        root.Children.Add(_actions);
        root.Children.Add(navigationSurface);
        root.Children.Add(statusBar);
        DockPanel.SetDock(_copyNotice, Dock.Bottom);
        root.Children.Add(_copyNotice);
        _copyNotice.StopRequested += () => _copying?.Cancel();
        var surface = new Border { Child = _view };
        root.Children.Add(surface);
        Content = ThemeLayers.Over(root, surface);

        _refresh.Click += async (_, _) => await ReadAsync();
        _previousLine.Click += (_, _) => MoveReportLine(forward: false);
        _nextLine.Click += (_, _) => MoveReportLine(forward: true);
        copy.Click += async (_, _) => await CopyAsync(all: true);
        save.Click += async (_, _) => await SaveAsync();
        _wrap.IsCheckedChanged += (_, _) => _view.Wrap = _wrap.IsChecked == true;
        _view.ContentChanged += () =>
        {
            _copyVisible.Content = _view.HasSelection ? "Copy source selection" : "Copy visible source text";
            if (_view.SelectionEnded is { } ended && !_closing.IsCancellationRequested) _copyNotice.Show(ended);
        };
        _search.KeyDown += async (_, e) =>
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                await FindAsync((e.KeyModifiers & KeyModifiers.Shift) == 0);
            }
            else if (e.Key == Key.Escape)
            {
                e.Handled = true;
                _findTimer.Stop();
                _searching?.Cancel();
                _view.Focus();
            }
        };
        // PropertyChanged retires the old request before an immediate Enter/F3 can start a new one.
        _search.PropertyChanged += (_, e) =>
        {
            if (e.Property != TextBox.TextProperty) return;
            _searching?.Cancel();
            _lastHit = -1;
            _searchNotice = null;
            _view.SetHighlight(null, false);
            ViewerSearchFeedback.Set(_search, null);
            ScheduleFind();
        };
        _matchCase.IsCheckedChanged += (_, _) =>
        {
            _searching?.Cancel();
            _lastHit = -1;
            _searchNotice = null;
            ViewerSearchFeedback.Set(_search, null);
            ScheduleFind();
        };
        _findTimer.Tick += (_, _) => { _findTimer.Stop(); _ = FindCoreAsync(forward: true, automatic: true); };
        AddHandler(KeyDownEvent, OnWindowKeyDown, RoutingStrategies.Tunnel);
        Opened += async (_, _) =>
        {
            _view.Focus();
            await ReadAsync();
        };
        Closed += (_, _) =>
        {
            _findTimer.Stop();
            _closing.Cancel();
            _reading?.Cancel();
            _searching?.Cancel();
            _copying?.Cancel();
            _saving?.Cancel();
            _detailsReader?.Dispose();
            _detailsReader = null;
            _detailsObservation = null;
            var reader = _reader;
            _reader = null;
            _view.SetReader(null, new UTF8Encoding(false), 0);
            _text = "";
            Reading = null;
            _produce = null;
            reader?.Dispose();
        };
    }

    /// <summary>The report's text as shown (tests).</summary>
    public string Text => _text;

    internal string StatusText => _status.Text ?? "";
    internal string SpokenLine => _spokenLine.Text ?? "";

    /// <summary>Where the report is scrolled to, in bytes of its text (tests).</summary>
    internal long TopOffset => _view.TopOffset;

    /// <summary>The reading in progress, if any (tests wait for it).</summary>
    internal Task? Reading { get; private set; }


    private Task ReadAsync() => Reading = _detailsReader is null ? ReadCoreAsync() : ReadDetailsCoreAsync();

    private async Task ReadCoreAsync()
    {
        if (_closing.IsCancellationRequested) return;
        _searchNotice = null;
        // An active producer owns this snapshot until it returns, even if its window closes meanwhile.
        var produce = _produce;
        if (produce is null) return;
        _reading?.Cancel();
        _searching?.Cancel();
        _copying?.Cancel();
        using var cts = _reading = CancellationTokenSource.CreateLinkedTokenSource(_closing.Token);
        var ct = cts.Token;
        _refresh.IsEnabled = false;
        if (_text.Length == 0) Show("Reading…");
        _status.Text = $"Reading {_subject}…";
        try
        {
            string text;
            try
            {
                text = await Task.Run(() => produce(ct), ct);
            }
            catch (Exception) when (ct.IsCancellationRequested)
            {
                return; // closed, or read again
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or InvalidDataException or System.ComponentModel.Win32Exception)
            {
                text = $"It could not be read: {ex.Message}";
            }
            if (ct.IsCancellationRequested || _closing.IsCancellationRequested || !ReferenceEquals(_reading, cts)) return;
            _readAt = DateTime.Now;
            long top = _view.TopOffset;
            Show(text);
            // Refresh keeps the place in the report.
            if (top > 0 && top < Encoding.UTF8.GetByteCount(text)) _view.ScrollToOffset(top);
            UpdateStatus();
        }
        finally
        {
            if (ReferenceEquals(_reading, cts))
            {
                _reading = null;
                if (!_closing.IsCancellationRequested) _refresh.IsEnabled = true;
            }
        }
    }

    private void Show(string text)
    {
        _searching?.Cancel();
        _copying?.Cancel();
        _saving?.Cancel();
        _text = text;
        _lineCount = text.Length == 0 ? 0 : 1 + text.AsSpan(0, text[^1] == '\n' ? text.Length - 1 : text.Length).Count('\n');
        _lineIndex = _lineStart = _segmentIndex = 0;
        _segmentStarts.Clear();
        if (_lineCount > 0) _segmentStarts.Add(0);
        UpdateSpokenLine();
        var old = _reader;
        _reader = new PagedReader(new MemoryContentSource("Report", Encoding.UTF8.GetBytes(text)));
        _view.SetReader(_reader, new UTF8Encoding(false), 0);
        // Its pages count against the shared content budget until it is disposed.
        old?.Dispose();
        _lastHit = -1;
        ViewerSearchFeedback.Set(_search, null);
        ScheduleFind();
    }

    private (int End, int Next) LineBounds()
    {
        int newline = _text.IndexOf('\n', _lineStart);
        int next = newline < 0 ? _text.Length : newline + 1;
        int end = newline < 0 ? _text.Length : newline;
        if (end > _lineStart && _text[end - 1] == '\r') end--;
        return (end, next);
    }

    private int SegmentEnd(int start, int end)
    {
        int last = Math.Min(start + SpokenSegmentLength, end);
        if (last < end && last > start && char.IsHighSurrogate(_text[last - 1]) &&
            char.IsLowSurrogate(_text[last])) last++;
        return last;
    }

    private void MoveReportLine(bool forward)
    {
        if (_lineCount == 0) return;
        var (end, next) = LineBounds();
        if (forward)
        {
            int nextSegment = SegmentEnd(_segmentStarts[_segmentIndex], end);
            if (nextSegment < end)
            {
                if (_segmentIndex + 1 == _segmentStarts.Count) _segmentStarts.Add(nextSegment);
                _segmentIndex++;
            }
            else if (_lineIndex + 1 < _lineCount)
            {
                _lineIndex++;
                _lineStart = next;
                _segmentStarts.Clear();
                _segmentStarts.Add(next);
                _segmentIndex = 0;
            }
        }
        else if (_segmentIndex > 0)
        {
            _segmentIndex--;
        }
        else if (_lineIndex > 0)
        {
            int before = _lineStart - 2;
            _lineStart = before < 0 ? 0 : _text.LastIndexOf('\n', before) + 1;
            _lineIndex--;
            _segmentStarts.Clear();
            _segmentStarts.Add(_lineStart);
            int priorEnd = LineBounds().End;
            while (SegmentEnd(_segmentStarts[^1], priorEnd) < priorEnd)
                _segmentStarts.Add(SegmentEnd(_segmentStarts[^1], priorEnd));
            _segmentIndex = _segmentStarts.Count - 1;
        }
        UpdateSpokenLine();
    }

    private void UpdateSpokenLine()
    {
        if (_lineCount == 0)
        {
            _spokenLine.Text = "No report lines yet.";
            _previousLine.IsEnabled = _nextLine.IsEnabled = false;
            return;
        }
        int end = LineBounds().End;
        int segmentStart = _segmentStarts[_segmentIndex];
        int segmentEnd = SegmentEnd(segmentStart, end);
        string body = segmentStart == end ? "(blank line)" : _text[segmentStart..segmentEnd];
        string part = _segmentIndex > 0 || segmentEnd < end ? $", part {_segmentIndex + 1}" : string.Empty;
        _spokenLine.Text = $"Line {_lineIndex + 1} of {_lineCount}{part}. {Formatters.SafeName(body)}";
        _previousLine.IsEnabled = _lineIndex > 0 || _segmentIndex > 0;
        _nextLine.IsEnabled = _lineIndex + 1 < _lineCount || segmentEnd < end;
    }

    private void UpdateStatus()
    {
        if (_detailsReader is not null) { UpdateDetailsStatus(); return; }
        int lines = _text.Count(c => c == '\n');
        _status.Text = (_searchNotice is { } notice ? notice + " · " : "") +
            $"{_subject} · read at {_readAt.ToString("T", CultureInfo.CurrentCulture)} · {lines.ToString("N0", CultureInfo.CurrentCulture)} lines · F5 reads it again";
    }

    private async void OnWindowKeyDown(object? sender, KeyEventArgs e)
    {
        bool ctrl = (e.KeyModifiers & KeyModifiers.Control) != 0;
        bool shift = (e.KeyModifiers & KeyModifiers.Shift) != 0;
        if (e.Key == Key.Escape && _copying is not null) { e.Handled = true; _copying.Cancel(); return; }
        if (FocusManager?.GetFocusedElement() is TextBox && e.Key is not (Key.F3 or Key.F5 or Key.F10)) return;
        switch (e.Key)
        {
            case Key.Escape:
            case Key.F10:
                Close();
                break;
            case Key.F5:
            case Key.R when ctrl:
                await ReadAsync();
                break;
            case Key.F when ctrl:
            case Key.F7:
                _search.Focus();
                _search.SelectAll();
                break;
            case Key.F3:
                await FindAsync(!shift);
                break;
            case Key.F2:
                _wrap.IsChecked = _wrap.IsChecked != true;
                break;
            case Key.C when ctrl:
                if (shift) await CopyTextAsync(displayed: true, explicitVisible: false);
                else await CopyAsync(all: false);
                break;
            case Key.S when ctrl:
                await SaveAsync();
                break;
            case Key.OemPlus when ctrl:
            case Key.Add when ctrl:
                _view.FontSize += 1;
                break;
            case Key.OemMinus when ctrl:
            case Key.Subtract when ctrl:
                _view.FontSize -= 1;
                break;
            default:
                return;
        }
        e.Handled = true;
    }

    private void ScheduleFind()
    {
        _findTimer.Stop();
        if (!_closing.IsCancellationRequested && !string.IsNullOrEmpty(_search.Text) && _reader is not null)
            _findTimer.Start();
    }

    private Task FindAsync(bool forward) => FindCoreAsync(forward, automatic: false);

    private async Task FindCoreAsync(bool forward, bool automatic)
    {
        _findTimer.Stop();
        _searchNotice = null;
        _searching?.Cancel();
        if (_closing.IsCancellationRequested) return;
        string pattern = _search.Text ?? "";
        if (pattern.Length == 0 || _reader is not { } reader)
        {
            _search.Focus();
            return;
        }
        using var cts = _searching = CancellationTokenSource.CreateLinkedTokenSource(_closing.Token);
        var ct = cts.Token;
        var encoding = new UTF8Encoding(false);
        bool matchCase = _matchCase.IsChecked == true;
        long from = automatic ? 0 : _lastHit >= 0
            ? (forward ? _lastHit + Math.Max(1, _lastHitLength) : _lastHit) : _view.TopOffset;
        try
        {
            (long found, bool wrapped, bool searchedWhole) = await Task.Run(() =>
            {
                long SearchAt(long offset)
                {
                    if (forward) return ContentSearch.FindText(reader, encoding, offset, pattern, matchCase, ct);
                    return ContentSearch.FindTextBackward(reader, encoding, offset, pattern, matchCase, ct);
                }
                long first = SearchAt(from);
                if (first >= 0) return (first, false, false);
                if (automatic || forward && from <= 0 || !forward && from >= reader.Length)
                    return (-1L, false, true);
                long around = SearchAt(forward ? 0 : reader.Length);
                return (around, around >= 0, true);
            }, ct);
            if (ct.IsCancellationRequested || _closing.IsCancellationRequested || !ReferenceEquals(_searching, cts) || !ReferenceEquals(_reader, reader)) return;
            if (found < 0)
            {
                if (searchedWhole)
                {
                    ViewerSearchFeedback.Set(_search, false);
                }
                _status.Text = searchedWhole ? $"\"{pattern}\" was not found in this report."
                    : $"\"{pattern}\" was not found {(forward ? "after" : "before")} this place.";
                return;
            }
            ViewerSearchFeedback.Set(_search, true);
            _lastHit = found;
            _lastHitLength = encoding.GetByteCount(pattern);
            _view.SetHighlight(pattern, matchCase);
            _view.ScrollToOffset(found);
            UpdateStatus();
            if (wrapped)
            {
                _searchNotice = $"Wrapped to {(forward ? "the beginning" : "the end")}. Found \"{pattern}\".";
                UpdateStatus();
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // A newer search, refresh, or closure owns the report now.
        }
        finally
        {
            if (ReferenceEquals(_searching, cts)) _searching = null;
        }
    }

    private async Task CopyAsync(bool all)
    {
        if (!all) { await CopyTextAsync(displayed: false, explicitVisible: false); return; }
        if (_closing.IsCancellationRequested || !CanPublishDetails || Clipboard is not { } clipboard) return;
        _copying?.Cancel();
        using var cts = _copying = CancellationTokenSource.CreateLinkedTokenSource(_closing.Token);
        var ct = cts.Token;
        string text = _text;
        var reader = _reader;
        bool publicationStarted = false;
        bool Current() => !ct.IsCancellationRequested && ReferenceEquals(_copying, cts) && ReferenceEquals(_reader, reader);
        try
        {
            if (text.Contains('\0'))
            {
                _copyNotice.Show("The report contains U+0000 (NUL). Native text clipboards can stop at NUL. Choose Copy displayed text or Save as to preserve the required representation.");
                return;
            }
            await _copyWrites.WaitAsync(ct);
            try { if (!Current()) return; publicationStarted = true; await Avalonia.Input.Platform.ClipboardExtensions.SetTextAsync(clipboard, text); }
            finally { _copyWrites.Release(); }
            if (Current())
            {
                _status.Text = "The whole report is on the clipboard.";
                _copyNotice.Show($"Copied the complete original report: {text.Length:N0} characters. Tabs and logical line endings are preserved.");
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or NotSupportedException or System.Runtime.InteropServices.ExternalException)
        {
            if (Current()) _copyNotice.Show("Copy could not finish: " + ex.Message);
        }
        finally
        {
            if (ReferenceEquals(_copying, cts))
            {
                if (ct.IsCancellationRequested && !_closing.IsCancellationRequested) _copyNotice.Show(ContentCopy.CanceledMessage(publicationStarted));
                _copying = null;
            }
        }
    }

    internal async Task CopyTextAsync(bool displayed, bool explicitVisible, Avalonia.Input.Platform.IClipboard? targetClipboard = null)
    {
        if (_closing.IsCancellationRequested || !CanPublishDetails || (targetClipboard ?? Clipboard) is not { } clipboard) return;
        _copying?.Cancel();
        using var cts = _copying = CancellationTokenSource.CreateLinkedTokenSource(_closing.Token);
        var ct = cts.Token;
        var scope = _view.CaptureCopyScope(explicitVisible);
        bool publicationStarted = false;
        bool Current() => !ct.IsCancellationRequested && ReferenceEquals(_copying, cts) && scope is not null
            && ReferenceEquals(_reader, scope.Reader) && scope.Generation == _view.SourceGeneration;
        try
        {
            if (scope is null) { _copyNotice.Show(_view.SelectionEnded ?? "The current report is still loading. Wait for its text before copying."); return; }
            _copyNotice.Show($"Reading the captured report range: {scope.Length:N0} bytes from offset {scope.Start:N0}…", running: true);
            var result = await Task.Run(() => ContentCopy.Read(scope.Reader, scope.Start, scope.Length,
                displayed ? ContentCopyRepresentation.DisplayedText : ContentCopyRepresentation.SourceText, scope.Encoding, scope.DisplayColumn, scope.Revision, ct), ct);
            if (!Current()) return;
            if (result.CanPublish)
            {
                await _copyWrites.WaitAsync(ct);
                try { if (!Current()) return; publicationStarted = true; await Avalonia.Input.Platform.ClipboardExtensions.SetTextAsync(clipboard, result.Text); }
                finally { _copyWrites.Release(); }
            }
            if (Current()) { string message = result.Describe(scope.Selected); _copyNotice.Show(message); _status.Text = message; }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            if (!_closing.IsCancellationRequested && ReferenceEquals(_copying, cts)) _copyNotice.Show(ContentCopy.CanceledMessage(publicationStarted));
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or NotSupportedException or System.Runtime.InteropServices.ExternalException)
        {
            if (Current()) _copyNotice.Show("Copy could not finish: " + ex.Message);
        }
        finally
        {
            if (ReferenceEquals(_copying, cts))
            {
                if (ct.IsCancellationRequested && !_closing.IsCancellationRequested) _copyNotice.Show(ContentCopy.CanceledMessage(publicationStarted));
                _copying = null;
            }
        }
    }

    private async Task SaveAsync()
    {
        if (_closing.IsCancellationRequested || !CanPublishDetails) return;
        _saving?.Cancel();
        using var cts = _saving = CancellationTokenSource.CreateLinkedTokenSource(_closing.Token);
        var ct = cts.Token;
        string capturedText = _text;
        var capturedReader = _reader;
        try
        {
            string stem = Path.GetFileName(_subject.TrimEnd('\\', '/'));
            var picked = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Save the report as a text file",
                SuggestedFileName = $"{(stem.Length > 0 ? stem : "report")} - {_kind}.txt",
                DefaultExtension = "txt",
                FileTypeChoices = [new FilePickerFileType("Text") { Patterns = ["*.txt"] }],
            });
            if (ct.IsCancellationRequested || !ReferenceEquals(_reader, capturedReader) || picked?.TryGetLocalPath() is not { } target) return;
            await File.WriteAllTextAsync(target, capturedText, new UTF8Encoding(true), ct);
            if (!ct.IsCancellationRequested) _status.Text = $"Saved as {target}.";
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            _status.Text = $"It could not be saved: {ex.Message}";
        }
        finally { if (ReferenceEquals(_saving, cts)) _saving = null; }
    }
}
