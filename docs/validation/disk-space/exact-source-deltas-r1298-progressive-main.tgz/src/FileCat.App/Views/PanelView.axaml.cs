using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Threading;
using Avalonia.VisualTree;
using FileCat.App.Controls;
using FileCat.App.Services;
using FileCat.App.ViewModels;
using FileCat.Core.Commands;
using FileCat.Core.Listing;

namespace FileCat.App.Views;

public partial class PanelView : UserControl
{
    private bool _addressCompact;
    private ContextMenu? _ancestorMenu;
    private ContextMenu? _sortMenu;
    internal ContextMenu? SortMenu => _sortMenu;
    private static ContextMenu? _openItemMenu;
    private static long _menuRequest;
    private static bool _nativeMenuWarningShown;

    public PanelView()
    {
        InitializeComponent();
        // Avalonia's Linux AT-SPI bridge exposes only selection-item descendants
        // of a list, so the inline TextBox must live beside the list in that tree.
        if (OperatingSystem.IsLinux()) List.PlaceRenameEditorIn(RenameOverlay);
        LiveRegions.Watch(FilterAnnouncement);
        AddressRow.SizeChanged += (_, _) => UpdateAddressDensity();
        StatusBar.SizeChanged += (_, e) => StatusRightText.MaxWidth = Math.Max(120, e.NewSize.Width * 0.45);
        List.ActivateRequested += (_, _) => Activated?.Invoke();
        List.OpenRequested += (_, _) => OpenRequested?.Invoke();
        List.RenameRequested += (_, _) => RenameRequested?.Invoke();
        List.MiddleClickRequested += (_, row) => MiddleClick?.Invoke(row);
        List.ContextMenuRequested += (_, point) => ShowContextMenu(point: point, extended: List.ContextWithShift);
        List.InspectRequested += (_, report) => _ = ShowInspectionAsync(report);
        AutomationProperties.SetHelpText(List, "Ctrl+Shift+I inspects every full value in the focused row. Shift+F10 opens item actions.");
        List.BackgroundContextRequested += (_, point) => ShowBackgroundContextMenu(point, List.ContextWithShift);
        List.HeaderContextRequested += (_, _) => ShowHeaderContextMenu();
        List.GotFocus += (_, _) => Activated?.Invoke();
        // The number, or the tab strip beside the tabs, moves the whole panel.
        NumberBadge.PointerPressed += (_, e) =>
        {
            MoveRequested?.Invoke(e, NumberBadge);
            e.Handled = true;
        };
        // A tab's button takes its press (it clicks on release), so the strip asks to see handled presses too.
        TabStrip.AddHandler(PointerPressedEvent, OnTabPointerPressed, RoutingStrategies.Bubble, handledEventsToo: true);
        TabHeader.PointerPressed += (_, e) =>
        {
            if (e.Source is Visual source && source.FindAncestorOfType<Button>(includeSelf: true) is null) MoveRequested?.Invoke(e, TabHeader);
        };
        PathBox.GotFocus += (_, _) =>
        {
            Activated?.Invoke();
            Dispatcher.UIThread.Post(PathBox.SelectAll, DispatcherPriority.Input);
        };
        // Typing a path suggests the folders that complete it (not while the box shows where the panel is); its keys
        // come first in OnPathKeyDown.
        _completion = new PathCompletion(PathBox, AddressRow, () => Panel?.Services.Settings.ShowHidden == true, () => Panel?.ActiveTab?.DisplayPath,
            handleKeys: false);
        _completion.Chosen += path => PathSubmitted?.Invoke(path);
        PathBox.LostFocus += (_, _) =>
        {
            RevertPath();
            PathLinks.IsVisible = true;
            PathBox.Classes.Add("linked");
        };
        PathBox.GotFocus += (_, _) =>
        {
            PathLinks.IsVisible = false;
            PathBox.Classes.Remove("linked");
        };
        PathLinks.NavigateRequested += OnPathPartChosen;
        PathLinks.EditRequested += () =>
        {
            Activated?.Invoke();
            FocusPathBox();
        };
        PathLinks.CopyRequested += text => _ = CopyToClipboardAsync(text);
        PathLinks.MenuRequested += ShowPathMenu;
        FilterBox.AddHandler(KeyDownEvent, OnFilterKeyDown, RoutingStrategies.Tunnel);
        FilterBox.GotFocus += (_, _) =>
        {
            Activated?.Invoke();
            Dispatcher.UIThread.Post(FilterBox.SelectAll, DispatcherPriority.Input);
        };
        FilterBox.LostFocus += (_, _) =>
        {
            if (_hookedTab is { } tab) tab.FilterValidationError = null;
            ShowFilter(force: true);
        };
        PathBox.AddHandler(KeyDownEvent, OnPathKeyDown, RoutingStrategies.Tunnel);
        DataContextChanged += (_, _) =>
        {
            HookQuickView();
            ShowActiveTab();
            HookTab();
            // The Places tree is built directly, not through bindings. A retired panel must release its
            // buttons and borrowed icons even when hidden; a layout-only detach keeps its live context.
            BuildPlaceButtons();
        };
        // Resizing the panel or adding tabs can make the tabs fit, or not.
        TabScroller.ScrollChanged += (_, _) => UpdateTabOverflow();
        AttachedToVisualTree += (_, _) =>
        {
            if (TopLevel.GetTopLevel(this)?.DataContext is not MainViewModel vm) return;
            _main = vm;
            vm.PlacesChanged += OnPlacesChanged;
            if (vm.Services.Icons.Native is { } native) native.IconsLoaded += OnIconsLoaded;
            vm.Services.Icons.Cleared += OnIconsLoaded;
            ThemeManager.ThemeChanged += OnThemeChanged;
            BuildPlaceButtons(force: true);
        };
        DetachedFromVisualTree += (_, _) =>
        {
            if (_main is not null)
            {
                _main.PlacesChanged -= OnPlacesChanged;
                if (_main.Services.Icons.Native is { } native) native.IconsLoaded -= OnIconsLoaded;
                _main.Services.Icons.Cleared -= OnIconsLoaded;
                ThemeManager.ThemeChanged -= OnThemeChanged;
            }
            _main = null;
        };
        // The mouse's back and forward buttons go through this panel's history, wherever in the panel they are pressed.
        AddHandler(PointerPressedEvent, OnHistoryButton, RoutingStrategies.Tunnel, handledEventsToo: true);
        // A press anywhere in a panel makes it the source (and, with two panels, the other one the target).
        AddHandler(PointerPressedEvent, OnAnyPress, RoutingStrategies.Tunnel, handledEventsToo: true);
    }

    private void UpdateAddressDensity()
    {
        bool compact = AddressRow.Bounds.Width < 480;
        if (_addressCompact == compact) return;
        _addressCompact = compact;
        // The location uses the whole middle span when secondary details move below it.
        Grid.SetColumnSpan(PathCell, compact ? 3 : 1);
        Grid.SetRow(FreeSpaceLabel, compact ? 1 : 0);
        Grid.SetColumn(FreeSpaceLabel, compact ? 2 : 3);
        Grid.SetRow(FilterBox, compact ? 1 : 0);
        Grid.SetRow(FilterError, compact ? 2 : 1);
        FreeSpaceLabel.MaxWidth = compact ? 130 : 170;
    }

    private void OnPlacesChanged() => BuildPlaceButtons();

    /// <summary>
    /// A press anywhere in the panel (its list, tabs, path, place buttons, or status line) makes it the source panel,
    /// and the keyboard follows when it was in another panel. "Set as target" on another panel is the exception: it
    /// changes where F5 and F6 go and the keyboard stays where it is.
    /// </summary>
    private void OnAnyPress(object? sender, PointerPressedEventArgs e)
    {
        if (!PointerActivates(e.Source) || Panel is not { } panel) return;
        if (!panel.IsActive) Activated?.Invoke();
        // After the press is handled: a press that gave the keyboard to something here (the path box, a rename) keeps it.
        Dispatcher.UIThread.Post(() =>
        {
            if (FocusIsInAnotherPanel() is not false) List.Focus();
        }, DispatcherPriority.Input);
    }

    internal bool PointerActivates(object? source) => Panel is { } panel &&
        !(source is Visual visual && visual.FindAncestorOfType<Button>(includeSelf: true) is { } button &&
          ReferenceEquals(button, RoleButton) && panel.OffersTarget);

    /// <summary>
    /// Whether the keyboard is in another panel of this window: false when it is in this one or elsewhere in the window
    /// (the command line, say), null when nothing has it (a press on something that takes no keyboard clears it).
    /// </summary>
    private bool? FocusIsInAnotherPanel()
    {
        if (TopLevel.GetTopLevel(this)?.FocusManager?.GetFocusedElement() is not Visual focused) return null;
        if (ReferenceEquals(focused, this) || this.IsVisualAncestorOf(focused)) return false;
        return focused.FindAncestorOfType<PanelView>() is not null;
    }

    private void OnHistoryButton(object? sender, PointerPressedEventArgs e)
    {
        var kind = e.GetCurrentPoint(this).Properties.PointerUpdateKind;
        if (kind is not (PointerUpdateKind.XButton1Pressed or PointerUpdateKind.XButton2Pressed)) return;
        e.Handled = true;
        Activated?.Invoke();
        if (Panel?.ActiveTab is not { } tab) return;
        if (kind == PointerUpdateKind.XButton1Pressed)
        {
            if (tab.CanGoBack) tab.GoBack();
        }
        else if (tab.CanGoForward) tab.GoForward();
    }

    private PanelViewModel? _hookedPanel;
    private PanelViewModel? _hookedSource;
    private MainViewModel? _main;

    private string? _placesShown;
    private IReadOnlyList<Place> _allBarPlaces = [];

    /// <summary>
    /// The place buttons (D-52, D-53): everything the location menu (Alt+F1, Alt+F2) offers, one button each, in its
    /// order and groups: drives with their letters (on Linux and macOS the mount point's name), This PC, phones, working
    /// sets, the Registry, the home and special folders, then bookmarks and saved servers by name. A click opens the
    /// place in this panel, a middle click in a new tab; the right button offers both and a place's other views. They
    /// are made anew only when what they show changed, or their icons did.
    /// </summary>
    private void BuildPlaceButtons(bool force = false)
    {
        if (_main is not { } vm || Panel is null)
        {
            ClearPlaceButtons();
            _placesShown = null;
            return;
        }
        var all = vm.BarPlaces();
        bool compact = vm.Services.Settings.CompactPlaces;
        var places = PlaceBarPolicy.Select(all, vm.Services.Settings.PinnedPlaces ?? [], compact);
        string shown = compact + "\n" + string.Join("\n", all.Select(p => $"{p.Group}|{p.Title}|{p.Detail}|{p.BarLabel}|{p.Location}|{p.Location?.Session}")) +
            "\nVisible:" + string.Join("|", places.Select(PlaceBarPolicy.Key));
        if (!force && shown == _placesShown)
        {
            MarkCurrentPlace();
            return;
        }
        _placesShown = shown;
        ClearPlaceButtons();
        _allBarPlaces = all;
        PlaceGroup? group = null;
        foreach (var place in places)
        {
            if (group is { } previous && previous != place.Group) DriveButtonsPanel.Children.Add(new Border { Classes = { "placeGap" } });
            group = place.Group;
            DriveButtonsPanel.Children.Add(PlaceButton(place, compact));
        }
        // Last: the places that do not fit the row.
        var more = new Button { Classes = { "drive" }, Content = new TextBlock { Text = "»", FontWeight = Avalonia.Media.FontWeight.Bold, VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center } };
        ToolTip.SetTip(more, "More places: those the row has no room for");
        Avalonia.Automation.AutomationProperties.SetName(more, "More places");
        more.Click += (_, _) => ShowMorePlaces(more);
        DriveButtonsPanel.Children.Add(more);
        MarkCurrentPlace();
    }

    private void ClearPlaceButtons()
    {
        // A detached panel's last composition can still retain its controls. Drop the borrowed images and
        // Place payloads explicitly; the shared icon provider owns the bitmaps, so never dispose them here.
        foreach (var button in DriveButtonsPanel.Children.OfType<Button>())
        {
            if (button.Content is StackPanel content)
                foreach (var image in content.Children.OfType<Image>()) image.Source = null;
            button.Content = null;
            button.Tag = null;
            button.ContextMenu?.Close();
            button.ContextMenu = null;
            ToolTip.SetTip(button, null);
            button.Click -= OnPlaceClick;
            button.PointerReleased -= OnPlacePointerReleased;
            button.ContextRequested -= OnPlaceContextRequested;
        }
        DriveButtonsPanel.Children.Clear();
        _allBarPlaces = [];
    }

    /// <summary>The » button lists every omitted destination, including compact-mode omissions and overflow.</summary>
    private void ShowMorePlaces(Button more)
    {
        var items = new List<Control>();
        PlaceGroup? group = null;
        var visible = DriveButtonsPanel.Children.OfType<Button>()
            .Where(button => !DriveButtonsPanel.Hidden.Contains(button))
            .Select(button => button.Tag).OfType<Place>().Select(PlaceBarPolicy.Key)
            .ToHashSet(StringComparer.Ordinal);
        foreach (var place in _allBarPlaces.Where(place => !visible.Contains(PlaceBarPolicy.Key(place))))
        {
            if (group is { } previous && previous != place.Group) items.Add(new Separator());
            group = place.Group;
            var item = new MenuItem { Header = place.Title };
            if (place.Icon() is { } image) item.Icon = new Image { Source = image, Width = 16, Height = 16 };
            ToolTip.SetTip(item, place.Detail);
            item.Click += (_, _) => OpenPlace(place, newTab: false);
            items.Add(item);
        }
        if (_main is { } vm && _allBarPlaces.Count > 0)
        {
            if (items.Count > 0) items.Add(new Separator());
            var pinMenu = new MenuItem { Header = "Pin places to bar" };
            var choices = new List<Control>();
            foreach (var place in _allBarPlaces)
            {
                bool pinned = vm.Services.Settings.PinnedPlaces?.Contains(PlaceBarPolicy.Key(place), StringComparer.Ordinal) == true;
                var choice = new MenuItem { Header = place.Title, ToggleType = MenuItemToggleType.CheckBox, IsChecked = pinned,
                    IsEnabled = !vm.Services.SettingsReadOnly };
                ToolTip.SetTip(choice, place.Detail);
                choice.Click += (_, _) =>
                {
                    if (!vm.SetPlacePinned(place, !pinned)) choice.IsChecked = pinned;
                };
                choices.Add(choice);
            }
            pinMenu.ItemsSource = choices;
            items.Add(pinMenu);
            if (vm.Services.Settings.PinnedPlaces is { Count: > 0 })
            {
                var clear = new MenuItem { Header = "Clear pinned Places", IsEnabled = !vm.Services.SettingsReadOnly };
                clear.Click += (_, _) => vm.ClearPlacePins();
                items.Add(clear);
            }
        }
        if (items.Count > 0)
        {
            more.ContextMenu = new ContextMenu { ItemsSource = items };
            more.ContextMenu.Open(more);
        }
    }

    private Button PlaceButton(Place place, bool compact)
    {
        var content = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Spacing = 3 };
        if (place.Icon() is { } image) content.Children.Add(new Image { Source = image, Width = 16, Height = 16 });
        string? barLabel = place.BarLabel is { Length: > 0 } label ? label : compact ? place.Title : null;
        if (barLabel is { Length: > 0 })
            content.Children.Add(new TextBlock
            {
                Text = barLabel,
                MaxWidth = compact ? 95 : 120,
                TextTrimming = Avalonia.Media.TextTrimming.CharacterEllipsis,
                VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center,
            });
        var button = new Button { Classes = { "drive" }, Content = content, Tag = place };
        var tip = new Controls.RichTip(place.Title, detail: place.Detail, hints:
        [
            place.BarTip,
            place.OpensInPanel ? "Middle-click opens it in a new tab" : null,
            OperatingSystem.IsWindows() && place.Drive is not null ? "Right-click for drive properties" : null,
            place.Variants.Count > 0 ? "Right-click offers: " + string.Join(", ", place.Variants.Select(v => v.Title)) : null,
        ]);
        ToolTip.SetTip(button, tip);
        Avalonia.Automation.AutomationProperties.SetName(button, place.Title);
        Avalonia.Automation.AutomationProperties.SetHelpText(button, tip.Text);
        button.Click += OnPlaceClick;
        button.PointerReleased += OnPlacePointerReleased;
        button.ContextRequested += OnPlaceContextRequested;
        return button;
    }

    private void OnPlaceClick(object? sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: Place place }) OpenPlace(place, newTab: false);
    }

    private void OnPlacePointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (e.InitialPressMouseButton != MouseButton.Middle || sender is not Button { Tag: Place { OpensInPanel: true } place }) return;
        OpenPlace(place, newTab: true);
        e.Handled = true;
    }

    private void OnPlaceContextRequested(object? sender, ContextRequestedEventArgs e)
    {
        if (sender is not Button { Tag: Place place } button) return;
        e.Handled = true;
        PlaceMenu(place).Open(button);
    }

    /// <summary>A place button's menu: here or in a new tab, and the place's other views.</summary>
    internal ContextMenu PlaceMenu(Place place)
    {
        var items = new List<Control>();
        void Add(string header, Action act)
        {
            var item = new MenuItem { Header = header };
            item.Click += (_, _) => act();
            items.Add(item);
        }
        Add(place.OpensInPanel ? "Open here" : "Open", () => OpenPlace(place, newTab: false));
        if (place.OpensInPanel) Add("Open in a new tab", () => OpenPlace(place, newTab: true));
        if (place.Variants.Count > 0) items.Add(new Separator());
        foreach (var variant in place.Variants) Add(variant.Title, () => OpenPlace(variant, newTab: false));
        if (OperatingSystem.IsWindows() && place.Drive is { } drive && _main is { } vm)
        {
            items.Add(new Separator());
            Add("Drive properties", () => vm.ShowPropertiesForPath(drive.RootPath));
        }
        if (_main is { } main)
        {
            items.Add(new Separator());
            bool pinned = main.Services.Settings.PinnedPlaces?.Contains(PlaceBarPolicy.Key(place), StringComparer.Ordinal) == true;
            var pin = new MenuItem { Header = pinned ? "Unpin from Places bar" : "Pin to Places bar",
                IsEnabled = !main.Services.SettingsReadOnly };
            pin.Click += (_, _) => main.SetPlacePinned(place, !pinned);
            items.Add(pin);
        }
        return new ContextMenu { ItemsSource = items };
    }

    private bool _iconsPending;

    /// <summary>
    /// The platform's icons load in the background, and are made anew when settings apply (Shell pictures on or off): the
    /// buttons take them when they arrive or change (once per batch).
    /// </summary>
    private void OnIconsLoaded()
    {
        if (_iconsPending) return;
        _iconsPending = true;
        Dispatcher.UIThread.Post(() =>
        {
            _iconsPending = false;
            BuildPlaceButtons(force: true);
        }, DispatcherPriority.Background);
    }

    // One rebuild with the icons made anew for the theme (the same batch as theirs).
    private void OnThemeChanged() => OnIconsLoaded();

    private void OpenPlace(Place place, bool newTab)
    {
        Activated?.Invoke();
        if (_main is { } vm && Panel is { } panel) vm.OpenPlace(panel, place, newTab);
    }

    /// <summary>
    /// The button of where this panel is, outlined: its drive, This PC, phones, the Registry, a server, or a folder
    /// or bookmark it shows exactly.
    /// </summary>
    private void MarkCurrentPlace()
    {
        var at = Panel?.ActiveTab?.Location;
        string? root = MainViewModel.DriveRootOf(at)?.TrimEnd('\\', '/');
        var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
        foreach (var button in DriveButtonsPanel.Children.OfType<Button>())
        {
            bool current = at is not null && button.Tag is Place { Location: { } place } p && (p.Drive is not null
                ? root is not null && string.Equals(place.Path.TrimEnd('\\', '/'), root, comparison) && (root.Length > 0 || place.Path == "/")
                : place.Scheme switch
                {
                    Core.Resources.Schemes.FileSystem => at.IsFileSystem && string.Equals(Core.FileSystem.PathUtil.NormalizeForCompare(at.Path),
                        Core.FileSystem.PathUtil.NormalizeForCompare(place.Path), Core.FileSystem.PathUtil.SafetyComparison),
                    Core.Resources.Schemes.Computer or Core.Resources.Schemes.Mtp or Core.Resources.Schemes.Registry or Core.Resources.Schemes.Network => at.Scheme == place.Scheme,
                    Core.Resources.Schemes.Sftp or Core.Resources.Schemes.Ftp => at.Scheme == place.Scheme && at.Session == place.Session,
                    _ => at.Equals(place),
                });
            button.Classes.Set("current", current);
        }
    }

    /// <summary>Keeps the quick-view pane attached to the source panel's current tab.</summary>
    private void HookQuickView()
    {
        if (_hookedPanel is not null)
        {
            _hookedPanel.PropertyChanged -= OnPanelPropertyChanged;
            _hookedPanel.Tabs.CollectionChanged -= OnTabsChanged;
        }
        _hookedPanel = Panel;
        if (_hookedPanel is not null)
        {
            _hookedPanel.PropertyChanged += OnPanelPropertyChanged;
            // A tab moved along the strip (dragged, or Ctrl+Shift+PageUp) stays in sight when the tabs do not all fit.
            _hookedPanel.Tabs.CollectionChanged += OnTabsChanged;
        }
        AttachQuickView();
    }

    private void OnTabsChanged(object? sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
    {
        if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Move) ShowActiveTab();
    }

    private void OnPanelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(PanelViewModel.QuickViewSource)) AttachQuickView();
        else if (e.PropertyName == nameof(PanelViewModel.ActiveTab))
        {
            ShowActiveTab();
            HookTab();
        }
    }

    private TabViewModel? _hookedTab;

    /// <summary>The path line follows the active tab's location.</summary>
    private void HookTab()
    {
        var next = Panel?.ActiveTab;
        if (ReferenceEquals(_hookedTab, next)) return;
        if (_hookedTab is not null)
        {
            _hookedTab.PropertyChanged -= OnTabPropertyChanged;
            _hookedTab.FilterValidationError = null;
        }
        _hookedTab = next;
        if (_hookedTab is not null) _hookedTab.PropertyChanged += OnTabPropertyChanged;
        UpdateFilterErrorName();
        UpdatePathLinks();
        ShowFilter(force: true);
        MarkCurrentPlace();
    }

    private void OnTabPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(TabViewModel.DisplayPath) or nameof(TabViewModel.Location))
        {
            UpdatePathLinks();
            MarkCurrentPlace();
            ShowFilter(force: true);
        }
        else if (e.PropertyName == nameof(TabViewModel.FilterText)) ShowFilter();
        else if (e.PropertyName == nameof(TabViewModel.FilterValidationError)) UpdateFilterErrorName();
    }

    private void UpdateFilterErrorName()
    {
        // The visible error can become hidden and unnamed as its binding clears.
        // Avalonia.Native aborts on a nil live-region name, so only the stable
        // and always named announcement node owns the live event.
        var error = _hookedTab?.FilterValidationError;
        string announcement = string.IsNullOrWhiteSpace(error) ? "Filter ready" : error;
        AutomationProperties.SetName(FilterError, announcement);
        FilterAnnouncement.Text = announcement;
    }

    /// <summary>What shows everything: "*.*" on Windows, as Salamander and Total Commander write it; "*" elsewhere.</summary>
    public static string AllItemsMask => OperatingSystem.IsWindows() ? "*.*" : "*";

    /// <summary>The filter box shows the tab's filter (or the mask for everything), and stands out while it filters.</summary>
    private void ShowFilter(bool force = false)
    {
        if (FilterBox.IsFocused && !force) return;
        string? filter = Panel?.ActiveTab?.FilterText;
        FilterBox.Text = filter ?? AllItemsMask;
        FilterBox.Classes.Set("active", filter is not null);
    }

    private void OnFilterKeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            if (Panel?.ActiveTab?.SetFilter(FilterBox.Text) == true) List.Focus();
        }
        else if (e.Key == Key.Escape)
        {
            e.Handled = true;
            var tab = Panel?.ActiveTab;
            if (tab is not null) tab.FilterValidationError = null;
            ShowFilter(force: true);
            List.Focus();
            // On macOS the AX row can regain keyboard focus without VoiceOver
            // speaking it. Announce only after focus settles, and only while the
            // same tab still owns the list; a later user action must win.
            if (OperatingSystem.IsMacOS() && tab is not null &&
                TopLevel.GetTopLevel(this) is MainWindow window)
                Dispatcher.UIThread.Post(() =>
                {
                    if (ReferenceEquals(Panel?.ActiveTab, tab))
                        window.AnnounceRestoredRowIfCurrent(List);
                }, DispatcherPriority.Background);
        }
    }

    /// <summary>
    /// The path with each folder up to it a link: the folders come from the location's parents (so archives, servers,
    /// and the Registry work as folders do), as long as each one's path begins the path shown.
    /// </summary>
    private void UpdatePathLinks()
    {
        var tab = Panel?.ActiveTab;
        string text = tab?.DisplayPath ?? "";
        var segments = new List<PathLine.Segment>();
        if (tab?.Location is { } location && Panel?.Services.Providers is { } providers)
        {
            var comparison = OperatingSystem.IsWindows() || OperatingSystem.IsMacOS() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            int guard = 0;
            for (var p = location; p is not null && p.Scheme != Core.Resources.Schemes.Computer && guard++ < 256; p = providers.For(p).GetParent(p))
            {
                string shown = providers.For(p).GetDisplayPath(p);
                // A root keeps its separator ("C:\", "/"); a folder's part ends at its name.
                string part = shown.Length > 1 && !shown.EndsWith(":\\", StringComparison.Ordinal) ? shown.TrimEnd('\\', '/') : shown;
                if (part.Length == 0 || !text.StartsWith(part, comparison) || (segments.Count > 0 && part.Length >= segments[0].End)) break;
                segments.Insert(0, new PathLine.Segment(part.Length, p));
            }
            // The location itself always ends at the text's end.
            if (segments.Count > 0 && segments[^1].Target == location && segments[^1].End != text.Length)
                segments[^1] = segments[^1] with { End = text.Length };
        }
        PathLinks.SetPath(text, segments);
    }

    /// <summary>A folder up the path was clicked: the panel goes there, with the folder it came from under the cursor.</summary>
    private void OnPathPartChosen(Core.Resources.Location target, bool newTab)
    {
        Activated?.Invoke();
        if (Panel is not { } panel || panel.ActiveTab is not { } tab) return;
        if (newTab)
        {
            panel.OpenTab(target);
            List.Focus();
            return;
        }
        var segments = PathLinks.Segments;
        int index = segments.ToList().FindIndex(s => s.Target == target);
        string? focus = index >= 0 && index + 1 < segments.Count ? panel.Services.Providers.For(segments[index + 1].Target).GetNameInParent(segments[index + 1].Target) : null;
        tab.Navigate(target, focus);
        List.Focus();
    }

    private async Task CopyToClipboardAsync(string text)
    {
        if (TopLevel.GetTopLevel(this)?.Clipboard is not { } clipboard) return;
        await Avalonia.Input.Platform.ClipboardExtensions.SetTextAsync(clipboard, text);
        if (TopLevel.GetTopLevel(this)?.DataContext is MainViewModel vm) vm.Notify("Copied " + text);
    }

    /// <summary>One explicit keyboard stop exposes every provider-derived ancestor and its actions.</summary>
    public bool OpenAncestorMenu()
    {
        if (Panel is not { } panel || panel.ActiveTab is not { Location: { } origin } tab) return false;
        var segments = PathLinks.Segments;
        if (segments.Count < 2) return false;
        _ancestorMenu?.Close();
        var focused = tab.Listing.FocusedStoreIndex;
        Core.Resources.ItemRef? originalItem = focused >= 0 && tab.Listing.TryGetFocused(out var entry)
            ? tab.Listing.GetItemRef(focused) : null;
        var items = new List<MenuItem>();
        bool Current() => ReferenceEquals(Panel, panel) && ReferenceEquals(panel.ActiveTab, tab)
            && Equals(tab.Location, origin);
        void Run(Action action)
        {
            if (!Current())
            {
                _main?.Notify("The path changed. Open the ancestor menu again for the current location.");
                return;
            }
            action();
        }
        for (int i = segments.Count - 2; i >= 0; i--)
        {
            var segment = segments[i];
            string path = PathLinks.PathUpTo(i);
            string safePath = Formatters.SafeName(path);
            string name = Formatters.SafeName(PathLinks.NameOf(i));
            var group = new MenuItem
            {
                Header = new TextBlock { Text = name.Length > 0 ? name : safePath, MaxWidth = 380,
                    TextTrimming = Avalonia.Media.TextTrimming.CharacterEllipsis },
                ItemsSource = new[]
                {
                    CreateAction("Open here", Core.Commands.CommandIds.Parent, () => Run(() => OnPathPartChosen(segment.Target, false)), safePath),
                    CreateAction("Open in new tab", Core.Commands.CommandIds.NewTab, () => Run(() => OnPathPartChosen(segment.Target, true)), safePath),
                    CreateAction("Copy path", Core.Commands.CommandIds.CopyPaths, () => Run(() => _ = CopyToClipboardAsync(path)), safePath),
                },
            };
            AutomationProperties.SetName(group, $"Ancestor {name}: {safePath}");
            ToolTip.SetTip(group, safePath);
            items.Add(group);
        }
        var menu = new ContextMenu { ItemsSource = items, Placement = PlacementMode.Bottom };
        _ancestorMenu = menu;
        menu.Closed += (_, _) =>
        {
            _main?.ReconcileKeyBar(KeyMods.None);
            if (ReferenceEquals(_ancestorMenu, menu)) _ancestorMenu = null;
            if (_main?.Workspace.ActivePanel is not { } active || !ReferenceEquals(active, panel))
            {
                _main?.View.FocusActivePanel();
                return;
            }
            // The listing retains its own identity across a menu. Never reapply a stale row index after navigation
            // or refresh: give the current list keyboard focus, preserving its item only if it is still the same one.
            if (Current() && originalItem is not null && tab.Listing.FocusedStoreIndex >= 0
                && tab.Listing.TryGetFocused(out _) &&
                !tab.Listing.GetItemRef(tab.Listing.FocusedStoreIndex).Equals(originalItem))
                _main?.Notify("The listing changed while the ancestor menu was open; focus is on its current item.");
            List.Focus();
        };
        menu.Open(AddressRow);
        Dispatcher.UIThread.Post(() =>
        {
            if (ReferenceEquals(_ancestorMenu, menu)) items[0].Focus();
        }, DispatcherPriority.Input);
        return true;

        static MenuItem CreateAction(string verb, string icon, Action run, string path)
        {
            var item = new MenuItem { Header = verb, Icon = MenuIconFactory.Create(icon) };
            AutomationProperties.SetName(item, $"{verb}: {path}");
            item.Click += (_, _) => run();
            return item;
        }
    }

    internal ContextMenu? AncestorMenu => _ancestorMenu;

    /// <summary>The path's context menu: copy the whole path, the part clicked, or the name; go there; edit the path.</summary>
    private void ShowPathMenu(Avalonia.Point point, int segment)
    {
        Activated?.Invoke();
        var segments = PathLinks.Segments;
        if (segments.Count == 0) return;
        int last = segments.Count - 1;
        var items = new List<Control>();
        void Add(string header, string icon, Action run)
        {
            var item = new MenuItem { Header = header, Icon = MenuIconFactory.Create(icon) };
            item.Click += (_, _) => run();
            items.Add(item);
        }
        Add("Copy full path", Core.Commands.CommandIds.CopyPaths, () => _ = CopyToClipboardAsync(PathLinks.Text));
        if (segment >= 0 && segment < last)
            Add($"Copy \u201C{PathLinks.PathUpTo(segment)}\u201D", Core.Commands.CommandIds.CopyPaths, () => _ = CopyToClipboardAsync(PathLinks.PathUpTo(segment)));
        int named = segment >= 0 ? segment : last;
        if (PathLinks.NameOf(named) is { Length: > 0 } name)
            Add($"Copy the name \u201C{name}\u201D", Core.Commands.CommandIds.CopyNames, () => _ = CopyToClipboardAsync(name));
        if (segment >= 0 && segment < last)
        {
            items.Add(new Separator());
            var target = segments[segment].Target;
            Add($"Go to \u201C{PathLinks.NameOf(segment)}\u201D", Core.Commands.CommandIds.GoTo, () => OnPathPartChosen(target, false));
            Add($"Open \u201C{PathLinks.NameOf(segment)}\u201D in a new tab", Core.Commands.CommandIds.NewTab, () => OnPathPartChosen(target, true));
        }
        items.Add(new Separator());
        Add("Edit the path", Core.Commands.CommandIds.Edit, FocusPathBox);
        var menu = new ContextMenu { ItemsSource = items, Placement = PlacementMode.Pointer };
        menu.Open(PathLinks);
    }

    /// <summary>The path's parts as links (tests).</summary>
    internal PathLine PathLinksControl => PathLinks;

    private void OnSourcePropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(PanelViewModel.ActiveTab)) QuickView.Attach(_hookedSource?.ActiveTab);
    }

    /// <summary>The active tab stays in sight when the tabs do not all fit (a new tab opens at the end).</summary>
    private void ShowActiveTab()
    {
        Avalonia.Threading.Dispatcher.UIThread.Post(() =>
        {
            if (Panel?.ActiveTab is { } tab && TabStrip.ContainerFromItem(tab) is { } container) container.BringIntoView();
            UpdateTabOverflow();
        }, Avalonia.Threading.DispatcherPriority.Loaded);
    }

    private void UpdateTabOverflow() => TabOverflow.IsVisible = TabScroller.Extent.Width > TabScroller.Viewport.Width + 1;

    private void OnTabOverflowClick(object? sender, RoutedEventArgs e)
    {
        Activated?.Invoke();
        if (TopLevel.GetTopLevel(this)?.DataContext is MainViewModel vm) vm.Execute(Core.Commands.CommandIds.TabList);
    }

    /// <summary>Whether the tab strip offers its "⋯" button, and whether the active tab is in sight (tests).</summary>
    internal (bool Overflowing, bool ActiveTabVisible) TabStripState()
    {
        bool visible = Panel?.ActiveTab is { } tab && TabStrip.ContainerFromItem(tab) is { } c &&
                       c.TranslatePoint(new Avalonia.Point(0, 0), TabScroller) is { } p && p.X >= -0.5 && p.X + c.Bounds.Width <= TabScroller.Viewport.Width + 0.5;
        return (TabOverflow.IsVisible, visible);
    }

    private void AttachQuickView()
    {
        if (_hookedSource is not null) _hookedSource.PropertyChanged -= OnSourcePropertyChanged;
        _hookedSource = Panel?.QuickViewSource;
        if (_hookedSource is not null) _hookedSource.PropertyChanged += OnSourcePropertyChanged;
        QuickView.Attach(_hookedSource?.ActiveTab);
    }

    public event Action? Activated;
    public event Action? OpenRequested;
    public event Action? RenameRequested;

    /// <summary>A press on the panel's number or tab strip that may start moving the panel (and the element pressed).</summary>
    public event Action<PointerPressedEventArgs, Control>? MoveRequested;

    /// <summary>A left press on a tab that may start dragging it (the tab, and its button).</summary>
    public event Action<PointerPressedEventArgs, TabViewModel, Control>? TabDragRequested;
    public event Action<string>? PathSubmitted;
    public event Action? LocationMenuRequested;
    public event Action<int>? MiddleClick;

    private PanelViewModel? Panel => DataContext as PanelViewModel;

    public void FocusPathBox()
    {
        PathBox.Focus();
        PathBox.SelectAll();
    }

    public void FocusFilterBox()
    {
        FilterBox.Focus(NavigationMethod.Tab);
        FilterBox.SelectAll();
    }

    private void RevertPath() => PathBox.Text = Panel?.ActiveTab?.DisplayPath;

    private readonly PathCompletion _completion;

    /// <summary>The folders suggested for what is typed; empty while none are shown (tests).</summary>
    internal IReadOnlyList<string> PathSuggestionsShown => _completion.Shown;

    private void OnPathKeyDown(object? sender, KeyEventArgs e)
    {
        if (_completion.HandleKey(e))
        {
            e.Handled = true;
            return;
        }
        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            var text = PathBox.Text ?? string.Empty;
            PathSubmitted?.Invoke(text);
        }
        else if (e.Key == Key.Escape)
        {
            e.Handled = true;
            RevertPath();
            List.Focus();
        }
        else if (e.Key == Key.Down && (e.KeyModifiers & KeyModifiers.Alt) == 0)
        {
            e.Handled = true;
            RevertPath();
            List.Focus();
        }
    }

    private void OnTabClick(object? sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: TabViewModel tab } && Panel is { } p)
        {
            p.ActiveTab = tab;
            Activated?.Invoke();
            List.Focus();
        }
    }

    /// <summary>A left press on a tab may start dragging it along the strip, or to another panel's (the window decides).</summary>
    private void OnTabPointerPressed(object? sender, PointerPressedEventArgs e)
    {
        if ((e.Source as Visual)?.FindAncestorOfType<Button>(includeSelf: true) is { Tag: TabViewModel tab } button
            && e.GetCurrentPoint(button).Properties.IsLeftButtonPressed)
            TabDragRequested?.Invoke(e, tab, button);
    }

    /// <summary>
    /// Where a tab dropped at <paramref name="point"/> (in <paramref name="relativeTo"/>'s coordinates) goes among this
    /// panel's tabs (as the index it ends up at), and the gap between tabs to mark there; null off the tab strip.
    /// </summary>
    internal (int Index, Rect Gap)? TabDropAt(Point point, Visual relativeTo, TabViewModel dragged)
    {
        if (Panel is not { } panel || !TabHeader.IsEffectivelyVisible || TabScroller.TranslatePoint(default, relativeTo) is not { } origin) return null;
        // Forgiving around the strip: a drag rarely stays within its few pixels of height, or stops exactly at an end.
        var strip = new Rect(origin, TabScroller.Bounds.Size).Inflate(new Thickness(TabStripEnd, 10));
        if (!strip.Contains(point)) return null;
        int index = 0;
        double gap = origin.X;
        foreach (var tab in panel.Tabs)
        {
            if (ReferenceEquals(tab, dragged)) continue;
            if (TabStrip.ContainerFromItem(tab) is not Control c || c.TranslatePoint(default, relativeTo) is not { } at) continue;
            if (point.X < at.X + c.Bounds.Width / 2)
            {
                gap = at.X;
                break;
            }
            index++;
            gap = at.X + c.Bounds.Width;
        }
        gap = Math.Clamp(gap, origin.X + 1, origin.X + TabScroller.Bounds.Width - 1);
        return (index, new Rect(gap - 1.5, origin.Y + 2, 3, Math.Max(8, TabScroller.Bounds.Height - 4)));
    }

    /// <summary>How near either end of the tab strip (inside it or just past it) a dragged tab is at that end.</summary>
    private const double TabStripEnd = 24;

    /// <summary>
    /// A tab dragged to either end of a strip whose tabs do not all fit scrolls it that way by <paramref name="step"/>,
    /// so every place among its tabs can be reached, the hidden ones too; whether it scrolled.
    /// </summary>
    internal bool ScrollTabsToward(Point point, Visual relativeTo, double step)
    {
        if (!TabHeader.IsEffectivelyVisible || TabScroller.TranslatePoint(default, relativeTo) is not { } origin) return false;
        var strip = new Rect(origin, TabScroller.Bounds.Size);
        if (!strip.Inflate(new Thickness(TabStripEnd, 10)).Contains(point)) return false;
        double direction = point.X < strip.Left + TabStripEnd ? -1 : point.X > strip.Right - TabStripEnd ? 1 : 0;
        double offset = Math.Clamp(TabScroller.Offset.X + direction * step, 0,
                                   Math.Max(0, TabScroller.Extent.Width - TabScroller.Viewport.Width));
        if (Math.Abs(offset - TabScroller.Offset.X) < 0.5) return false;
        TabScroller.Offset = TabScroller.Offset.WithX(offset);
        TabScroller.UpdateLayout(); // the tabs' new places, for the drop that follows
        return true;
    }

    private void OnTabPointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (sender is not Button { Tag: TabViewModel tab } button || Panel is not { } p) return;
        if (e.InitialPressMouseButton == MouseButton.Middle)
        {
            // A panel's last tab stays; say so, as Ctrl+W does, rather than ignore the click.
            if (p.CanCloseTab(tab)) p.CloseTab(tab);
            else _main?.Notify(PanelViewModel.KeepsOneTab);
            e.Handled = true;
        }
        else if (e.InitialPressMouseButton == MouseButton.Right)
        {
            BuildTabMenu(p, tab).Open(button);
            e.Handled = true;
        }
    }

    /// <summary>Tab operations following Total Commander (plan §4.1).</summary>
    internal ContextMenu BuildTabMenu(PanelViewModel panel, TabViewModel tab)
    {
        var ws = panel.Workspace;
        var items = new List<Control>();
        void Add(string header, string icon, Action action, bool enabled = true, string? gesture = null, string? reason = null)
        {
            var mi = new MenuItem { Header = header, Icon = MenuIconFactory.Create(icon), IsEnabled = enabled };
            if (gesture is not null) mi.InputGesture = KeyGesture.Parse(gesture);
            if (!enabled && reason is not null)
            {
                ToolTip.SetTip(mi, reason);
                ToolTip.SetShowOnDisabled(mi, true);
                AutomationProperties.SetHelpText(mi, reason);
            }
            mi.Click += (_, _) =>
            {
                action();
                List.Focus();
            };
            items.Add(mi);
        }
        Add("Close tab", "tab.close", () => panel.CloseTab(tab), panel.CanCloseTab(tab), reason: PanelViewModel.KeepsOneTab);
        Add("Close other tabs", "tab.closeOthers", () =>
        {
            foreach (var t in panel.Tabs.Where(t => !ReferenceEquals(t, tab) && !t.IsLocked).ToList()) panel.CloseTab(t);
        }, panel.Tabs.Count > 1);
        Add("Duplicate tab", "tab.duplicate", () =>
        {
            if (tab.Location is null) return;
            var dup = panel.OpenTab(tab.Location);
            var s = tab.ToState();
            s.Locked = false;
            dup.ApplyState(s);
        });
        items.Add(new Separator());
        Add(tab.IsLocked && !tab.ReturnToRoot ? "Unlock tab" : "Lock tab (navigation opens new tabs)", "tab.lock", () =>
        {
            bool lockIt = !(tab.IsLocked && !tab.ReturnToRoot);
            tab.IsLocked = lockIt;
            tab.ReturnToRoot = false;
            tab.LockedRoot = lockIt ? tab.Location : null;
        });
        Add(tab.IsLocked && tab.ReturnToRoot ? "Unlock tab" : "Lock tab at root (returns here when revisited)", "tab.lock", () =>
        {
            bool lockIt = !(tab.IsLocked && tab.ReturnToRoot);
            tab.IsLocked = lockIt;
            tab.ReturnToRoot = lockIt;
            tab.LockedRoot = lockIt ? tab.Location : null;
        });
        items.Add(new Separator());
        var target = ws.GetTarget(panel);
        // The last tab moved away leaves a fresh one at the same place behind (a panel keeps a tab).
        Add(target is null ? "Move tab to target panel (no target)" : $"Move tab to panel {target.Number}", "tab.moveTarget", () =>
        {
            if (target is not null) ws.MoveTabToPanel(tab, target);
        }, target is not null);
        Add(target is null ? "Copy tab to target panel (no target)" : $"Copy tab to panel {target.Number}", "tab.copyTarget", () =>
        {
            if (target is not null && tab.Location is { } l) target.OpenTab(l);
        }, target is not null);
        int index = panel.Tabs.IndexOf(tab);
        Add("Move tab left", "tab.left", () => panel.MoveTab(tab, index - 1), index > 0, "Ctrl+Shift+PageUp");
        Add("Move tab right", "tab.right", () => panel.MoveTab(tab, index + 1), index < panel.Tabs.Count - 1, "Ctrl+Shift+PageDown");
        return new ContextMenu { ItemsSource = items };
    }

    private void OnNewTabClick(object? sender, RoutedEventArgs e)
    {
        if (Panel is { ActiveTab.Location: { } loc } p)
        {
            p.OpenTab(loc);
            Activated?.Invoke();
            List.Focus();
        }
    }

    /// <summary>
    /// The role chip: "Set as target" makes this panel the active panel's target without leaving the active panel; on
    /// the active panel it lists the other panels to choose the target from.
    /// </summary>
    private void OnRoleClick(object? sender, RoutedEventArgs e)
    {
        if (Panel is not { } panel || TopLevel.GetTopLevel(this)?.DataContext is not MainViewModel vm) return;
        var ws = panel.Workspace;
        if (panel.OffersTarget && ws.ActivePanel is { } active)
        {
            vm.SetPanelTarget(active, panel);
            return;
        }
        if (!panel.IsActive || ws.Panels.Count <= 2) return;
        var current = ws.GetTarget(panel);
        var items = new List<Control>();
        foreach (var other in ws.Panels.Where(p => !ReferenceEquals(p, panel)))
        {
            var choice = other;
            var item = new MenuItem
            {
                Header = $"Panel {other.Number}: {other.ActiveTab?.DisplayPath}",
                ToggleType = MenuItemToggleType.Radio,
                IsChecked = ReferenceEquals(other, current),
            };
            item.Click += (_, _) => vm.SetPanelTarget(panel, choice);
            items.Add(item);
        }
        new ContextMenu { ItemsSource = items }.Open(RoleButton);
    }

    private void OnLocationMenuClick(object? sender, RoutedEventArgs e)
    {
        Activated?.Invoke();
        LocationMenuRequested?.Invoke();
    }

    /// <summary>Accessible sort choices live outside the custom file-list renderer's native bridge.</summary>
    private void OnSortClick(object? sender, RoutedEventArgs e)
    {
        if (Panel is not { ActiveTab: { } tab } panel) return;
        Activated?.Invoke();
        _sortMenu?.Close();
        var items = new List<MenuItem>();
        foreach (var column in tab.Columns)
        {
            if (column.SortField is not { } field || field == SortField.None) continue;
            string? metadataId = field == SortField.Metadata ? column.MetadataId : null;
            if (field == SortField.Metadata && metadataId is null) continue;
            string label = Formatters.SafeName(column.DisplayHeader);
            bool current = tab.Listing.Sort.Field == field &&
                (field != SortField.Metadata || tab.Listing.Sort.MetadataId == metadataId);
            var item = new MenuItem
            {
                Header = label,
                ToggleType = MenuItemToggleType.Radio,
                IsChecked = current,
            };
            AutomationProperties.SetName(item, $"Sort by {label}" +
                (current ? $", currently {(tab.Listing.Sort.Descending ? "descending" : "ascending")}; activate to reverse" : string.Empty));
            item.Click += (_, _) =>
            {
                if (!ReferenceEquals(Panel, panel) || !ReferenceEquals(panel.ActiveTab, tab)) return;
                if (metadataId is { } id) tab.SortByMetadata(id);
                else tab.SortBy(field);
            };
            items.Add(item);
        }
        if (items.Count == 0) return;
        var menu = new ContextMenu { ItemsSource = items, Placement = PlacementMode.Bottom };
        _sortMenu = menu;
        menu.Closed += (_, _) =>
        {
            _main?.ReconcileKeyBar(KeyMods.None);
            if (ReferenceEquals(_sortMenu, menu)) _sortMenu = null;
            if (ReferenceEquals(Panel, panel) && ReferenceEquals(panel.ActiveTab, tab)) List.Focus();
        };
        menu.Open(SortButton);
    }

    private void OnDismissBanner(object? sender, RoutedEventArgs e)
    {
        if (Panel?.ActiveTab is { } t) t.Banner = null;
        List.Focus();
    }

    private async void OnReadSupplementaryEas(object? sender, RoutedEventArgs e)
    {
        if (_main is not { } main || Panel?.ActiveTab is not { CanReadSupplementaryEas: true } tab || tab.Location is not { } location) return;
        long generation = tab.NavigationGeneration;
        bool admitted = await main.Dialogs.ConfirmAsync("Read extended attributes",
            "Windows returns extended attribute names and value bytes in the same query. FileCat will acquire a bounded buffer, retain names, flags and lengths, and discard the values. The inventory does not display or export value excerpts.", "Read extended attributes");
        if (!admitted || !ReferenceEquals(Panel?.ActiveTab, tab) || tab.Location != location || tab.NavigationGeneration != generation || !tab.CanReadSupplementaryEas) return;
        tab.Listing.AdmitSupplementaryEaQuery();
    }

    /// <summary>Count in the status line: this panel's marked folders are counted, and the keyboard stays in its list.</summary>
    private void OnCountFolderSizes(object? sender, RoutedEventArgs e)
    {
        if (Panel?.ActiveTab is { } tab && TopLevel.GetTopLevel(this)?.DataContext is MainViewModel vm) vm.CountFolderSizes(tab);
        List.Focus();
    }

    /// <summary>The item context menu: at the pointer for a right click, at the focused row from the keyboard.</summary>
    /// <param name="extended">Shift was held for the right click: Windows adds its extended verbs, as in Explorer.</param>
    public void ShowContextMenu(bool atFocus = false, Avalonia.Point? point = null, bool extended = false)
    {
        long request = ++_menuRequest;
        _openItemMenu?.Close();
        _openItemMenu = null;
        _ = ShowContextMenuAsync(atFocus, point, extended && point is not null, request);
    }

    /// <summary>
    /// Tests: stands in for Windows' own menu of a folder's empty space (folder, screen x, screen y, extended), so each
    /// of its outcomes can be given on purpose without a desktop.
    /// </summary>
    internal static Func<string, int, int, bool, Task<WindowsContextMenu.Outcome>>? NativeBackgroundMenuForTests { get; set; }

    /// <summary>
    /// Windows' own menus need a desktop window of FileCat's to stand on: not the headless test platform's stand-in, where
    /// a Shell popup would wait on a desktop no one looks at.
    /// </summary>
    internal bool HasNativeWindow() => OperatingSystem.IsWindows() &&
        TopLevel.GetTopLevel(this)?.TryGetPlatformHandle() is { HandleDescriptor: "HWND", Handle: not 0 };

    /// <summary>
    /// The menu for a folder's empty space. On Windows, for a folder on disk, it is the folder's own Shell menu, as
    /// Explorer shows it there (New, Paste, Give access to, installed handlers, Properties), with FileCat's location
    /// actions one item away; elsewhere, or when that menu is unavailable, FileCat's location actions directly.
    /// </summary>
    private void ShowBackgroundContextMenu(Avalonia.Point point, bool extended = false)
    {
        long request = ++_menuRequest;
        _openItemMenu?.Close();
        _openItemMenu = null;
        if (TopLevel.GetTopLevel(this)?.DataContext is not MainViewModel vm ||
            Panel is not { ActiveTab: { Location: { } location } tab } panel ||
            !ReferenceEquals(tab, List.Tab)) return;
        // A folder whose listing failed keeps FileCat's menu, which says why writing there waits for a reread.
        if (location.IsFileSystem && WindowsContextMenu.CanShowBackground(location.Path) &&
            MainViewModel.LocationWriteBlockReason(tab, location) is null &&
            (NativeBackgroundMenuForTests is not null || HasNativeWindow()))
        {
            _ = ShowNativeBackgroundMenuAsync(vm, panel, tab, location, point, extended, request);
            return;
        }
        ShowFileCatBackgroundMenu(vm, panel, tab, location, request);
    }

    /// <summary>
    /// The column header's menu, at the pointer: setting up the columns, on Settings' Columns page with this panel's
    /// profile selected. A view with columns of its own (results, the Recycle Bin, the registry) says so instead.
    /// </summary>
    private void ShowHeaderContextMenu()
    {
        ++_menuRequest; // an item or folder menu still being prepared gives way to this one
        _openItemMenu?.Close();
        _openItemMenu = null;
        if (TopLevel.GetTopLevel(this)?.DataContext is not MainViewModel vm || List.Tab is not { } tab) return;
        bool profiled = tab.UsesColumnProfiles;
        var columns = new MenuItem
        {
            Header = "Set up columns…",
            Icon = MenuIconFactory.Create(Core.Commands.CommandIds.ColumnProfilePrefix),
            IsEnabled = profiled,
        };
        string tip = profiled
            ? $"Settings → Columns, on this panel's profile {Formatters.SafeName(vm.Services.Columns.NameOf(tab.ColumnProfile))} " +
              $"(Alt+{tab.ColumnProfile}): its columns, their order and widths."
            : "This view keeps its own columns; Settings → Columns sets those of folders, archives and connections.";
        ToolTip.SetTip(columns, tip);
        if (!profiled)
        {
            ToolTip.SetShowOnDisabled(columns, true);
            AutomationProperties.SetHelpText(columns, tip);
        }
        columns.Click += (_, _) => _ = vm.ShowSettingsAsync(SettingsDialog.ColumnsPage, tab.ColumnProfile);
        var menu = new ContextMenu { ItemsSource = new Control[] { columns }, Placement = PlacementMode.Pointer };
        _openItemMenu = menu;
        menu.Closed += (_, _) =>
        {
            vm.ReconcileKeyBar(KeyMods.None);
            if (ReferenceEquals(_openItemMenu, menu)) _openItemMenu = null;
        };
        menu.Open(List);
    }

    /// <summary>
    /// Whether this window's keyboard focus is still in this panel's list, or nowhere (the window not active while the
    /// Shell's popup hands the foreground back): not in the path box, the command line, a menu, or another panel.
    /// </summary>
    private bool KeyboardStaysInList() => TopLevel.GetTopLevel(this)?.FocusManager?.GetFocusedElement() switch
    {
        null => true,
        Visual focused => ReferenceEquals(focused, List) || List.IsVisualAncestorOf(focused),
        _ => false,
    };

    private void ShowFileCatBackgroundMenu(MainViewModel vm, PanelViewModel panel, TabViewModel tab, Core.Resources.Location location, long request)
    {
        var menu = ContextMenuFactory.BuildBackground(vm, panel, tab, location);
        if (request != _menuRequest) return;
        menu.Placement = PlacementMode.Pointer;
        _openItemMenu = menu;
        menu.Closed += (_, _) =>
        {
            vm.ReconcileKeyBar(KeyMods.None);
            if (ReferenceEquals(_openItemMenu, menu)) _openItemMenu = null;
        };
        menu.Open(List);
    }

    private async Task ShowNativeBackgroundMenuAsync(MainViewModel vm, PanelViewModel panel, TabViewModel tab,
        Core.Resources.Location location, Avalonia.Point point, bool extended, long request)
    {
        try
        {
            var screen = List.PointToScreen(point);
            var show = NativeBackgroundMenuForTests ?? WindowsContextMenu.ShowBackgroundAsync;
            // The cursor and marks as the menu opens (it holds the input while open): whatever changes them after it
            // closes is the user's doing, and wins over renaming a new item.
            string? cursor = MainViewModel.CursorName(tab.Listing);
            int marks = tab.Listing.MarkedCount;
            var outcome = await show(location.Path, screen.X, screen.Y, extended);
            if (request != _menuRequest) return;
            switch (outcome.Result)
            {
                case WindowsContextMenu.Result.Handled:
                    return;
                case WindowsContextMenu.Result.Created when outcome.Created is { } created:
                    // New → Folder, Text Document, …: the item is selected with its name open for editing, as in Explorer,
                    // unless the user went on to something else meanwhile: the path box, the command line or search, the
                    // menu bar, another menu (the keyboard left this list, or a menu opened since), or a rename.
                    vm.RenameCreatedItem(panel, tab, location, created, cursor, marks,
                        () => request == _menuRequest && _openItemMenu is null && !List.IsRenaming && KeyboardStaysInList());
                    return;
                case WindowsContextMenu.Result.Created:
                    return;
                case WindowsContextMenu.Result.Properties:
                    vm.ShowPropertiesForPath(location.Path);
                    return;
                case WindowsContextMenu.Result.ActionFailed:
                    vm.Notify("Windows could not complete that action.", true);
                    return;
                case WindowsContextMenu.Result.Failed:
                    if (!_nativeMenuWarningShown)
                    {
                        _nativeMenuWarningShown = true;
                        vm.Notify("Windows menu unavailable here; showing FileCat actions.", true);
                    }
                    break;
                case WindowsContextMenu.Result.FileCatActions:
                    break;
                default:
                    return;
            }
            // FileCat's own location actions, for the folder this menu was opened for while the tab still shows it.
            if (!panel.Tabs.Contains(tab) || tab.Listing.IsDisposed || tab.Location != location || !ReferenceEquals(Panel, panel)) return;
            ShowFileCatBackgroundMenu(vm, panel, tab, location, request);
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            Core.Diagnostics.AppLog.Error("The folder's context menu failed", ex);
            vm.Notify("The folder's menu could not open: " + Formatters.SafeName(ex.Message), true);
        }
    }

    private async Task ShowContextMenuAsync(bool atFocus, Avalonia.Point? point, bool extended, long request)
    {
        if (TopLevel.GetTopLevel(this)?.DataContext is not MainViewModel vm) return;
        if (Panel is { ActiveTab: { Location: { } current } parentTab } parentPanel &&
            parentTab.Listing.TryGetFocused(out var focused) && focused.Kind == Core.Resources.EntryKind.Parent &&
            vm.Services.Providers.For(current).GetParent(current) is { } parent)
        {
            if (request == _menuRequest) ShowParentContextMenu(vm, parentPanel, parentTab, current, parent, atFocus, request);
            return;
        }
        if (HasNativeWindow() && Panel?.ActiveTab is { Location.IsFileSystem: true } tab &&
            tab.Listing.MarkedCount <= WindowsContextMenu.MaxItems)
        {
            var paths = tab.Listing.GetSelection().Select(item => item.FileSystemPath).ToArray();
            if (WindowsContextMenu.CanShow(paths))
            {
                var anchor = point ?? (List.FocusedRowBounds() is { } bounds
                    ? new Avalonia.Point(bounds.Left + 12, bounds.Bottom) : new Avalonia.Point(0, 0));
                var screen = List.PointToScreen(anchor);
                var result = await WindowsContextMenu.ShowAsync(paths!, screen.X, screen.Y, extended);
                if (request != _menuRequest) return;
                if (result == WindowsContextMenu.Result.Handled) return;
                if (result == WindowsContextMenu.Result.Properties)
                {
                    if (paths.Length == 1) vm.ShowPropertiesForPath(paths[0]!);
                    else vm.Notify("Select one item to show its properties.");
                    return;
                }
                if (result == WindowsContextMenu.Result.CompressedZip)
                {
                    vm.PackFromWindowsSendTo(paths, tab);
                    return;
                }
                if (result is WindowsContextMenu.Result.Copy or WindowsContextMenu.Result.Cut)
                {
                    await vm.PutContextFilesOnClipboardAsync(tab, paths, result == WindowsContextMenu.Result.Cut);
                    return;
                }
                if (result == WindowsContextMenu.Result.ShareInExplorer)
                {
                    try
                    {
                        vm.Services.Shell.Reveal(paths[0]!);
                        vm.Notify(paths.Length == 1
                            ? "Selected in Explorer. Choose Share there."
                            : "The first item is selected in Explorer. Select the other items there, then choose Share.");
                    }
                    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidOperationException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.COMException)
                    {
                        vm.Notify("Could not open Explorer for sharing: " + ex.Message, true);
                    }
                    return;
                }
                if (result == WindowsContextMenu.Result.RecoverImage)
                {
                    vm.RecoverImage(paths[0]!);
                    return;
                }
                if (result == WindowsContextMenu.Result.ActionFailed)
                {
                    vm.Notify("Windows could not complete that action.", true);
                    return;
                }
                if (result == WindowsContextMenu.Result.FileCatActions) atFocus = point is null;
                if (result == WindowsContextMenu.Result.Failed && !_nativeMenuWarningShown)
                {
                    _nativeMenuWarningShown = true;
                    vm.Notify("Windows menu unavailable here; showing FileCat actions.", true);
                }
            }
        }
        if (request != _menuRequest) return;
        var menu = ContextMenuFactory.Build(vm);
        AppendInspectionItem(menu);
        if (atFocus && List.FocusedRowBounds() is { } row)
        {
            menu.Placement = Avalonia.Controls.PlacementMode.BottomEdgeAlignedLeft;
            menu.PlacementRect = row;
        }
        _openItemMenu = menu;
        menu.Closed += (_, _) =>
        {
            vm.ReconcileKeyBar(KeyMods.None);
            if (ReferenceEquals(_openItemMenu, menu)) _openItemMenu = null;
        };
        menu.Open(List);
    }

    private void ShowParentContextMenu(MainViewModel vm, PanelViewModel panel, TabViewModel tab,
        Core.Resources.Location current, Core.Resources.Location parent, bool atFocus, long request)
    {
        bool Current() => request == _menuRequest && ReferenceEquals(Panel, panel) &&
            ReferenceEquals(panel.ActiveTab, tab) && Equals(tab.Location, current);
        void Run(Action action)
        {
            if (!Current()) { vm.Notify("The location changed. Open the parent menu again for the current location."); return; }
            action();
            List.Focus();
        }
        MenuItem Action(string header, string icon, Action run)
        {
            var item = new MenuItem { Header = header, Icon = MenuIconFactory.Create(icon) };
            item.Click += (_, _) => Run(run);
            return item;
        }
        var parentText = parent.IsFileSystem ? parent.Path : vm.Services.Providers.Display(parent);
        var menu = new ContextMenu
        {
            ItemsSource = new[]
            {
                Action("Go to parent", Core.Commands.CommandIds.Parent, () => tab.Navigate(parent)),
                Action("Open parent in new tab", Core.Commands.CommandIds.NewTab, () => panel.OpenTab(parent)),
                Action("Copy parent path", Core.Commands.CommandIds.CopyPaths, () => _ = CopyToClipboardAsync(parentText)),
            },
            Placement = atFocus ? PlacementMode.BottomEdgeAlignedLeft : PlacementMode.Pointer,
        };
        if (atFocus && List.FocusedRowBounds() is { } row) menu.PlacementRect = row;
        _openItemMenu = menu;
        menu.Closed += (_, _) =>
        {
            vm.ReconcileKeyBar(KeyMods.None);
            if (ReferenceEquals(_openItemMenu, menu)) _openItemMenu = null;
        };
        menu.Open(List);
    }

    internal void AppendInspectionItem(ContextMenu menu)
    {
        if (menu.ItemsSource is IEnumerable<Control> original)
        {
            var items = original.ToList();
            var inspect = new MenuItem { Header = "Inspect focused row…", IsEnabled = List.FocusedInspectionText() is not null };
            ToolTip.SetTip(inspect, "Show every full displayed value for the focused item (Ctrl+Shift+I).");
            inspect.Click += (_, _) => _ = ShowInspectionAsync(List.FocusedInspectionText());
            items.Add(new Separator());
            items.Add(inspect);
            menu.ItemsSource = items;
        }
    }

    private async Task ShowInspectionAsync(string? report)
    {
        if (report is null || _main is not { } vm || vm.Dialogs.IsOpen) return;
        var text = new TextBox
        {
            Text = report,
            IsReadOnly = true,
            AcceptsReturn = true,
            TextWrapping = Avalonia.Media.TextWrapping.Wrap,
            MinWidth = 420,
            MinHeight = 240,
            MaxHeight = 520,
        };
        AutomationProperties.SetName(text, "Full values of focused item");
        await vm.Dialogs.ShowCustomAsync("Inspect focused item", text,
            [new DialogButton("Close", "close", IsDefault: true, IsCancel: true)], text, resizable: true);
    }
}
