param([Parameter(Mandatory=$true)][string]$ArchiveSha256)
$ErrorActionPreference='Stop';$base=$PSScriptRoot;$app=Join-Path $base 'app'
function Json([string]$name,$value){$value|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $base $name)}
function WaitIdle([string]$case){
 $deadline=[DateTime]::UtcNow.AddMinutes(30)
 while(@(Get-Process -Name 'FileCat*','dotnet' -ErrorAction SilentlyContinue).Count){
  Json 'state.json' @{state='waiting-for-idle';case=$case}
  if([DateTime]::UtcNow-ge$deadline){throw 'Shared guest stayed busy; no additional test started'}
  Start-Sleep -Seconds 30
 }
}
if((Get-FileHash -LiteralPath (Join-Path $base 'app.tgz') -Algorithm SHA256).Hash.ToLowerInvariant()-cne$ArchiveSha256){throw 'Archive mismatch'}
if(Test-Path -LiteralPath $app){throw 'Fresh extraction required'}
WaitIdle 'integrity';New-Item -ItemType Directory -Path $app|Out-Null
& tar.exe -xzf (Join-Path $base 'app.tgz') -C $app;if($LASTEXITCODE){throw 'Extraction failed'}
$inputs=Get-Content -LiteralPath (Join-Path $app 'inputs.json') -Raw|ConvertFrom-Json
foreach($item in $inputs){
 if([IO.Path]::GetFileName($item.name)-cne$item.name){throw 'Invalid input filename'}
 if((Get-FileHash -LiteralPath (Join-Path $app $item.name) -Algorithm SHA256).Hash.ToLowerInvariant()-cne$item.sha256){throw 'Input mismatch'}
}
$result=[ordered]@{purpose='Production CSV store/export scale, not filesystem source traversal or full-tool qualification';archiveSha256=$ArchiveSha256;inputs=$inputs;runs=@()}
try{
 foreach($count in @(1000,1000000,10000000)){
  foreach($shape in @('wide','deep')){
   $case=[string]$count+'-'+$shape;WaitIdle $case;$parent=Join-Path $base ('records-'+$case)
   if(Test-Path -LiteralPath $parent){throw 'A fresh generated scale parent is required'}
   New-Item -ItemType Directory -Path $parent|Out-Null
   $record=[ordered]@{records=$count;shape=$shape;warmup=$count-eq1000}
   Json 'state.json' @{state='running';case=$case;runnerPid=$PID}
   try{
    Set-Location -LiteralPath $app
    & 'C:\Program Files\dotnet\dotnet.exe' (Join-Path $app 'FileCat.CoreCrashHarness.dll') --analysis-csv-scale $count $shape $parent 1> (Join-Path $base ($case+'.out')) 2> (Join-Path $base ($case+'.err'))
    $code=$LASTEXITCODE;$record.exitCode=$code;$record.ownedProcessExited=$true
    $lines=Get-Content -LiteralPath (Join-Path $base ($case+'.out'));$measurement=$lines[-1]|ConvertFrom-Json;$record.measurement=$measurement
    if($code-ne0-or!$measurement.passed-or$measurement.records-ne$count-or$measurement.shape-cne$shape-or@($measurement.reports).Count-ne2){throw 'Native scale child failed; inspect preserved output'}
    foreach($report in $measurement.reports){if(!$report.verifiedEveryDeclaredRow-or$report.lines-ne($count+2)){throw 'CSV completeness failed'}}
    Write-Output ('PASS '+$case+' actual child exited')
   }catch{$record.error=$_.Exception.Message;throw}
   finally{$result.runs+=@($record);Json 'result.json' $result}
  }
 }
 $result.passed=$true;Json 'result.json' $result;Json 'state.json' @{state='finished';passed=$true}
}catch{Json 'state.json' @{state='finished';passed=$false;error=$_.Exception.Message};throw}
