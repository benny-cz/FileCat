set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '006d5987eb025f85ac405f3a79b34621c5497e66496f65e6d8ca165bf4c7b64f' ];umask 077;mkdir input;tar -xzf bundle.tgz -C input
python3 input/run.py
