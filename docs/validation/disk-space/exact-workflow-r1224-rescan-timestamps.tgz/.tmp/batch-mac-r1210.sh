set -eu
cd "$(dirname "$0")";base=$(pwd)
idle() {
 for attempt in 1 2 3; do
  if pgrep -x 'FileCat([.].*)?' >/dev/null 2>&1 || pgrep -x dotnet >/dev/null 2>&1; then
   printf 'BUSY\n' > state.txt;ps -axo pid=,args= > busy.txt;exit 75
  fi
  sleep 1
 done
}
idle
printf 'RUNNING phase=verify\n' > state.txt
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '3c8bdbdfdfe872173cb05e1e96612763d98995a84c4d75a47dcc692ecafe8750' ];umask 077;mkdir payload;tar -xzf bundle.tgz -C payload
bin="$base/payload/render"
for phase in epoch app-rescan metadata render settings;do
 idle;printf 'RUNNING phase=%s\n' "$phase" > "$base/state.txt"
 assembly=FileCat.Rendering.Tests.dll; bin="$base/payload/render"
 case "$phase" in
  epoch) bin="$base/payload/tests/FileCat.Core.Tests/bin/Debug/net10.0";assembly=FileCat.Core.Tests.dll;set -- -method 'FileCat.Core.Tests.AnalysisRefreshNavigationTests.*';;
  core) bin="$base/payload/tests/FileCat.Core.Tests/bin/Debug/net10.0";assembly=FileCat.Core.Tests.dll;set -- -class 'FileCat.Core.Tests.Analysis*' -class '*CommandTests' -class '*DeviceIoSchedulerTests' -class '*PathAndStateTests' -class '*ZipListingRevisionTests' -class '*ArchiveJobBackendTests' -class '*CloudFilesTests' -class '*CloudPlaceholderTests' -class '*FileDetailsFieldsTests' -class '*FileDetailsOwnershipTests' -class '*FileDetailsTests' -class '*HiddenDataTests' -class '*HiddenInventoryRefreshTests' -class '*HiddenInventoryTests' -class '*HiddenSearchTests' -class '*JobSchedulerClaimTests' -class '*NativeSearchPredicateTests' -class '*ReparsePresentationTests' -class '*StorageCallAdmissionTests' -class '*StorageCallEvidenceTests' -class '*StorageContractTests' -class '*StorageEvidenceAccountingTests' -class '*StorageEvidenceCursorTests' -class '*StorageEvidenceEnvelopeTests' -class '*StorageExecutionPlanTests' -class '*StorageExecutorTests' -class '*StorageHistoryDiscoveryTests' -class '*StorageJournalTests' -class '*StorageNativeAllowanceTests' -class '*StorageObjectCallRunnerTests' -class '*StorageReviewAcknowledgmentTests' -class '*StorageReviewOwnershipTests' -class '*StorageVisitLedgerTests' -class '*UnixFileDetailsNativeTests' -class '*UnixFileRecordTests' -class '*UnixHiddenInventoryNativeTests';;
  metadata) assembly=FileCat.App.Tests.dll;set -- -class '*FileDetailsColumnTests' -class '*AnalysisCurrentDemandTests' -class '*OwnerColumnAnalysisTests' -class '*MetadataOutcomeUiTests';;
  app-rescan) set -- -method '*NativeRescanView*';;
  render) set -- -class '*AnalysisRenderingTests';;
  settings) assembly=FileCat.App.Tests.dll;set -- -class '*SettingsDialogTests' -class '*SettingsPreservationTests' -class '*AnalyzeFolderChoiceTests' -class '*CloudBrowsingTests' -class '*FileDetailsColumnTests' -class '*FileDetailsFindScopeTests' -class '*FileDetailsWindowTests' -class '*FormattersTests' -class '*HiddenDataUiTests' -class '*HiddenInventoryUiTests' -class '*InterruptedRenameTests' -class '*NativeSearchPredicateUiTests' -class '*StorageCallEvidenceUiTests' -class '*StorageHistoryAccountingTests' -class '*StorageHistoryStartupUiTests' -class '*StorageOperationsUiTests' -class '*OwnerColumn*Tests' -class '*AnalysisCurrentDemandTests' -class '*AnalysisLeaveTests' -class '*MetadataPreparationTests' -class '*MetadataOutcomeUiTests';;
 esac
 set +e
 (cd "$bin";"$HOME/.dotnet/dotnet" "$assembly" "$@" -noLogo -noColor -maxThreads 2 -xml "$base/$phase.xml") > "$base/$phase.log" 2>&1
 result=$?;set -e
 if [ "$result" != 0 ] || ! python3 "$base/payload/validate.py" "$phase" "$base/$phase.xml";then printf 'FINISHED exit=1 phase=%s\n' "$phase" > "$base/state.txt";tail -n 30 "$base/$phase.log";exit 1;fi
done
export FILECAT_TEST_MAC_RUSAGE_CONTROL="$base/payload/render/native-counter-layout.json"
for shape in wide deep;do
 idle;printf 'RUNNING phase=1000-%s\n' "$shape" > "$base/state.txt"
 case="$base/case-1000-$shape";mkdir "$case"
 export FILECAT_TEST_NATIVE_SCALE_COUNT=1000 FILECAT_TEST_NATIVE_SCALE_SHAPE="$shape" FILECAT_TEST_NATIVE_SCALE_ROOT="$case"
 unset FILECAT_TEST_NATIVE_SCALE_SOURCE FILECAT_TEST_NATIVE_SCALE_KEEP_SOURCE
 set +e
 (cd "$base/payload/render";"$HOME/.dotnet/dotnet" FileCat.Rendering.Tests.dll -class '*AnalysisAcquisitionScaleTests' -noLogo -noColor -maxThreads 1 -xml "$case/tests.xml") > "$case/test.log" 2>&1
 result=$?;set -e
 if [ "$result" != 0 ] || ! python3 "$base/payload/render/validate-native-optimization.py" scale "$case";then printf 'FINISHED exit=1 phase=1000-%s\n' "$shape" > "$base/state.txt";tail -n 30 "$case/test.log";exit 1;fi
done
printf 'FINISHED exit=0\n' > "$base/state.txt"
