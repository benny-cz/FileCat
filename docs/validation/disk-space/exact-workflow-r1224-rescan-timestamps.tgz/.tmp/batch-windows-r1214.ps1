$ErrorActionPreference='Stop';$base=$PSScriptRoot;$state=Join-Path $base 'state.txt'
if((Get-Process -Id $PID).SessionId-eq0-or[Environment]::UserName-ne'filecatdsa_r2'){throw 'Use the ordinary R2 interactive desktop'}
function Idle {if(@(Get-Process -Name 'FileCat*',dotnet -ErrorAction SilentlyContinue).Count){'BUSY'|Set-Content $state;exit 75}}
try{
 Idle;'RUNNING phase=verify'|Set-Content $state
 if((Get-FileHash -LiteralPath (Join-Path $base 'bundle.tgz') -Algorithm SHA256).Hash-ne'f8589962905d1a51446663bb51f48da770cbaddcbf1b29ee745ac5ea40fce1c8'){throw 'Bundle changed'}
 $payload=Join-Path $base 'payload';if(Test-Path -LiteralPath $payload){throw 'Fresh payload required'}
 New-Item -ItemType Directory -Path $payload|Out-Null
 & tar.exe -xzf (Join-Path $base 'bundle.tgz') -C $payload;if($LASTEXITCODE){throw 'Extraction failed'}
 foreach($phase in 'app-rescan','metadata','render','settings'){
  Idle;('RUNNING phase='+$phase)|Set-Content $state
  $bin=Join-Path $payload 'tests\FileCat.Core.Tests\bin\Debug\net10.0';$assembly='FileCat.Core.Tests.dll'
  $filters=switch($phase){
   'epoch'{@('-method','FileCat.Core.Tests.AnalysisRefreshNavigationTests.*')}
   'native-epoch'{@('-method','*RescanEpoch*')}
   'core'{@('-class','FileCat.Core.Tests.Analysis*','-class','*CommandTests','-class','*DeviceIoSchedulerTests','-class','*PathAndStateTests','-class','*ZipListingRevisionTests','-class','*ArchiveJobBackendTests','-class','*CloudFilesTests','-class','*CloudPlaceholderTests','-class','*FileDetailsFieldsTests','-class','*FileDetailsOwnershipTests','-class','*FileDetailsTests','-class','*HiddenDataTests','-class','*HiddenInventoryRefreshTests','-class','*HiddenInventoryTests','-class','*HiddenSearchTests','-class','*JobSchedulerClaimTests','-class','*NativeSearchPredicateTests','-class','*ReparsePresentationTests','-class','*StorageCallAdmissionTests','-class','*StorageCallEvidenceTests','-class','*StorageContractTests','-class','*StorageEvidenceAccountingTests','-class','*StorageEvidenceCursorTests','-class','*StorageEvidenceEnvelopeTests','-class','*StorageExecutionPlanTests','-class','*StorageExecutorTests','-class','*StorageHistoryDiscoveryTests','-class','*StorageJournalTests','-class','*StorageNativeAllowanceTests','-class','*StorageObjectCallRunnerTests','-class','*StorageReviewAcknowledgmentTests','-class','*StorageReviewOwnershipTests','-class','*StorageVisitLedgerTests','-class','*UnixFileDetailsNativeTests','-class','*UnixFileRecordTests','-class','*UnixHiddenInventoryNativeTests')}
   'metadata'{@('-class','*FileDetailsColumnTests','-class','*AnalysisCurrentDemandTests','-class','*OwnerColumnAnalysisTests','-class','*MetadataOutcomeUiTests')}
   'app-rescan'{@('-method','*NativeRescanView*')}
   'render'{@('-class','*AnalysisRenderingTests')}
   'settings'{@('-class','*SettingsDialogTests','-class','*SettingsPreservationTests','-class','*AnalyzeFolderChoiceTests','-class','*CloudBrowsingTests','-class','*FileDetailsColumnTests','-class','*FileDetailsFindScopeTests','-class','*FileDetailsWindowTests','-class','*FormattersTests','-class','*HiddenDataUiTests','-class','*HiddenInventoryUiTests','-class','*InterruptedRenameTests','-class','*NativeSearchPredicateUiTests','-class','*StorageCallEvidenceUiTests','-class','*StorageHistoryAccountingTests','-class','*StorageHistoryStartupUiTests','-class','*StorageOperationsUiTests','-class','*OwnerColumn*Tests','-class','*AnalysisCurrentDemandTests','-class','*AnalysisLeaveTests','-class','*MetadataPreparationTests','-class','*MetadataOutcomeUiTests')}
   'native'{@('-class','*AnalysisWindowsTests','-class','*WindowsFileOperationsTests','-class','*WindowsHiddenDataTests','-class','*BoundReplacementTests','-class','*BoundComparedDeleteTests','-class','*BoundExtractionTests','-class','*CloudWriteTests','-class','*HiddenInventoryParserTests','-class','*NativeSearchAttributeTests','-class','*StorageDirectoryCursorTests','-class','*WindowsCompressionNativeTests','-class','*WindowsEnumerationTests','-class','*WindowsFileDetailsTests','-class','*WindowsFileRecordsTests','-class','*WindowsHiddenDataTests','-class','*WindowsStorageExecutorTests','-class','*WindowsStorageInspectionTests','-class','*WindowsStorageReviewEvidenceTests','-class','*WindowsStorageTraversalTests')}
  }
  if($phase-in@('native-epoch','native')){$bin=Join-Path $payload 'native';$assembly='FileCat.Platform.Windows.Tests.dll'}
  if($phase-in@('app-rescan','metadata','render','settings')){$bin=Join-Path $payload 'render';$assembly=if($phase-in@('metadata','settings')){'FileCat.App.Tests.dll'}else{'FileCat.Rendering.Tests.dll'}}
  Set-Location -LiteralPath $bin;$ErrorActionPreference='Continue'
  & 'C:\Program Files\dotnet\dotnet.exe' $assembly @filters -noLogo -noColor -maxThreads 2 -xml (Join-Path $base ($phase+'.xml')) *> (Join-Path $base ($phase+'.log'))
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop'
  [xml]$document=[IO.File]::ReadAllText((Join-Path $base ($phase+'.xml')));$a=$document.assemblies.assembly
  if($result-ne0-or[int]$a.total-le0-or[int]$a.failed-ne0-or[int]$a.errors-ne0){throw 'The actual test phase failed'}
  if($phase-eq'app-rescan'-and([int]$a.total-ne9-or[int]$a.passed-ne9-or[int]$a.skipped-ne0)){throw 'App rescan discovery mismatch'}
  if($phase-eq'epoch'-and([int]$a.total-ne15-or[int]$a.passed-ne15-or[int]$a.skipped-ne0)){throw 'Epoch discovery/platform skips mismatch'}
  if($phase-eq'native-epoch'-and([int]$a.total-ne2-or[int]$a.passed-ne2-or[int]$a.skipped-ne0)){throw 'Native epoch discovery mismatch'}
 }
 foreach($shape in 'wide','deep'){
  Idle;('RUNNING phase=1000-'+$shape)|Set-Content $state
  $case=Join-Path $base ('case-1000-'+$shape);New-Item -ItemType Directory -Path $case|Out-Null
  $env:FILECAT_TEST_NATIVE_SCALE_COUNT='1000';$env:FILECAT_TEST_NATIVE_SCALE_SHAPE=$shape;$env:FILECAT_TEST_NATIVE_SCALE_ROOT=$case
  Remove-Item Env:FILECAT_TEST_NATIVE_SCALE_SOURCE,Env:FILECAT_TEST_NATIVE_SCALE_KEEP_SOURCE -ErrorAction SilentlyContinue
  Set-Location -LiteralPath (Join-Path $payload 'render');$ErrorActionPreference='Continue'
  & 'C:\Program Files\dotnet\dotnet.exe' FileCat.Rendering.Tests.dll -class '*AnalysisAcquisitionScaleTests' -noLogo -noColor -maxThreads 1 -xml (Join-Path $case 'tests.xml') *> (Join-Path $case 'test.log')
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop'
  [xml]$document=[IO.File]::ReadAllText((Join-Path $case 'tests.xml'));$a=$document.assemblies.assembly
  $receipt=Get-Content -LiteralPath (Join-Path $case 'receipt.json') -Raw|ConvertFrom-Json
  if($result-ne0-or[int]$a.total-ne1-or[int]$a.passed-ne1-or!$receipt.completed-or!$receipt.cleanup-or$receipt.remainingSharedQuotaBytes-ne0-or$receipt.sourceCloseFailures-ne0){throw 'Native acquisition control failed'}
 }
 'FINISHED exit=0'|Set-Content $state;exit 0
}catch{($_|Out-String)|Set-Content (Join-Path $base 'failure.txt');'FINISHED exit=1'|Set-Content $state;exit 1}
