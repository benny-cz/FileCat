set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '96ba33e855aad748d99183502a79fc1cb54edf00d3f0adb67d24132d963e2799' ];umask 077;mkdir input;tar -xzf bundle.tgz -C input
python3 input/run.py
