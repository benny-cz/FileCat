$ErrorActionPreference='Stop'
$base=$PSScriptRoot;$state=Join-Path $base 'state.txt'
function Busy { @(Get-Process -Name 'FileCat*' -ErrorAction SilentlyContinue).Count -or @(Get-Process -Name dotnet -ErrorAction SilentlyContinue).Count }
if(Busy){'BUSY phase=verify'|Set-Content $state;exit 75}
try{
 if((Get-FileHash -LiteralPath (Join-Path $base 'bundle.tgz') -Algorithm SHA256).Hash.ToLowerInvariant()-ne'745eb49a65c7a1bfe18b9ca8cd079dff7ba74b6db479a41509ee87eb05deae1b'){throw 'Focused archive hash mismatch'}
 $driver=Join-Path $base 'driver';if(Test-Path -LiteralPath $driver){throw 'Fresh driver directory required'}
 New-Item -ItemType Directory -Path $driver|Out-Null
 & tar.exe -xzf (Join-Path $base 'bundle.tgz') -C $driver;if($LASTEXITCODE){throw 'Focused driver extraction failed'}
 $plan=Get-Content -Raw -LiteralPath (Join-Path $driver 'plan.json')|ConvertFrom-Json
 if($plan.baseline-ne'C:\FileCatDsa20261104R2\batch-r1222\payload\render'){throw 'Unexpected baseline root'}
 $payload=Join-Path $base 'payload';if(Test-Path -LiteralPath $payload){throw 'Fresh focused payload required'}
 foreach($item in $plan.files){
  if([IO.Path]::IsPathRooted($item.path)-or$item.path.Contains(':')-or@($item.path-split'/'|Where-Object{$_-eq'..'}).Count){throw 'Invalid cached input path'}
  if((Get-FileHash -LiteralPath (Join-Path $plan.baseline $item.path) -Algorithm SHA256).Hash.ToLowerInvariant()-ne$item.baselineSha256){throw 'Cached input changed'}
 }
 foreach($item in $plan.files){
  if($item.patch-and$item.path-notin $plan.assembly,($plan.assembly-replace'[.]dll$','.pdb')){throw 'Production input patch refused'}
  $source=if($item.patch){Join-Path $driver ('patch/'+$item.path)}else{Join-Path $plan.baseline $item.path}
  $target=Join-Path $payload $item.path;New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force|Out-Null;Copy-Item -LiteralPath $source -Destination $target
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()-ne$item.sha256){throw 'Copied input mismatch'}
 }
 ('VERIFIED cachedFiles='+$plan.files.Count+' changedFiles='+@($plan.files|Where-Object{$_.patch}).Count)|Set-Content (Join-Path $base 'cache-proof.txt')
 if(Busy){'BUSY phase=render'|Set-Content $state;exit 75}
 $arguments=@((Join-Path $payload $plan.assembly))
 foreach($method in $plan.methods){$arguments+=@('-method',$method)}
 $arguments+=@('-noLogo','-noColor','-maxThreads','2','-xml',(Join-Path $base 'render-r1227.xml'))
 'RUNNING phase=render'|Set-Content $state;Set-Location -LiteralPath $payload;$ErrorActionPreference='Continue'
 & 'C:\Program Files\dotnet\dotnet.exe' @arguments *> (Join-Path $base 'render-r1227.log')
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop'
 if($result-ne0){('FINISHED exit='+$result)|Set-Content $state;exit $result}
 [xml]$focused=[IO.File]::ReadAllText((Join-Path $base 'render-r1227.xml'))
 if([int]$focused.assemblies.assembly.total-ne1-or[int]$focused.assemblies.assembly.passed-ne1){throw 'Focused fixture discovery mismatch'}
 foreach($shape in 'wide','deep'){
  if(Busy){('BUSY phase=1000-'+$shape)|Set-Content $state;exit 75}
  ('RUNNING phase=1000-'+$shape)|Set-Content $state
  $case=Join-Path $base ('case-1000-'+$shape);New-Item -ItemType Directory -Path $case|Out-Null
  $env:FILECAT_TEST_NATIVE_SCALE_COUNT='1000';$env:FILECAT_TEST_NATIVE_SCALE_SHAPE=$shape;$env:FILECAT_TEST_NATIVE_SCALE_ROOT=$case
  Remove-Item Env:FILECAT_TEST_NATIVE_SCALE_SOURCE,Env:FILECAT_TEST_NATIVE_SCALE_KEEP_SOURCE -ErrorAction SilentlyContinue
  Set-Location -LiteralPath $payload;$ErrorActionPreference='Continue'
  & 'C:\Program Files\dotnet\dotnet.exe' FileCat.Rendering.Tests.dll -class '*AnalysisAcquisitionScaleTests' -noLogo -noColor -maxThreads 1 -xml (Join-Path $case 'tests.xml') *> (Join-Path $case 'test.log')
  $result=$LASTEXITCODE;$ErrorActionPreference='Stop'
  [xml]$document=[IO.File]::ReadAllText((Join-Path $case 'tests.xml'));$a=$document.assemblies.assembly
  $receipt=Get-Content -LiteralPath (Join-Path $case 'receipt.json') -Raw|ConvertFrom-Json
  if($result-ne0-or[int]$a.total-ne1-or[int]$a.passed-ne1-or!$receipt.completed-or!$receipt.cleanup-or$receipt.remainingSharedQuotaBytes-ne0-or$receipt.sourceCloseFailures-ne0){throw 'Actual native acquisition control failed'}
 }
 'FINISHED exit=0'|Set-Content $state;exit 0
}catch{($_|Out-String)|Set-Content (Join-Path $base 'failure.txt');'FAILED'|Set-Content $state;exit 1}
