set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '00ab0f8d3b792dc8a2e225d429c8a11fa5123b8070ea1a5d6781dcba7f1abc24' ];umask 077;mkdir input;tar -xzf bundle.tgz -C input
python3 input/run.py
