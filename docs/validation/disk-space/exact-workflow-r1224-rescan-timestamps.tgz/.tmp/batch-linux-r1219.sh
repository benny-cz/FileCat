set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" = Darwin ];then actual=$(shasum -a 256 bundle.tgz | cut -d ' ' -f 1);else actual=$(sha256sum bundle.tgz | cut -d ' ' -f 1);fi
[ "$actual" = '8c2a432253368438e273324cad1e581c51300cb60d764024b29398753fcdfbd4' ];umask 077;mkdir input;tar -xzf bundle.tgz -C input
python3 input/run.py
