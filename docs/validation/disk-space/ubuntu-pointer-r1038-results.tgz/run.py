import hashlib,json,pathlib,subprocess,xml.etree.ElementTree as E
base=pathlib.Path.cwd();plan=json.loads((base/'plan.json').read_text(encoding='utf-8-sig'));payload=pathlib.Path(plan['baseline'])
def busy():
    return any(subprocess.run(args,capture_output=True).returncode==0 for args in (['pgrep','-x','FileCat([.].*)?'],['pgrep','-f','^[^ ]*dotnet +.*FileCat']))
if busy():raise SystemExit(75)
for item in plan['files']:
    with (payload/item['path']).open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest()!=item['sha256']:raise RuntimeError('Cached input changed: '+item['path'])
rows=[]
for trial in range(1,4):
    if busy():raise SystemExit(75)
    xml=base/f'trial-{trial}.xml'
    with (base/f'trial-{trial}.log').open('w') as output:
        run=subprocess.run([str(pathlib.Path.home()/'.dotnet/dotnet'),'FileCat.Rendering.Tests.dll','-method','FileCat.Rendering.Tests.AnalysisRenderingTests.IndexedSelectionTablePressKeepsItsCapturedMarkTargetUntilThePendingQueryCanPublish','-noLogo','-noColor','-maxThreads','1','-xml',str(xml)],cwd=payload,stdout=output,stderr=subprocess.STDOUT)
    a=E.parse(xml).getroot().find('assembly');rows.append({'trial':trial,'exit':run.returncode,**a.attrib})
(base/'report.json').write_text(json.dumps({'verifiedInputs':len(plan['files']),'trials':rows},indent=2)+'\n')
print(json.dumps(rows))
