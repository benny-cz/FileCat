using FileCat.Core.Listing;
using FileCat.Core.Resources;
using FileCat.Core.State;

namespace FileCat.App.Controls;

public enum ColumnField
{
    Name,
    Extension,
    Size,
    Modified,
    Created,
    Attributes,
    /// <summary>Containing folder of a result-set item.</summary>
    Folder,
    /// <summary>Registry value type or a provider-specific kind.</summary>
    Kind,
    /// <summary>Registry data preview or archive member details.</summary>
    Details,
    /// <summary>A lazily computed metadata field (<see cref="ColumnSpec.MetadataId"/>).</summary>
    Metadata,
}

public sealed record ColumnSpec(ColumnField Field, string Header, double Width, bool RightAlign = false, bool Star = false)
{
    public string? MetadataId { get; init; }

    /// <summary>A date column that shows seconds (a change journal's times).</summary>
    public bool Seconds { get; init; }

    public SortField? SortField => Field switch
    {
        ColumnField.Name => Core.Listing.SortField.Name,
        ColumnField.Extension => Core.Listing.SortField.Extension,
        ColumnField.Size => Core.Listing.SortField.Size,
        ColumnField.Modified => Core.Listing.SortField.Modified,
        ColumnField.Created => Core.Listing.SortField.Created,
        ColumnField.Attributes => Core.Listing.SortField.Attributes,
        ColumnField.Metadata => Core.Listing.SortField.Metadata,
        ColumnField.Folder => Core.Listing.SortField.Metadata,
        _ => null,
    };

    /// <summary>The sort key a Folder column uses (<see cref="ViewModels.TabViewModel"/> supplies each item's folder).</summary>
    public const string FolderSortKey = "folder";
}

/// <summary>Built-in column profiles (the defaults of <see cref="ColumnProfileSet"/>) and dedicated layouts.</summary>
public static class ColumnProfiles
{
    /// <summary>
    /// How much of the space the fixed columns leave a filling column takes, against the other filling columns' shares
    /// (its <see cref="ColumnSpec.Width"/>): a name's, and most columns'.
    /// </summary>
    public const double DefaultFillShare = 200;

    /// <summary>A link target is a path, most often longer than the name beside it: filling, it takes a larger share.</summary>
    public const double LinkTargetFillShare = 260;

    /// <summary>Linux and macOS show permissions and ownership where Windows shows attributes and file versions.</summary>
    public static IReadOnlyList<(string Name, ColumnSpec[] Columns)> Defaults { get; } = OperatingSystem.IsWindows() ? WindowsDefaults() : UnixDefaults();

    private static List<(string Name, ColumnSpec[] Columns)> UnixDefaults() =>
    [
        ("Details", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Extension, "Ext", 56),
            new(ColumnField.Size, "Size", 86, RightAlign: true),
            new(ColumnField.Modified, "Modified", 128),
            new(ColumnField.Metadata, "Permissions", 88) { MetadataId = "permissions" },
        ]),
        ("Brief", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Size, "Size", 86, RightAlign: true),
        ]),
        ("Full", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Extension, "Ext", 56),
            new(ColumnField.Size, "Size", 96, RightAlign: true),
            new(ColumnField.Modified, "Modified", 128),
            new(ColumnField.Created, "Created", 128),
            new(ColumnField.Metadata, "Permissions", 88) { MetadataId = "permissions" },
            new(ColumnField.Metadata, "Owner", 90) { MetadataId = "owner" },
            new(ColumnField.Metadata, "Group", 90) { MetadataId = "group" },
            new(ColumnField.Metadata, "Attributes", 70, RightAlign: true) { MetadataId = "hidden" },
        ]),
        ("Media", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Size, "Size", 86, RightAlign: true),
            new(ColumnField.Metadata, "Dimensions", 110, RightAlign: true) { MetadataId = "dimensions" },
            new(ColumnField.Metadata, "Origin", 90) { MetadataId = "zone" },
            new(ColumnField.Modified, "Modified", 128),
        ]),
        ("Links", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Metadata, "Link target", LinkTargetFillShare, Star: true) { MetadataId = "linkTarget" },
            new(ColumnField.Modified, "Modified", 128),
        ]),
    ];

    private static List<(string Name, ColumnSpec[] Columns)> WindowsDefaults() =>
    [
        ("Details", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Extension, "Ext", 56),
            new(ColumnField.Size, "Size", 86, RightAlign: true),
            new(ColumnField.Modified, "Modified", 128),
            new(ColumnField.Attributes, "Attr", 44),
        ]),
        ("Brief", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Size, "Size", 86, RightAlign: true),
        ]),
        ("Full", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Extension, "Ext", 56),
            new(ColumnField.Size, "Size", 96, RightAlign: true),
            new(ColumnField.Modified, "Modified", 128),
            new(ColumnField.Created, "Created", 128),
            new(ColumnField.Metadata, "Version", 110) { MetadataId = "version" },
            new(ColumnField.Metadata, OperatingSystem.IsWindows() ? "Streams" : "Attributes", 70, RightAlign: true) { MetadataId = "hidden" },
            new(ColumnField.Attributes, "Attr", 50),
        ]),
        ("Media", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Size, "Size", 86, RightAlign: true),
            new(ColumnField.Metadata, "Dimensions", 110, RightAlign: true) { MetadataId = "dimensions" },
            new(ColumnField.Metadata, "Origin", 90) { MetadataId = "zone" },
            new(ColumnField.Modified, "Modified", 128),
        ]),
        ("Links", [
            new(ColumnField.Name, "Name", DefaultFillShare, Star: true),
            new(ColumnField.Metadata, "Link target", LinkTargetFillShare, Star: true) { MetadataId = "linkTarget" },
            new(ColumnField.Modified, "Modified", 128),
        ]),
    ];

    public static ColumnSpec[] ResultSet { get; } =
    [
        new(ColumnField.Name, "Name", 180, Star: true),
        new(ColumnField.Kind, "Kind", 70),
        new(ColumnField.Folder, "Folder", 220, Star: true) { MetadataId = ColumnSpec.FolderSortKey },
        new(ColumnField.Size, "Size", 86, RightAlign: true),
        new(ColumnField.Modified, "Modified", 128),
        new(ColumnField.Attributes, "Attr", 50),
    ];

    /// <summary>Find's duplicates: each file's group beside it, the groups in the order found.</summary>
    public static ColumnSpec[] Duplicates { get; } =
    [
        new(ColumnField.Name, "Name", 180, Star: true),
        new(ColumnField.Details, "Duplicates", 150),
        new(ColumnField.Folder, "Folder", 220, Star: true) { MetadataId = ColumnSpec.FolderSortKey },
        new(ColumnField.Size, "Size", 86, RightAlign: true),
        new(ColumnField.Modified, "Modified", 128),
    ];

    /// <summary>The list of working sets: each set's name, size in items, and when it last changed.</summary>
    public static ColumnSpec[] WorkingSetList { get; } =
    [
        new(ColumnField.Name, "Working set", 240, Star: true),
        new(ColumnField.Details, "Items", 110),
        new(ColumnField.Modified, "Changed", 128),
    ];

    /// <summary>Deleted items: how much can come back, and the evidence for it.</summary>
    public static ColumnSpec[] Recovery { get; } =
    [
        new(ColumnField.Name, "Name", 200, Star: true),
        new(ColumnField.Size, "Size", 86, RightAlign: true),
        new(ColumnField.Modified, "Modified", 128),
        new(ColumnField.Kind, "State", 96),
        new(ColumnField.Details, "Evidence", 320, Star: true),
    ];

    /// <summary>A file's streams and attributes (D-55): what each is, how big, and what it says.</summary>
    public static ColumnSpec[] HiddenData { get; } =
    [
        new(ColumnField.Name, "Name", 200, Star: true),
        new(ColumnField.Kind, "Kind", 120),
        new(ColumnField.Size, "Size", 86, RightAlign: true),
        new(ColumnField.Details, "What it says", 340, Star: true),
    ];

    /// <summary>A volume's change journal (D-56): each entry's name, time to the second, what happened, and its folder.</summary>
    public static ColumnSpec[] Journal { get; } =
    [
        new(ColumnField.Name, "Name", 300, Star: true),
        new(ColumnField.Modified, "Time", 150) { Seconds = true },
        new(ColumnField.Kind, "What happened", 190),
        new(ColumnField.Details, "Folder", 260, Star: true),
    ];

    /// <summary>Windows' Recycle Bin: each item's name, the folder it was deleted from, its size, and when it was deleted.</summary>
    public static ColumnSpec[] RecycleBin { get; } =
    [
        new(ColumnField.Name, "Name", 220, Star: true),
        new(ColumnField.Details, "Deleted from", 280, Star: true),
        new(ColumnField.Size, "Size", 86, RightAlign: true),
        new(ColumnField.Modified, "Deleted", 128),
    ];

    public static ColumnSpec[] Registry { get; } =
    [
        new(ColumnField.Name, "Name", 200, Star: true),
        new(ColumnField.Kind, "Type", 120),
        new(ColumnField.Details, "Data", 240, Star: true),
        new(ColumnField.Size, "Size", 70, RightAlign: true),
    ];
}

/// <summary>
/// A column the profile editor offers: its stable settings key and how to build it. Filling the remaining space, it
/// takes <paramref name="FillShare"/> of it against the other filling columns' shares.
/// </summary>
public sealed record ColumnChoice(string Key, string Title, bool RightAlign, double DefaultWidth,
    double FillShare = ColumnProfiles.DefaultFillShare, string? Description = null);

/// <summary>One field description shared by the add box and the Analyze chooser.</summary>
public static class ColumnDescriptions
{
    public static string For(string fieldId) => fieldId switch
    {
        "version" => "Program and library versions (.exe, .dll, and similar)",
        "dimensions" => "Picture sizes in pixels",
        "linkTarget" => "Where links and junctions point",
        "zone" => "Where files came from (downloaded from the internet, say)",
        "permissions" => "The mode bits: what owner, group, and others may read, write, and run. ACLs, where present, are not shown",
        "owner" => OperatingSystem.IsWindows()
            ? "The account each item belongs to (a user, group, or service; not who created or last changed it)"
            : "The user account each item belongs to (not who created or last changed it)",
        "group" => "The group each item belongs to",
        "hidden" => OperatingSystem.IsWindows() ? "Alternate data streams each file carries, counted" : "Extended attributes each item carries, counted",
        "verified" => "Whether files match the checksums and signatures beside them (large ones wait for File → Verify)",
        _ => "A column's value for every item",
    };
}

/// <summary>
/// The user's column profiles (Alt+0–9), shared by all tabs and backed by settings. Until customized the built-in
/// profiles apply. A width of 0 in settings means "fill the remaining space"; filling columns share it as their kind
/// does (<see cref="ColumnChoice.FillShare"/>), so a profile comes back from settings as it was. Result sets and the
/// registry keep their dedicated layouts. Every profile keeps a Name column.
/// </summary>
public sealed class ColumnProfileSet
{
    public const int MaxProfiles = 10;
    private List<(string Name, ColumnSpec[] Columns)> _profiles;

    public ColumnProfileSet(IReadOnlyList<ColumnProfile>? saved)
    {
        _profiles = Parse(saved) ?? [.. ColumnProfiles.Defaults];
    }

    /// <summary>Raised on the UI thread after a width or profile change.</summary>
    public event Action? Changed;

    public int Count => _profiles.Count;

    public IReadOnlyList<(string Name, ColumnSpec[] Columns)> Profiles => _profiles;

    public string NameOf(int profile) => _profiles[Math.Clamp(profile, 0, _profiles.Count - 1)].Name;

    /// <summary>True when the scheme has a dedicated layout that profiles do not change.</summary>
    public static bool HasFixedLayout(string scheme) => scheme is Schemes.ResultSet or Schemes.Registry or Schemes.Recovery or Schemes.HiddenData or Schemes.Journal or Schemes.RecycleBin;

    public ColumnSpec[] Get(int profile, string scheme)
    {
        if (scheme == Schemes.ResultSet) return ColumnProfiles.ResultSet;
        if (scheme == Schemes.Registry) return ColumnProfiles.Registry;
        if (scheme == Schemes.Recovery) return ColumnProfiles.Recovery;
        if (scheme == Schemes.HiddenData) return ColumnProfiles.HiddenData;
        if (scheme == Schemes.Journal) return ColumnProfiles.Journal;
        if (scheme == Schemes.RecycleBin) return ColumnProfiles.RecycleBin;
        return _profiles[Math.Clamp(profile, 0, _profiles.Count - 1)].Columns;
    }

    public static IReadOnlyList<ColumnChoice> Choices { get; } =
    [
        new("name", "Name", false, 0),
        new("ext", "Ext", false, 56),
        new("size", "Size", true, 86),
        new("modified", "Modified", false, 128),
        new("created", "Created", false, 128),
        new("attr", "Attr", false, 44),
        .. Core.Metadata.BuiltInFields.All.Select(f => new ColumnChoice("meta:" + f.Id, f.Title, f.RightAlign,
            OperatingSystem.IsWindows() && f.Id == "owner" ? 160 : 110,
            f.Id == Core.Metadata.BuiltInFields.LinkTarget.Id ? ColumnProfiles.LinkTargetFillShare : ColumnProfiles.DefaultFillShare,
            ColumnDescriptions.For(f.Id))),
    ];

    /// <summary>Stores a column width chosen by dragging its border (never turns a fill column fixed).</summary>
    public void SetWidth(int profile, int column, double width)
    {
        if ((uint)profile >= (uint)_profiles.Count) return;
        var (name, columns) = _profiles[profile];
        if ((uint)column >= (uint)columns.Length || columns[column].Star) return;
        double stored = Math.Round(Math.Clamp(width, 24, 2000));
        if (columns[column].Width == stored) return; // the width it has: nothing changed
        var copy = (ColumnSpec[])columns.Clone();
        copy[column] = copy[column] with { Width = stored };
        _profiles[profile] = (name, copy);
        Changed?.Invoke();
    }

    /// <summary>Replaces all profiles (the Settings editor); keeps at least one and at most ten.</summary>
    public void Replace(IEnumerable<(string Name, ColumnSpec[] Columns)> profiles)
    {
        List<(string Name, ColumnSpec[] Columns)> list =
            [.. profiles.Where(p => p.Columns.Length > 0).Take(MaxProfiles).Select(p => (p.Name, EnsureName(p.Columns)))];
        if (list.Count == 0) list = [.. ColumnProfiles.Defaults];
        // A profile the edit left as it was keeps its own column list, so no list showing it is told its columns changed.
        for (int i = 0; i < list.Count; i++)
        {
            var next = list[i];
            var kept = i < _profiles.Count && SameColumns(_profiles[i].Columns, next.Columns) ? _profiles[i].Columns
                : _profiles.FirstOrDefault(p => p.Name == next.Name && SameColumns(p.Columns, next.Columns)).Columns;
            if (kept is not null) list[i] = (next.Name, kept);
        }
        // The same profiles again (Settings' OK with nothing edited, or an edit that came back to what was there):
        // nothing changed, so no list is told its columns did.
        if (list.Count == _profiles.Count &&
            list.Zip(_profiles).All(p => p.First.Name == p.Second.Name && ReferenceEquals(p.First.Columns, p.Second.Columns))) return;
        _profiles = list;
        Changed?.Invoke();
    }

    /// <summary>
    /// Whether two column lists are the same as profiles keep them: the same columns in the same order, at the same widths
    /// (a filling column's is its share of the space the fixed columns leave).
    /// </summary>
    public static bool SameColumns(IReadOnlyList<ColumnSpec> a, IReadOnlyList<ColumnSpec> b)
    {
        if (!SameFields(a, b)) return false;
        for (int i = 0; i < a.Count; i++)
            if (a[i].Width != b[i].Width) return false;
        return true;
    }

    /// <summary>Whether two column lists have the same columns in the same order, filling the space alike (widths aside).</summary>
    public static bool SameFields(IReadOnlyList<ColumnSpec> a, IReadOnlyList<ColumnSpec> b)
    {
        if (ReferenceEquals(a, b)) return true;
        if (a.Count != b.Count) return false;
        for (int i = 0; i < a.Count; i++)
            if (a[i].Star != b[i].Star || KeyOf(a[i]) != KeyOf(b[i])) return false;
        return true;
    }

    public List<ColumnProfile> ToSettings() =>
        _profiles.Select(p => new ColumnProfile
        {
            Name = p.Name,
            Columns = p.Columns.Select(c => new ColumnSetting { Field = KeyOf(c), Width = c.Star ? 0 : c.Width, Visible = true }).ToList(),
        }).ToList();

    public static string KeyOf(ColumnSpec c) => c.Field switch
    {
        ColumnField.Name => "name",
        ColumnField.Extension => "ext",
        ColumnField.Size => "size",
        ColumnField.Modified => "modified",
        ColumnField.Created => "created",
        ColumnField.Attributes => "attr",
        ColumnField.Metadata => "meta:" + c.MetadataId,
        _ => c.Field.ToString().ToLowerInvariant(),
    };

    /// <summary>A column for a settings key; width 0 fills the remaining space, with the column's share of it. Null for unknown keys.</summary>
    public static ColumnSpec? Create(string key, double width)
    {
        var choice = Choices.FirstOrDefault(c => string.Equals(c.Key, key, StringComparison.OrdinalIgnoreCase));
        if (choice is null) return null;
        bool star = width <= 0;
        double w = star ? choice.FillShare : Math.Clamp(width, 24, 2000);
        var field = choice.Key switch
        {
            "name" => ColumnField.Name,
            "ext" => ColumnField.Extension,
            "size" => ColumnField.Size,
            "modified" => ColumnField.Modified,
            "created" => ColumnField.Created,
            "attr" => ColumnField.Attributes,
            _ => ColumnField.Metadata,
        };
        var spec = new ColumnSpec(field, choice.Title, w, choice.RightAlign, star);
        return field == ColumnField.Metadata ? spec with { MetadataId = choice.Key["meta:".Length..] } : spec;
    }

    private static List<(string Name, ColumnSpec[] Columns)>? Parse(IReadOnlyList<ColumnProfile>? saved)
    {
        if (saved is null || saved.Count == 0) return null;
        var list = new List<(string, ColumnSpec[])>();
        foreach (var p in saved)
        {
            if (list.Count == MaxProfiles) break;
            var columns = p.Columns.Where(c => c.Visible).Select(c => Create(c.Field, c.Width)).OfType<ColumnSpec>().ToArray();
            if (columns.Length == 0) continue;
            list.Add((string.IsNullOrWhiteSpace(p.Name) ? $"Profile {list.Count}" : p.Name.Trim(), EnsureName(columns)));
        }
        return list.Count > 0 ? list : null;
    }

    private static ColumnSpec[] EnsureName(ColumnSpec[] columns) =>
        columns.Any(c => c.Field == ColumnField.Name) ? columns : [Create("name", 0)!, .. columns];
}
